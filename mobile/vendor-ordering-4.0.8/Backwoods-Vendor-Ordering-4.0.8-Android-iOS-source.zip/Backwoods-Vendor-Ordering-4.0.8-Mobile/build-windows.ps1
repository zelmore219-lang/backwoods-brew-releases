$ErrorActionPreference = "Stop"
Write-Host "Installing dependencies..." -ForegroundColor Cyan
npm install
Write-Host "Building web/PWA..." -ForegroundColor Cyan
npm run build
Write-Host "Building Windows installer and portable app..." -ForegroundColor Cyan
npm run desktop:win
Write-Host "Finished. Open the release folder." -ForegroundColor Green
Start-Process explorer.exe "release"
