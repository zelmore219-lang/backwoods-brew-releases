# Merge the vendor rules safely

The vendor app now uses only collections beginning with `vendor`, including `vendorUsers`, `vendorOrders`, and `vendorSettings`. It no longer reads or writes the main app collections such as `users`, `orders`, or `settings`.

1. Open Firebase Console > Firestore Database > Rules.
2. Keep all existing main-app rules.
3. Open `firestore-vendor-rules-snippet.rules`.
4. Copy its contents inside the existing `match /databases/{database}/documents { ... }` block, just before that block's final closing brace.
5. Publish the combined rules.
6. Start this vendor app and sign in as `admin`. The app creates `vendorUsers/{your-auth-uid}` with role `owner`.

Do not paste the snippet outside the database match block, and do not erase the main app rules.
