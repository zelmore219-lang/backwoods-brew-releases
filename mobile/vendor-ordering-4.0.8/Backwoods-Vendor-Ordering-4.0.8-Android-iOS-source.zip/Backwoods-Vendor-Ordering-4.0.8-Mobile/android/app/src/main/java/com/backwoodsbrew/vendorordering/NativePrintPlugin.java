package com.backwoodsbrew.vendorordering;

import android.content.Context;
import android.print.PrintAttributes;
import android.print.PrintManager;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

@CapacitorPlugin(name = "NativePrint")
public class NativePrintPlugin extends Plugin {
    @PluginMethod
    public void print(PluginCall call) {
        getActivity().runOnUiThread(() -> {
            try {
                PrintManager manager = (PrintManager) getActivity().getSystemService(Context.PRINT_SERVICE);
                if (manager == null) { call.reject("Printing is unavailable on this device."); return; }
                manager.print("Backwoods Vendor Ordering", getBridge().getWebView().createPrintDocumentAdapter("Backwoods document"), new PrintAttributes.Builder().build());
                call.resolve();
            } catch (Exception error) { call.reject("Could not open the print dialog.", error); }
        });
    }
}
