@echo off
cd /d "%~dp0"
code .
if errorlevel 1 (
  echo VS Code command was not found. Open VS Code, choose File - Open Folder, and select this folder.
  pause
)
