@echo off
setlocal
cd /d "%~dp0"
echo.
echo Backwoods Vendor Ordering - Windows Setup
echo ===========================================
where node >nul 2>nul
if errorlevel 1 (
  echo ERROR: Node.js is not installed or is not on PATH.
  echo Install Node.js 20 LTS from nodejs.org, restart VS Code, then run this file again.
  pause
  exit /b 1
)
node -v
npm -v
if exist node_modules rmdir /s /q node_modules
if exist package-lock.json del /q package-lock.json
call npm cache verify
call npm config set registry https://registry.npmjs.org/
call npm install --no-audit --no-fund
if errorlevel 1 (
  echo.
  echo INSTALL FAILED. Copy the red error shown above and send it for diagnosis.
  pause
  exit /b 1
)
echo.
echo Installation completed. Starting the app...
call npm run dev
pause
