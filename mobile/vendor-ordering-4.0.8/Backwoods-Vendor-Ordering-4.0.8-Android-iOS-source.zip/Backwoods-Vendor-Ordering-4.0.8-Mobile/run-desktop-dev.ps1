$ErrorActionPreference = "Stop"
npm install
npm run desktop:dev
