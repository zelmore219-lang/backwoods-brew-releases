# Backwoods Vendor Ordering 4.0.8 — recovered mobile source

Recovered from your uploaded Windows app.asar, retaining the newer vendor app features. This is separate from the Backwoods Brew main app.

- Read **MOBILE-BUILD.md** for setup, Android APK builds, and iPhone/iPad build/signing steps.
- Read **RECOVERY-NOTES.md** for recovery provenance and limitations.
- Read **MOBILE-VALIDATION.md** for executed checks and outstanding device testing.

Run `npm ci`, then `npm run mobile:sync` to rebuild assets and native projects. Your local Firebase .env is deliberately excluded; restore the original web-client settings before production builds.

The prepared Android test APK is version 4.0.8 with version code 2 and the same application ID and development signer as the earlier 4.0 test APK. Install as an update without uninstalling. Export a backup before upgrades. No compiled/signed iOS IPA is included.
