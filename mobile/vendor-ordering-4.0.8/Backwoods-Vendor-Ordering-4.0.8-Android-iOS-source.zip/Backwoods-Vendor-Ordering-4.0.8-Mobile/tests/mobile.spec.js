import { test, expect } from '@playwright/test';

async function login(page, role = 'Owner') {
  await page.goto('/');
  await page.getByRole('button', { name: role, exact: true }).click();
}
async function navigate(page, name) {
  await page.getByRole('button', { name: 'Menu', exact: true }).click();
  await page.getByRole('navigation').getByRole('link', { name, exact: true }).click();
  await expect(page.getByRole('button', { name: 'Menu', exact: true })).toHaveAttribute('aria-expanded', 'false');
}

test('phone menu, order submission, local persistence and inventory reservation', async ({ page }) => {
  const errors = [];
  page.on('pageerror', error => errors.push(error.message));
  await login(page);
  await expect(page.getByRole('heading', { name: 'Operations Dashboard' })).toBeVisible();
  await expect(page.getByRole('navigation')).toBeHidden();
  await navigate(page, 'Orders');
  await page.getByRole('button', { name: /new order/i }).click();
  await page.getByPlaceholder('Search catalog, SKU, or UPC').fill('MC-10');
  await page.locator('.order-return-table tbody tr').first().locator('input.qty').first().fill('2');
  await page.getByRole('button', { name: 'Submit order & returns', exact: true }).click();
  await expect(page.locator('.modal')).toHaveCount(0);
  await expect.poll(() => page.evaluate(() => JSON.parse(localStorage.getItem('backwoods_vendor_app_v2')).orders.length)).toBe(1);
  const state = await page.evaluate(() => JSON.parse(localStorage.getItem('backwoods_vendor_app_v2')));
  expect(state.orders[0].items[0].qty).toBe(2);
  expect(state.products.find(p => p.id === state.orders[0].items[0].productId).reserved).toBe(2);
  await page.reload();
  await expect(page.getByRole('heading', { name: /Orders/ })).toBeVisible();
  expect(await page.evaluate(() => JSON.parse(localStorage.getItem('backwoods_vendor_app_v2')).orders.length)).toBe(1);
  expect(errors).toEqual([]);
});

test('phone product editing and role restrictions', async ({ page }) => {
  await login(page);
  await navigate(page, 'Products');
  await page.getByRole('button', { name: 'Edit', exact: true }).first().click();
  await page.getByLabel(/^(Product name|name)$/).fill('Mobile test coffee');
  await page.getByRole('button', { name: 'Save product' }).click();
  await expect(page.getByText('Mobile test coffee', { exact: true }).first()).toBeVisible();
  await page.getByRole('button', { name: 'Menu', exact: true }).click();
  await page.getByRole('button', { name: 'Sign out' }).click();
  await page.getByRole('button', { name: 'Driver', exact: true }).click();
  await page.goto('/#/');
  await page.getByRole('button', { name: 'Menu', exact: true }).click();
  await expect(page.getByRole('navigation').getByRole('link', { name: 'Users', exact: true })).toHaveCount(0);
  await page.goto('/#/users');
  await expect(page.getByRole('heading', { name: /access|permission|authorized/i })).toBeVisible();
});

test('tablet navigation keeps all business pages accessible', async ({ page }) => {
  await page.setViewportSize({ width: 1024, height: 768 });
  await login(page);
  await expect(page.getByRole('navigation')).toBeVisible();
  for (const name of ['Products', 'Stores', 'Orders', 'Packing', 'Drivers', 'Invoices', 'Settings']) {
    await page.getByRole('navigation').getByRole('link', { name, exact: true }).click();
    await expect(page.locator('main h1')).toBeVisible();
  }
});

test('native adapters preserve exported backups and request GPS/print through the bridge', async ({ page }) => {
  await page.addInitScript(() => {
    window.androidBridge = {};
    window.__nativeCalls = [];
    const methods = { App: ['addListener', 'minimizeApp'], Filesystem: ['writeFile'], Share: ['share'], Browser: ['open'], Geolocation: ['requestPermissions', 'getCurrentPosition'], NativePrint: ['print'] };
    window.Capacitor = {
      PluginHeaders: Object.entries(methods).map(([name, entries]) => ({ name, methods: entries.map(name => ({ name, rtype: name === 'addListener' ? 'callback' : 'promise' })) })),
      nativeCallback: () => 'listener-1',
      nativePromise: async (plugin, method, options) => {
        window.__nativeCalls.push({ plugin, method, options });
        if (method === 'writeFile') return { uri: 'file:///cache/backup.json' };
        if (method === 'requestPermissions') return { location: window.__denyLocation ? 'denied' : 'granted' };
        if (method === 'getCurrentPosition') return { coords: { latitude: 33.6, longitude: -85.8, accuracy: 10 } };
        return {};
      },
    };
  });
  await login(page);
  await navigate(page, 'System');
  await page.getByRole('button', { name: 'Download full backup' }).click();
  await expect.poll(() => page.evaluate(() => window.__nativeCalls.some(c => c.method === 'share'))).toBe(true);
  const exported = await page.evaluate(() => {
    const write = window.__nativeCalls.find(c => c.method === 'writeFile');
    return JSON.parse(atob(write.options.data));
  });
  expect(exported.app).toBe('Backwoods Vendor Ordering');
  expect(exported.data.products.length).toBeGreaterThan(3);
  expect(exported.data.products.some(p => p.category === 'Soda')).toBe(true);
  const location = await page.evaluate(async () => {
    const { getCurrentLocation } = await import('/src/lib/mobile.js');
    return getCurrentLocation();
  });
  expect(location.coords.latitude).toBe(33.6);
  const denied = await page.evaluate(async () => {
    window.__denyLocation = true;
    const { getCurrentLocation } = await import('/src/lib/mobile.js');
    try { await getCurrentLocation(); } catch (error) { return error.message; }
  });
  expect(denied).toContain('permission was denied');
  await navigate(page, 'Products');
  await page.getByRole('button', { name: 'Catalog JSON', exact: true }).click();
  await expect.poll(() => page.evaluate(() => window.__nativeCalls.filter(c => c.method === 'share').length)).toBe(2);
  await page.getByRole('button', { name: 'Print catalog', exact: true }).click();
  await expect(page.getByRole('dialog', { name: 'Catalog print preview' })).toBeVisible();
  await page.getByRole('button', { name: 'Print / Save PDF', exact: true }).click();
  await expect.poll(() => page.evaluate(() => window.__nativeCalls.some(c => c.plugin === 'NativePrint' && c.method === 'print'))).toBe(true);
  await page.getByRole('button', { name: 'Close preview', exact: true }).click();
  await expect(page.getByRole('dialog', { name: 'Catalog print preview' })).toHaveCount(0);
});

test('recovered 4.0.8 scanner, imports, settlements and sync pages remain available', async ({ page }) => {
  await login(page);
  await navigate(page, 'Scanner Test');
  await page.getByPlaceholder('Scan or type a UPC, then press Enter').fill('012345678905');
  await page.getByPlaceholder('Scan or type a UPC, then press Enter').press('Enter');
  await expect(page.getByText('Scanner read 012345678905')).toBeVisible();
  for (const [link, heading] of [['Imports', 'Import Tools'], ['Settlements', /Settlement/i], ['Sync Log', /Sync/i]]) {
    await navigate(page, link);
    await expect(page.getByRole('heading', { name: heading, level: 1 })).toBeVisible();
  }
});
