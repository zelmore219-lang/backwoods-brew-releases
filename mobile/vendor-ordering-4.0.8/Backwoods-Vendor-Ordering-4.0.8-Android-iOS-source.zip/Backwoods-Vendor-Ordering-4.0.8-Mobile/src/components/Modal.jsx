export default function Modal({ title, onClose, children, wide=false }) {
  return <div className="modal-backdrop" onMouseDown={onClose}>
    <div className={`modal ${wide ? 'wide' : ''}`} onMouseDown={e=>e.stopPropagation()}>
      <div className="modal-head"><h3>{title}</h3><button className="icon-btn" onClick={onClose}>×</button></div>
      {children}
    </div>
  </div>
}
