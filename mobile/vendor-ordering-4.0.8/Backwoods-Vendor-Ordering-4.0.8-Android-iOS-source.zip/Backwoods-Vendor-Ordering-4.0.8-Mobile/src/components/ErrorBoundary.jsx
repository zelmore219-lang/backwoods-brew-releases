import React from 'react';

const KEY='backwoods_vendor_error_log';
function record(error, info){
  try{
    const rows=JSON.parse(localStorage.getItem(KEY)||'[]');
    rows.unshift({id:crypto.randomUUID?.()||String(Date.now()),message:error?.message||String(error),stack:error?.stack||'',componentStack:info?.componentStack||'',createdAt:new Date().toISOString(),url:location.href});
    localStorage.setItem(KEY,JSON.stringify(rows.slice(0,100)));
  }catch{}
}

export default class ErrorBoundary extends React.Component{
  state={error:null};
  static getDerivedStateFromError(error){return {error};}
  componentDidCatch(error,info){record(error,info)}
  render(){
    if(!this.state.error)return this.props.children;
    return <div className="fatal-error"><div><h1>Backwoods Vendor App hit an error</h1><p>Your data was not intentionally deleted. The error was recorded in System Diagnostics.</p><pre>{this.state.error.message}</pre><button onClick={()=>location.reload()}>Reload app</button></div></div>;
  }
}

export function installGlobalErrorLogging(){
  const save=(message,stack='')=>record({message,stack},{});
  window.addEventListener('error',e=>save(e.message,e.error?.stack||''));
  window.addEventListener('unhandledrejection',e=>save(e.reason?.message||String(e.reason),e.reason?.stack||''));
}
