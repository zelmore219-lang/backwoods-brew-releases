import { useState } from 'react';
import { NavLink } from 'react-router-dom';
import {
  Activity,
  BadgeDollarSign,
  BarChart3,
  Bell,
  Boxes,
  CalendarDays,
  ClipboardList,
  CloudCog,
  Factory,
  FileText,
  History,
  Landmark,
  LayoutDashboard,
  LogOut,
  PackageCheck,
  Route,
  Rocket,
  ScanBarcode,
  Settings,
  Shuffle,
  ShoppingCart,
  Store,
  Truck,
  Upload,
  UserCog,
  Users
} from 'lucide-react';
import { useAuth } from '../auth/AuthContext';
import ConnectionStatus from './ConnectionStatus';

const defaultLogo = `${import.meta.env.BASE_URL}brand/backwoods-brew-brewfoot-logo.png`;

const navGroups = [
  {
    label: 'Home',
    items: [
      { to: '/portal', label: 'My Account', icon: Store, roles: ['customer'] },
      { to: '/', label: 'Dashboard', icon: LayoutDashboard },
      { to: '/notifications', label: 'Alerts', icon: Bell, roles: ['owner', 'manager', 'sales', 'packer', 'driver', 'accounting'] }
    ]
  },
  {
    label: 'Sales',
    items: [
      { to: '/customers', label: 'Stores', icon: Users, roles: ['owner', 'manager', 'sales', 'accounting'] },
      { to: '/orders', label: 'Orders', icon: ClipboardList, roles: ['owner', 'manager', 'sales'] },
      { to: '/sales-day', label: 'Today Route', icon: CalendarDays, roles: ['owner', 'manager', 'sales', 'driver'] },
      { to: '/routes', label: 'Routes', icon: Route, roles: ['owner', 'manager'] },
      { to: '/drivers', label: 'Drivers', icon: Truck, roles: ['owner', 'manager', 'driver'] }
    ]
  },
  {
    label: 'Warehouse',
    items: [
      { to: '/products', label: 'Products', icon: Boxes, roles: ['owner', 'manager', 'sales', 'packer', 'accounting'] },
      { to: '/packing', label: 'Packing', icon: PackageCheck, roles: ['owner', 'manager', 'packer'] },
      { to: '/suppliers', label: 'Suppliers', icon: Factory, roles: ['owner', 'manager', 'accounting'] },
      { to: '/purchasing', label: 'Purchasing', icon: ShoppingCart, roles: ['owner', 'manager', 'packer', 'accounting'] },
      { to: '/labels', label: 'Labels', icon: ScanBarcode, roles: ['owner', 'manager', 'packer'] },
      { to: '/scanner-test', label: 'Scanner Test', icon: ScanBarcode, roles: ['owner', 'manager', 'sales', 'packer'] }
    ]
  },
  {
    label: 'Office',
    items: [
      { to: '/invoices', label: 'Invoices', icon: FileText, roles: ['owner', 'manager', 'sales', 'driver', 'accounting'] },
      { to: '/credits', label: 'Credits', icon: BadgeDollarSign, roles: ['owner', 'manager', 'sales', 'driver', 'accounting'] },
      { to: '/receivables', label: 'Receivables', icon: Landmark, roles: ['owner', 'manager', 'accounting'] },
      { to: '/settlements', label: 'Settlements', icon: Landmark, roles: ['owner', 'manager', 'accounting'] },
      { to: '/reports', label: 'Reports', icon: BarChart3, roles: ['owner', 'manager', 'accounting'] },
      { to: '/sync-log', label: 'Sync Log', icon: Shuffle, roles: ['owner', 'manager', 'accounting'] }
    ]
  },
  {
    label: 'Admin',
    items: [
      { to: '/launch', label: 'Launch', icon: Rocket, roles: ['owner', 'manager', 'accounting'] },
      { to: '/imports', label: 'Imports', icon: Upload, roles: ['owner', 'manager'] },
      { to: '/users', label: 'Users', icon: UserCog, roles: ['owner'] },
      { to: '/audit', label: 'Audit', icon: History, roles: ['owner', 'manager'] },
      { to: '/backups', label: 'Backups', icon: CloudCog, roles: ['owner'] },
      { to: '/system', label: 'System', icon: Activity, roles: ['owner'] },
      { to: '/settings', label: 'Settings', icon: Settings, roles: ['owner'] }
    ]
  }
];

const canSee = (item, role) => role === 'customer'
  ? item.roles?.includes('customer')
  : (!item.roles || item.roles.includes(role));

export default function Layout({ children, company }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const { user, logout, firebaseEnabled } = useAuth();
  const appLogo = company.logo || defaultLogo;
  const groups = navGroups
    .map(group => ({ ...group, items: group.items.filter(item => canSee(item, user.role)) }))
    .filter(group => group.items.length);

  return <div className="app-shell">
    <header className="mobile-header no-print"><strong>{company.name}</strong><button type="button" aria-expanded={menuOpen} aria-controls="main-navigation" onClick={() => setMenuOpen(!menuOpen)}>{menuOpen ? 'Close menu' : 'Menu'}</button></header>
    <aside id="main-navigation" className={`sidebar ${menuOpen ? 'mobile-open' : ''}`}>
      <div className="brand">
        {appLogo ? <img src={appLogo} alt="Backwoods Brew logo"/> : <div className="brandmark">BB</div>}
        <div><strong>{company.name}</strong><span>Order Desk</span></div>
      </div>

      <div className="sidebar-scroll">
        <nav className="side-nav">
          {groups.map(group => <section className="nav-group" key={group.label}>
            <div className="nav-group-label">{group.label}</div>
            {group.items.map(({ to, label, icon: Icon }) => <NavLink key={to} to={to} end={to === '/'} onClick={() => setMenuOpen(false)}>
              <Icon size={17}/><span>{label}</span>
            </NavLink>)}
          </section>)}
        </nav>
      </div>

      <div className="sidebar-footer">
        <ConnectionStatus/>
        <div className="user-card">
          <div><strong>{user.name}</strong><small>{firebaseEnabled ? user.email : 'Local mode'}</small></div>
          <span>{user.role}</span>
        </div>
        <button className="logout-button" onClick={logout}><LogOut size={17}/>Sign out</button>
      </div>
    </aside>
    <main className="content">{children}</main>
  </div>;
}
