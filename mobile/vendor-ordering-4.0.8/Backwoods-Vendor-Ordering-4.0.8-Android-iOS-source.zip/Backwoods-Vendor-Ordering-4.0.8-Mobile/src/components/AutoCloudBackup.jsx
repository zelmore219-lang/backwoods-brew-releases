import { useEffect } from 'react';
import { useAuth } from '../auth/AuthContext';
import { makeId, now } from '../lib/helpers';
const KEYS=['company','users','customers','products','orders','credits','payments','inventoryMovements','routePlans','notifications','auditLogs','recurringOrders','driverSettlements'];
export default function AutoCloudBackup({data,update}){
 const {user}=useAuth();
 useEffect(()=>{
  if(user?.role!=='owner')return;
  const day=new Date().toISOString().slice(0,10);
  if((data.cloudBackups||[]).some(b=>b.day===day))return;
  const payload=JSON.stringify(Object.fromEntries(KEYS.map(k=>[k,data[k]])));
  if(payload.length>750000)return;
  update(d=>({...d,cloudBackups:[...(d.cloudBackups||[]),{id:makeId('backup'),day,createdAt:now(),kind:'automatic',recordCounts:Object.fromEntries(KEYS.filter(k=>Array.isArray(d[k])).map(k=>[k,d[k].length])),payload}]})).catch(()=>{});
 },[user?.role,data.cloudBackups]);
 return null;
}
