import { useEffect, useState } from 'react';
import { Cloud, CloudOff } from 'lucide-react';

export default function ConnectionStatus() {
  const [online, setOnline] = useState(navigator.onLine);

  useEffect(() => {
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    addEventListener('online', on);
    addEventListener('offline', off);
    return () => {
      removeEventListener('online', on);
      removeEventListener('offline', off);
    };
  }, []);

  return <div className={`connection-status ${online ? 'online' : 'offline'}`}>
    {online ? <Cloud size={14}/> : <CloudOff size={14}/>}
    {online ? 'Online' : 'Offline - sync later'}
  </div>;
}
