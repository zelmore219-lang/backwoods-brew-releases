import { useEffect, useRef } from 'react';
import JsBarcode from 'jsbarcode';
import { money, calcOrder } from '../lib/helpers';

function LineBarcode({ value }) {
  const ref = useRef(null);
  useEffect(() => {
    if (!ref.current || !value) return;
    try {
      JsBarcode(ref.current, String(value), { format: 'CODE128', displayValue: false, height: 34, margin: 2 });
    } catch {
      ref.current.textContent = '';
    }
  }, [value]);
  if (!value) return <span className="invoice-upc-empty">-</span>;
  return <span className="invoice-upc"><svg ref={ref}/><small>{value}</small></span>;
}

export default function InvoiceView({ order, customer, company }) {
  const totals = calcOrder(order);
  const delivered = (order.items || []).filter(item => Number(item.invoiceQty ?? item.deliveredQty ?? item.qty) > 0);
  const returned = (order.items || []).filter(item => Number(item.returnQty) > 0);
  const showSku = company.showSku !== false;
  const showUpc = [...delivered, ...returned].some(item => item.barcode || item.upc);
  const deliveredColSpan = (showSku ? 1 : 0) + (showUpc ? 1 : 0) + 4;
  const returnColSpan = (showSku ? 1 : 0) + (showUpc ? 1 : 0) + 5;

  return <div className="invoice" id={`invoice-${order.id}`}>
    <div className="invoice-head">
      <div>
        {company.logo && <img className="invoice-logo" src={company.logo} alt="logo"/>}
        <h1>{company.name}</h1>
        <p>{[company.address, [company.city, company.state, company.zip].filter(Boolean).join(' ')].filter(Boolean).map((line, index) => <span key={index}>{line}<br/></span>)}{company.phone}<br/>{company.email}</p>
      </div>
      <div className="invoice-meta"><h2>INVOICE</h2><p><b>{order.invoiceNumber || order.orderNumber}</b><br/>Date: {new Date(order.createdAt).toLocaleDateString()}<br/>Status: {order.status}</p></div>
    </div>

    <div className="invoice-grid">
      <div><b>Bill To</b><p>{customer?.name}<br/>{customer?.contact}<br/>{customer?.address}<br/>{customer?.phone}</p></div>
      <div><b>Terms</b><p>{customer?.terms}<br/>Salesperson: {order.salesperson || 'Unassigned'}<br/>Driver: {order.driver || 'Unassigned'}</p></div>
    </div>

    <h3>Merchandise delivered</h3>
    <table>
      <thead><tr>{showSku && <th>SKU</th>}{showUpc && <th>UPC</th>}<th>Description</th><th>Qty brought in</th><th>Price</th><th>Total</th></tr></thead>
      <tbody>{delivered.map(item => {
        const qty = Number(item.invoiceQty ?? item.deliveredQty ?? item.qty);
        const upc = item.upc || item.barcode || '';
        return <tr key={item.productId}>
          {showSku && <td>{item.sku}</td>}
          {showUpc && <td><LineBarcode value={upc}/></td>}
          <td>{item.name}</td>
          <td>{qty}</td>
          <td>{money(item.price)}</td>
          <td>{money(qty * Number(item.price))}</td>
        </tr>;
      })}
      {!delivered.length && <tr><td colSpan={deliveredColSpan}>No merchandise delivered.</td></tr>}</tbody>
    </table>

    <h3 className="invoice-return-heading">Returns from store</h3>
    <table className="invoice-returns">
      <thead><tr>{showSku && <th>SKU</th>}{showUpc && <th>UPC</th>}<th>Description</th><th>Qty returned</th><th>Credit each</th><th>Reason / disposition</th><th>Credit</th></tr></thead>
      <tbody>{returned.map(item => {
        const upc = item.upc || item.barcode || '';
        const credit = Number(item.returnQty) * Number(item.returnPrice ?? item.price) * (Number(item.returnCreditPercent ?? 100) / 100);
        return <tr key={item.productId}>
          {showSku && <td>{item.sku}</td>}
          {showUpc && <td><LineBarcode value={upc}/></td>}
          <td>{item.name}</td>
          <td>{Number(item.returnQty)}</td>
          <td>{money(item.returnPrice ?? item.price)}</td>
          <td>{item.returnReason || 'Return'}<small>{(item.returnDisposition || 'sellable').replaceAll('_', ' ')} - {Number(item.returnCreditPercent ?? 100)}% credit</small></td>
          <td>-{money(credit)}</td>
        </tr>;
      })}
      {!returned.length && <tr><td colSpan={returnColSpan}>No returns.</td></tr>}</tbody>
    </table>

    <div className="totals">
      <p><span>Delivered merchandise</span><b>{money(totals.subtotal)}</b></p>
      <p><span>Returns</span><b>-{money(totals.returnTotal)}</b></p>
      <p><span>Other credits</span><b>-{money(totals.creditTotal)}</b></p>
      <p><span>Tax</span><b>{money(totals.tax)}</b></p>
      <p className="grand"><span>Net invoice total</span><b>{money(totals.total)}</b></p>
      <p><span>Paid</span><b>{money(totals.paid)}</b></p>
      <p className="grand"><span>Balance</span><b>{money(totals.balance)}</b></p>
    </div>

    {order.deliveryNotes && <p><b>Delivery notes:</b> {order.deliveryNotes}</p>}
    {company.paymentInstructions && <p><b>Payment instructions:</b> {company.paymentInstructions}</p>}
    {company.showSignature !== false && order.signature && <div className="signature"><b>Received by:</b><br/><img src={order.signature} alt="signature"/><p>{order.signedBy || ''}</p></div>}
    <p className="invoice-note">{company.invoiceFooter || 'Thank you for your business.'}</p>
  </div>;
}
