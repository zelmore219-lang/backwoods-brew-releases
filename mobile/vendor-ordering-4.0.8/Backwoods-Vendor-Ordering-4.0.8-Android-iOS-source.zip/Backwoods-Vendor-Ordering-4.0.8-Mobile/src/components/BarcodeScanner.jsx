import { BrowserMultiFormatReader } from '@zxing/browser';
import { useEffect, useRef, useState } from 'react';

export default function BarcodeScanner({ onScan, placeholder='Scan barcode or type code', autoFocus=true }) {
  const [value,setValue]=useState('');
  const [cameraOpen,setCameraOpen]=useState(false);
  const [error,setError]=useState('');
  const [hint,setHint]=useState('');
  const [devices,setDevices]=useState([]);
  const [selectedDeviceId,setSelectedDeviceId]=useState('');
  const videoRef=useRef(null);
  const streamRef=useRef(null);
  const detectorRef=useRef(null);
  const frameRef=useRef(null);
  const zxingReaderRef=useRef(null);
  const zxingControlsRef=useRef(null);
  const scanLockedRef=useRef(false);

  const resetScanLock=()=>setTimeout(()=>{scanLockedRef.current=false;},250);

  const stopCamera=()=>{
    zxingControlsRef.current?.stop?.();
    zxingControlsRef.current=null;
    zxingReaderRef.current=null;
    streamRef.current?.getTracks().forEach(t=>t.stop());
    streamRef.current=null;
    detectorRef.current=null;
    if(frameRef.current)cancelAnimationFrame(frameRef.current);
    frameRef.current=null;
    setCameraOpen(false);
    setHint('');
  };

  const acceptScan=code=>{
    const clean=String(code||'').trim();
    if(!clean||scanLockedRef.current)return;
    scanLockedRef.current=true;
    onScan(clean);
    setValue('');
    stopCamera();
    resetScanLock();
  };

  const submit=()=>acceptScan(value);

  const loadDevices=async()=>{
    if(!navigator.mediaDevices?.enumerateDevices)return [];
    try{
      const cameras=(await navigator.mediaDevices.enumerateDevices()).filter(device=>device.kind==='videoinput');
      setDevices(cameras);
      if(!selectedDeviceId&&cameras.length){
        const preferred=cameras.find(device=>/back|rear|environment/i.test(device.label))||cameras[0];
        setSelectedDeviceId(preferred.deviceId);
      }
      return cameras;
    }catch{return [];}
  };

  useEffect(()=>{loadDevices();return()=>stopCamera();},[]);

  const waitForVideo=()=>new Promise((resolve,reject)=>{
    let attempts=0;
    const check=()=>{
      if(videoRef.current){resolve(videoRef.current);return;}
      attempts+=1;
      if(attempts>20){reject(new Error('Camera preview could not start.'));return;}
      setTimeout(check,25);
    };
    check();
  });

  const scanFrame=async()=>{
    if(!videoRef.current||!detectorRef.current)return;
    try{
      const found=await detectorRef.current.detect(videoRef.current);
      if(found?.[0]?.rawValue){acceptScan(found[0].rawValue);return;}
    }catch{}
    frameRef.current=requestAnimationFrame(scanFrame);
  };

  const startNativeCamera=async()=>{
    detectorRef.current=new window.BarcodeDetector({formats:['code_128','ean_13','ean_8','upc_a','upc_e','qr_code']});
    const videoRequest=selectedDeviceId?{deviceId:{exact:selectedDeviceId}}:{facingMode:{ideal:'environment'}};
    const stream=await navigator.mediaDevices.getUserMedia({video:videoRequest});
    streamRef.current=stream;
    setCameraOpen(true);
    setHint('Camera ready. Hold the UPC steady inside the preview.');
    const video=await waitForVideo();
    video.srcObject=stream;
    await video.play();
    loadDevices();
    scanFrame();
  };

  const startZxingCamera=async()=>{
    const reader=new BrowserMultiFormatReader();
    zxingReaderRef.current=reader;
    setCameraOpen(true);
    setHint('Camera ready. Hold the UPC steady inside the preview.');
    const video=await waitForVideo();
    const videoRequest=selectedDeviceId?{deviceId:{exact:selectedDeviceId}}:{facingMode:{ideal:'environment'}};
    const controls=await reader.decodeFromConstraints(
      {video:videoRequest},
      video,
      result=>{
        const text=result?.getText?.();
        if(text)acceptScan(text);
      }
    );
    zxingControlsRef.current=controls;
    loadDevices();
  };

  const startCamera=async()=>{
    setError('');
    setHint('');
    scanLockedRef.current=false;
    if(!navigator.mediaDevices?.getUserMedia){setError('This device does not allow camera access. A USB/Bluetooth scanner still works.');return;}
    await loadDevices();
    try{
      if('BarcodeDetector' in window){await startNativeCamera();return;}
    }catch{}
    stopCamera();
    try{
      await startZxingCamera();
    }catch(e){
      stopCamera();
      setError(e.message||'Could not open camera. A USB/Bluetooth scanner still works.');
    }
  };

  return <div className="barcode-scanner">
    <div className="scanner-row"><input autoFocus={autoFocus} value={value} onChange={e=>setValue(e.target.value)} onKeyDown={e=>{if(e.key==='Enter'){e.preventDefault();submit();}}} placeholder={placeholder}/><button type="button" onClick={submit}>Scan</button><button type="button" className="secondary" onClick={cameraOpen?stopCamera:startCamera}>{cameraOpen?'Close camera':'Use camera'}</button></div>
    {devices.length>1&&<label className="scanner-device">Camera<select value={selectedDeviceId} disabled={cameraOpen} onChange={event=>setSelectedDeviceId(event.target.value)}>{devices.map((device,index)=><option key={device.deviceId||index} value={device.deviceId}>{device.label||`Camera ${index+1}`}</option>)}</select></label>}
    {cameraOpen&&<video ref={videoRef} className="scanner-video" muted playsInline/>}
    {hint&&<small className="scanner-hint">{hint}</small>}
    {error&&<small className="scanner-error">{error}</small>}
  </div>;
}
