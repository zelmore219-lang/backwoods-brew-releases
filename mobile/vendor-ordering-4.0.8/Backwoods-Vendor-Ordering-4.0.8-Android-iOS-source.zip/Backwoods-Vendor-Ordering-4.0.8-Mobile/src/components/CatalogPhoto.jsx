import { Image } from 'lucide-react';
import { catalogInitials, catalogPhoto } from '../lib/catalog';

export default function CatalogPhoto({ product, className = '' }) {
  const photo = catalogPhoto(product);
  const classes = `catalog-photo ${className}`.trim();
  if (photo) return <img className={classes} src={photo} alt={product?.name || 'Product photo'}/>;
  return <div className={`${classes} placeholder`} aria-label="No product photo">
    <Image size={18}/>
    <span>{catalogInitials(product)}</span>
  </div>;
}
