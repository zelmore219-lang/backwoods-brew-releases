import React from 'react';
import ReactDOM from 'react-dom/client';
import { HashRouter } from 'react-router-dom';
import { AuthProvider } from './auth/AuthContext';
import App from './App';
import ErrorBoundary, { installGlobalErrorLogging } from './components/ErrorBoundary';
import './styles.css';
import './mobile.css';
import { initializeMobile } from './lib/mobile';

initializeMobile();

installGlobalErrorLogging();

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <HashRouter>
      <ErrorBoundary><AuthProvider>
        <App />
      </AuthProvider></ErrorBoundary>
    </HashRouter>
  </React.StrictMode>
);
