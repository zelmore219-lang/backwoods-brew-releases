import { money, calcOrder } from '../lib/helpers';

const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

export default function Dashboard({ data }) {
  const today = days[new Date().getDay()];
  const orders = data.orders || [];
  const products = data.products || [];
  const open = orders.filter(order => !['completed', 'cancelled', 'void'].includes(order.status));
  const submitted = orders.filter(order => order.status === 'submitted');
  const packing = orders.filter(order => order.status === 'packing');
  const packed = orders.filter(order => order.status === 'packed');
  const delivery = orders.filter(order => order.status === 'out_for_delivery');
  const receivable = orders.reduce((sum, order) => sum + calcOrder(order).balance, 0);
  const routeCount = (data.routePlans || []).filter(route => route.dayOfWeek === today).length;
  const lowStock = products
    .map(product => ({ ...product, available: Number(product.onHand || 0) - Number(product.reserved || 0) }))
    .filter(product => product.available <= Number(product.reorderLevel || 30))
    .sort((a, b) => a.available - b.available);
  const recent = [...orders].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, 7);

  return <>
    <div className="page-head"><div><h1>Operations Dashboard</h1><p>Orders, inventory pressure, delivery readiness, and collections.</p></div></div>

    <div className="stats">
      <div className="card"><span>Open orders</span><strong>{open.length}</strong></div>
      <div className="card"><span>Ready to pack</span><strong>{submitted.length}</strong></div>
      <div className="card"><span>Ready to deliver</span><strong>{packed.length}</strong></div>
      <div className="card"><span>Receivables</span><strong>{money(receivable)}</strong></div>
    </div>

    <div className="dashboard-grid">
      <section className="panel">
        <div className="panel-title"><div><h2>Workflow</h2><p>{today} routes: {routeCount}</p></div></div>
        <div className="workflow-list">
          <div><span>Submitted</span><strong>{submitted.length}</strong><small>Waiting for warehouse</small></div>
          <div><span>Packing</span><strong>{packing.length}</strong><small>In progress</small></div>
          <div><span>Driver queue</span><strong>{packed.length + delivery.length}</strong><small>Packed or loaded</small></div>
          <div><span>Low stock</span><strong>{lowStock.length}</strong><small>At or below reorder level</small></div>
        </div>
      </section>

      <section className="panel">
        <div className="panel-title"><div><h2>Low Stock</h2><p>Available inventory after reservations.</p></div></div>
        <table>
          <thead><tr><th>Product</th><th>Available</th><th>Location</th></tr></thead>
          <tbody>{lowStock.slice(0, 8).map(product => <tr key={product.id} className="low-stock">
            <td><b>{product.name}</b><small>{product.sku}</small></td>
            <td>{product.available}<small>Reorder {product.reorderLevel || 30}</small></td>
            <td>{product.location || 'Unassigned'}</td>
          </tr>)}</tbody>
        </table>
        {!lowStock.length && <p className="empty compact">Inventory is above reorder levels.</p>}
      </section>

      <section className="panel span-2">
        <div className="panel-title"><div><h2>Recent Orders</h2><p>Newest order activity across stores.</p></div></div>
        <table>
          <thead><tr><th>Order</th><th>Store</th><th>Status</th><th>Delivered</th><th>Returned</th><th>Total</th></tr></thead>
          <tbody>{recent.map(order => {
            const totals = calcOrder(order);
            return <tr key={order.id}>
              <td><b>{order.orderNumber}</b><small>{order.invoiceNumber}</small></td>
              <td>{data.customers.find(customer => customer.id === order.customerId)?.name || 'Unknown'}</td>
              <td><span className="status">{String(order.status || '').replaceAll('_', ' ')}</span></td>
              <td>{(order.items || []).reduce((sum, item) => sum + Number(item.qty || item.deliveredQty || 0), 0)}</td>
              <td>{(order.items || []).reduce((sum, item) => sum + Number(item.returnQty || 0), 0)}</td>
              <td><b>{money(totals.total)}</b></td>
            </tr>;
          })}</tbody>
        </table>
        {!recent.length && <p className="empty compact">No order activity yet.</p>}
      </section>
    </div>
  </>;
}
