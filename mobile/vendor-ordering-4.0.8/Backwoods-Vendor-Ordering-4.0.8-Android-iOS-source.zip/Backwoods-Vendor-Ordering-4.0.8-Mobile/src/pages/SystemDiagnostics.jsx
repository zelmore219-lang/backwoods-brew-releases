import { useMemo, useRef, useState } from 'react';
import { AlertTriangle, CheckCircle2, DatabaseBackup, Download, HardDriveDownload, RefreshCw, ShieldCheck, Upload } from 'lucide-react';
import { calcOrder } from '../lib/helpers';

const ERROR_KEY='backwoods_vendor_error_log';
const requiredLists=['users','customers','products','orders','credits','payments','inventoryMovements','routePlans','notifications','auditLogs'];
const download=(name,text,type='application/json')=>{const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([text],{type}));a.download=name;a.click();URL.revokeObjectURL(a.href)};

export default function SystemDiagnostics({data,update,firebaseEnabled,ready,error}){
  const input=useRef(); const [message,setMessage]=useState('');
  const errors=useMemo(()=>{try{return JSON.parse(localStorage.getItem(ERROR_KEY)||'[]')}catch{return[]}},[message]);
  const checks=useMemo(()=>{
    const duplicateInvoices=findDuplicates((data.orders||[]).map(x=>x.invoiceNumber).filter(Boolean));
    const duplicateOrders=findDuplicates((data.orders||[]).map(x=>x.orderNumber).filter(Boolean));
    const brokenCustomer=(data.orders||[]).filter(o=>!data.customers.some(c=>c.id===o.customerId));
    const brokenProducts=(data.orders||[]).flatMap(o=>(o.items||[]).filter(i=>!data.products.some(p=>p.id===i.productId)).map(i=>`${o.orderNumber}: ${i.name||i.productId}`));
    const negativeInventory=(data.products||[]).filter(p=>Number(p.onHand)<0||Number(p.reserved)<0||Number(p.reserved)>Number(p.onHand));
    const invalidMoney=(data.orders||[]).filter(o=>!Number.isFinite(calcOrder(o).total)||calcOrder(o).total<0);
    return [
      check('Database connection',firebaseEnabled?(ready?'Connected to Firebase':'Firebase is still loading'):'Local demo storage active',firebaseEnabled?ready:true),
      check('Required collections',requiredLists.every(k=>Array.isArray(data[k]))?'All data collections loaded':'One or more collections are missing',requiredLists.every(k=>Array.isArray(data[k]))),
      check('Invoice numbering',duplicateInvoices.length?`Duplicate invoices: ${duplicateInvoices.join(', ')}`:'No duplicate invoice numbers',!duplicateInvoices.length),
      check('Order numbering',duplicateOrders.length?`Duplicate orders: ${duplicateOrders.join(', ')}`:'No duplicate order numbers',!duplicateOrders.length),
      check('Customer links',brokenCustomer.length?`${brokenCustomer.length} order(s) have missing customers`:'All orders have valid customers',!brokenCustomer.length),
      check('Product links',brokenProducts.length?`${brokenProducts.length} order line(s) have missing products`:'All order lines have valid products',!brokenProducts.length),
      check('Inventory integrity',negativeInventory.length?`${negativeInventory.length} product(s) have invalid stock values`:'Inventory values are valid',!negativeInventory.length),
      check('Invoice calculations',invalidMoney.length?`${invalidMoney.length} invoice(s) have invalid totals`:'Invoice totals calculate correctly',!invalidMoney.length),
      check('Runtime errors',errors.length?`${errors.length} recorded browser error(s)`:'No recorded browser errors',!errors.length),
      check('Store sync errors',error||'No synchronization errors',!error)
    ];
  },[data,firebaseEnabled,ready,error,errors.length]);
  const passed=checks.filter(x=>x.ok).length;

  const exportBackup=()=>{
    const payload={schemaVersion:3,app:'Backwoods Vendor Ordering',exportedAt:new Date().toISOString(),data};
    download(`backwoods-vendor-backup-${new Date().toISOString().slice(0,10)}.json`,JSON.stringify(payload,null,2));
    setMessage('Backup downloaded. Store a copy somewhere outside this computer.');
  };
  const importBackup=async e=>{
    const file=e.target.files?.[0]; if(!file)return;
    try{
      const parsed=JSON.parse(await file.text()); const incoming=parsed.data||parsed;
      if(!incoming.company||!Array.isArray(incoming.orders)||!Array.isArray(incoming.products))throw new Error('This is not a valid Backwoods Vendor backup.');
      if(!confirm(`Restore backup from ${parsed.exportedAt||'unknown date'}? Current app data will be replaced.`))return;
      await update({...data,...incoming,auditLogs:[...(incoming.auditLogs||[]),{id:crypto.randomUUID(),entityType:'system',entityId:'backup',action:'Backup restored',details:`Restored from ${file.name}`,createdAt:new Date().toISOString(),actor:'Owner'}]});
      setMessage('Backup restored successfully.');
    }catch(err){setMessage(`Restore failed: ${err.message}`)} finally{e.target.value=''}
  };
  const exportErrors=()=>download('backwoods-error-log.json',JSON.stringify(errors,null,2));
  const clearErrors=()=>{localStorage.removeItem(ERROR_KEY);setMessage('Recorded browser errors cleared.');};
  const exportCsv=()=>{
    const rows=[['Invoice','Order','Customer','Status','Total','Balance'],...(data.orders||[]).map(o=>{const t=calcOrder(o);return[o.invoiceNumber,o.orderNumber,data.customers.find(c=>c.id===o.customerId)?.name||'',o.status,t.total,t.balance]})];
    download('backwoods-invoice-export.csv',rows.map(r=>r.map(v=>`"${String(v??'').replaceAll('"','""')}"`).join(',')).join('\n'),'text/csv');
  };

  return <>
    <div className="page-head"><div><h1>System Diagnostics</h1><p>Back up business data, check data integrity, and review app errors.</p></div><button onClick={()=>location.reload()}><RefreshCw size={17}/> Recheck app</button></div>
    {message&&<div className="notice">{message}</div>}
    <div className="stats diagnostics-stats"><div className="card"><span>Checks passed</span><strong>{passed}/{checks.length}</strong></div><div className="card"><span>Storage mode</span><strong className="text-value">{firebaseEnabled?'Firebase':'Local'}</strong></div><div className="card"><span>Orders protected</span><strong>{data.orders.length}</strong></div><div className="card"><span>Recorded errors</span><strong>{errors.length}</strong></div></div>
    <div className="diagnostics-grid">
      <section className="panel"><h2><ShieldCheck size={20}/> Health check</h2><div className="health-list">{checks.map(x=><div className={x.ok?'health-row ok':'health-row bad'} key={x.name}>{x.ok?<CheckCircle2 size={19}/>:<AlertTriangle size={19}/>}<div><b>{x.name}</b><span>{x.detail}</span></div></div>)}</div></section>
      <section className="panel"><h2><DatabaseBackup size={20}/> Backup and recovery</h2><p>Download a complete JSON backup before major updates. Restore only from a trusted backup file.</p><div className="stack-actions"><button onClick={exportBackup}><Download size={17}/> Download full backup</button><button className="secondary" onClick={()=>input.current?.click()}><Upload size={17}/> Restore backup</button><input ref={input} hidden type="file" accept="application/json,.json" onChange={importBackup}/><button className="secondary" onClick={exportCsv}><HardDriveDownload size={17}/> Export invoice CSV</button></div></section>
      <section className="panel span-2"><h2><AlertTriangle size={20}/> Error recovery log</h2>{errors.length?<><div className="table-scroll"><table><thead><tr><th>Date</th><th>Message</th><th>Location</th></tr></thead><tbody>{errors.slice(0,25).map(e=><tr key={e.id}><td>{new Date(e.createdAt).toLocaleString()}</td><td><b>{e.message}</b><small>{e.stack?.split('\n')[0]}</small></td><td>{e.url||'—'}</td></tr>)}</tbody></table></div><div className="actions"><button className="secondary" onClick={exportErrors}>Download errors</button><button className="danger" onClick={clearErrors}>Clear errors</button></div></>:<p className="empty">No browser errors have been recorded.</p>}</section>
    </div>
  </>;
}
function check(name,detail,ok){return{name,detail,ok}}
function findDuplicates(values){const seen=new Set(),dupes=new Set();for(const v of values){if(seen.has(v))dupes.add(v);seen.add(v)}return[...dupes]}
