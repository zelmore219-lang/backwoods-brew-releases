import { useMemo, useState } from 'react';
import { Download, Search } from 'lucide-react';

export default function AuditLog({data}){
  const [query,setQuery]=useState(''); const [type,setType]=useState('all');
  const logs=useMemo(()=>{
    const direct=data.auditLogs||[];
    const orderLogs=(data.orders||[]).flatMap(o=>(o.auditTrail||o.auditLogs||[]).map((x,i)=>({id:`${o.id}-${i}`,entityType:'invoice/order',entityId:o.invoiceNumber||o.orderNumber||o.id,action:x.action||x.reason||'Order changed',details:x.details||x.changes||'',createdAt:x.createdAt||x.date,actor:x.actor||x.user||'System'})));
    return [...direct,...orderLogs].sort((a,b)=>new Date(b.createdAt||0)-new Date(a.createdAt||0));
  },[data]);
  const filtered=logs.filter(l=>(type==='all'||l.entityType===type)&&`${l.action} ${l.details} ${l.entityId} ${l.actor}`.toLowerCase().includes(query.toLowerCase()));
  const types=[...new Set(logs.map(l=>l.entityType).filter(Boolean))];
  const csv=()=>{const rows=[['Date','Actor','Type','Record','Action','Details'],...filtered.map(l=>[l.createdAt,l.actor,l.entityType,l.entityId,l.action,l.details])];const content=rows.map(r=>r.map(v=>`"${String(v??'').replaceAll('"','""')}"`).join(',')).join('\n');const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([content],{type:'text/csv'}));a.download=`audit-log-${new Date().toISOString().slice(0,10)}.csv`;a.click();URL.revokeObjectURL(a.href)};
  return <><div className="page-head"><div><h1>Audit Log</h1><p>Review important changes to invoices, orders, users, inventory, and settings.</p></div><button onClick={csv}><Download size={17}/> Export CSV</button></div>
    <div className="panel"><div className="audit-filters"><label><Search size={15}/> Search<input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Invoice, user, action, or details"/></label><label>Record type<select value={type} onChange={e=>setType(e.target.value)}><option value="all">All types</option>{types.map(t=><option key={t}>{t}</option>)}</select></label></div></div>
    <div className="panel"><div className="panel-title"><h2>Activity</h2><span className="status">{filtered.length} records</span></div><div className="table-scroll"><table><thead><tr><th>Date</th><th>User</th><th>Type</th><th>Record</th><th>Action</th><th>Details</th></tr></thead><tbody>{filtered.map(l=><tr key={l.id}><td>{l.createdAt?new Date(l.createdAt).toLocaleString():'—'}</td><td>{l.actor||'System'}</td><td><span className="status">{l.entityType||'general'}</span></td><td>{l.entityId||'—'}</td><td><b>{l.action}</b></td><td>{typeof l.details==='string'?l.details:JSON.stringify(l.details||'')}</td></tr>)}{!filtered.length&&<tr><td colSpan="6" className="empty">No matching audit activity.</td></tr>}</tbody></table></div></div>
  </>;
}
