import { Link } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';

export default function Unauthorized(){
  const { user, logout } = useAuth();
  return <div className="auth-page"><div className="auth-card">
    <h1>Access unavailable</h1>
    <p>{user?.role === 'pending' ? 'Your account exists, but an owner must assign your role in Firestore.' : 'Your role does not have permission to open this section.'}</p>
    <div className="actions"><Link className="link-button" to="/">Go to dashboard</Link><button className="secondary" onClick={logout}>Sign out</button></div>
  </div></div>;
}
