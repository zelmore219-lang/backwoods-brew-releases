import { useMemo, useState } from 'react';
import Modal from '../components/Modal';
import BarcodeScanner from '../components/BarcodeScanner';
import { now } from '../lib/helpers';

const lineState = (item, product, orderStatus = 'submitted') => {
  const orderedQty = Number(item.orderedQty ?? item.qty ?? 0);
  const packedQty = Number(item.packedQty ?? (orderStatus === 'packed' ? orderedQty : 0));
  const shortQty = Number(item.shortQty ?? Math.max(0, orderedQty - packedQty));
  return {
    ...item,
    orderedQty,
    packedQty,
    shortQty,
    packStatus: item.packStatus || (packedQty >= orderedQty ? 'packed' : 'pending'),
    shortageReason: item.shortageReason || '',
    substitution: item.substitution || '',
    stockException: item.stockException || '',
    availableAtOrder: Number(item.availableAtOrder || 0),
    location: product?.location || item.location || 'Unassigned'
  };
};

const normalizePackingLine = line => {
  const orderedQty = Number(line.orderedQty || 0);
  const packedQty = Math.max(0, Math.min(Number(line.packedQty || 0), orderedQty));
  const shortQty = Math.max(0, orderedQty - packedQty);
  const shortageReason = shortQty > 0 ? String(line.shortageReason || '').trim() : '';
  return {
    ...line,
    orderedQty,
    packedQty,
    shortQty,
    shortageReason,
    packStatus: shortQty > 0 ? 'short' : 'packed'
  };
};

export default function Packing({ data, update }) {
  const [selected, setSelected] = useState(null);
  const [lines, setLines] = useState([]);
  const [packer, setPacker] = useState('Warehouse Packer');
  const [notes, setNotes] = useState('');
  const [error, setError] = useState('');
  const [lastScan, setLastScan] = useState('');

  const orders = data.orders.filter(o => ['submitted', 'packing', 'packed'].includes(o.status));
  const customer = selected ? data.customers.find(c => c.id === selected.customerId) : null;

  const totals = useMemo(() => lines.reduce((a, line) => ({
    ordered: a.ordered + Number(line.orderedQty || 0),
    packed: a.packed + Number(line.packedQty || 0),
    short: a.short + Number(line.shortQty || 0)
  }), { ordered: 0, packed: 0, short: 0 }), [lines]);

  const openOrder = order => {
    setSelected(order);
    setLines(order.items.filter(item => Number(item.qty || 0) > 0).map(item => lineState(item, data.products.find(p => p.id === item.productId), order.status)));
    setPacker(order.packer || 'Warehouse Packer');
    setNotes(order.packingNotes || '');
    setError('');
  };

  const changePacked = (productId, value) => setLines(current => current.map(line => {
    if (line.productId !== productId) return line;
    const packedQty = Math.max(0, Math.min(Number(value || 0), Number(line.orderedQty)));
    const shortQty = Number(line.orderedQty) - packedQty;
    return { ...line, packedQty, shortQty, packStatus: shortQty > 0 ? 'short' : 'packed' };
  }));

  const scanProduct = code => {
    const product = data.products.find(p => [p.barcode,p.sku].filter(Boolean).some(v => String(v).toLowerCase() === String(code).toLowerCase()));
    if (!product) { setError(`Barcode ${code} was not found.`); return; }
    const line = lines.find(x => x.productId === product.id);
    if (!line) { setError(`${product.name} is not on this order.`); return; }
    if (line.packedQty >= line.orderedQty) { setError(`${product.name} is already fully packed.`); return; }
    changePacked(product.id, Number(line.packedQty || 0) + 1);
    setLastScan(`${product.name} packed (${Number(line.packedQty || 0) + 1}/${line.orderedQty})`);
    setError('');
  };

  const setLine = (productId, patch) => setLines(current => current.map(line => line.productId === productId ? { ...line, ...patch } : line));
  const leaveOff = productId => setLines(current => current.map(line => {
    if (line.productId !== productId) return line;
    return {
      ...line,
      packedQty: 0,
      shortQty: Number(line.orderedQty || 0),
      packStatus: 'short',
      shortageReason: line.shortageReason || 'Out of stock'
    };
  }));

  const saveProgress = complete => {
    setError('');
    const packedLines = lines.map(normalizePackingLine);
    if (!packer.trim()) return setError('Enter the packer name.');
    const missingReason = packedLines.filter(line => line.shortQty > 0 && !line.shortageReason);
    if (complete && missingReason.length) {
      return setError(`Choose a shortage reason for: ${missingReason.map(line => line.name).join(', ')}.`);
    }

    update(d => {
      const original = d.orders.find(o => o.id === selected.id);
      const products = complete ? d.products.map(product => {
        const before = original.items.find(item => item.productId === product.id);
        const after = packedLines.find(item => item.productId === product.id);
        if (!before || !after) return product;
        const release = Math.max(0, Number(before.orderedUnits ?? before.qty ?? 0) - Number(after.packedQty || 0));
        return { ...product, reserved: Math.max(0, Number(product.reserved || 0) - release) };
      }) : d.products;

      const ordersUpdated = d.orders.map(order => order.id === selected.id ? {
        ...order,
        status: complete ? 'packed' : 'packing',
        packer: packer.trim(),
        packingNotes: notes,
        packingStartedAt: order.packingStartedAt || now(),
        packedAt: complete ? now() : order.packedAt,
        items: packedLines.map(({ location, ...line }) => ({
          ...line,
          qty: Number(line.orderedQty),
          deliveredQty: complete ? Number(line.packedQty || 0) : line.deliveredQty,
          invoiceQty: complete ? Number(line.packedQty || 0) : line.invoiceQty
        })),
        updatedAt: now()
      } : order);
      return { ...d, products, orders: ordersUpdated };
    });
    setSelected(null);
  };

  return <>
    <div className="page-head"><div><h1>Packing Queue</h1><p>Assign packers, verify every line, record shortages, and release completed orders to drivers.</p></div></div>
    <div className="packing-summary">
      <div className="card"><span>Waiting</span><strong>{orders.filter(o => o.status === 'submitted').length}</strong></div>
      <div className="card"><span>In progress</span><strong>{orders.filter(o => o.status === 'packing').length}</strong></div>
      <div className="card"><span>Ready for drivers</span><strong>{orders.filter(o => o.status === 'packed').length}</strong></div>
    </div>
    <div className="grid-cards">{orders.map(order => {
      const packed = order.items.reduce((sum, item) => sum + Number(item.packedQty ?? (order.status === 'packed' ? item.qty : 0)), 0);
      const ordered = order.items.reduce((sum, item) => sum + Number(item.qty || 0), 0);
      return <div className="panel" key={order.id}>
        <div className="panel-title"><div><h3>{order.orderNumber}</h3><p>{data.customers.find(c => c.id === order.customerId)?.name}</p></div><span className="status">{order.status.replaceAll('_', ' ')}</span></div>
        <div className="packing-progress"><span style={{ width: `${ordered ? Math.min(100, packed / ordered * 100) : 0}%` }} /></div>
        <p><b>{packed} of {ordered}</b> units packed</p>
        <small>{order.packer ? `Assigned to ${order.packer}` : 'Not assigned'} · {order.items.length} product lines</small>
        <div className="actions"><button className="secondary" onClick={() => openOrder(order)}>{order.status === 'packed' ? 'Review / print' : order.status === 'packing' ? 'Continue packing' : 'Start packing'}</button></div>
      </div>;
    })}</div>
    {!orders.length && <div className="panel empty">No orders are waiting for packing.</div>}

    {selected && <Modal title={`${selected.orderNumber} packing worksheet`} wide onClose={() => setSelected(null)}>
      {error && <div className="alert">{error}</div>}
      <div className="packing-slip" id="packing-slip">
        <div className="packing-slip-head"><div><h2>{data.company.name}</h2><p>Warehouse Packing Slip</p></div><div><b>{selected.orderNumber}</b><small>{selected.invoiceNumber}</small></div></div>
        <div className="packing-customer"><div><small>SHIP TO</small><b>{customer?.name}</b><span>{customer?.address}</span></div><div><small>ORDER NOTES</small><span>{selected.notes || 'None'}</span></div></div>
        <div className="no-print scan-pack-box"><h3>Scan items into this order</h3><BarcodeScanner onScan={scanProduct}/>{lastScan&&<div className="success-note">{lastScan}</div>}</div>
        <div className="form-grid no-print"><label>Packer name<input value={packer} onChange={e => setPacker(e.target.value)} /></label><label>Warehouse notes<input value={notes} onChange={e => setNotes(e.target.value)} placeholder="Pallet, tote, temperature, or loading notes" /></label></div>
        <div className="packing-table-wrap"><table><thead><tr><th>Location</th><th>Product</th><th>Ordered</th><th>Packed</th><th>Short</th><th>Status / reason</th></tr></thead><tbody>{lines.map(line => <tr key={line.productId} className={line.shortQty ? 'short-line' : ''}>
          <td><b>{line.location}</b></td><td><b>{line.name}</b><small>{line.sku}{line.stockException ? ` - ordered with ${line.availableAtOrder} available` : ''}</small></td><td>{line.orderedQty}</td>
          <td><input className="qty no-print" type="number" min="0" max={line.orderedQty} value={line.packedQty} onChange={e => changePacked(line.productId, e.target.value)} /><span className="print-only">{line.packedQty}</span></td>
          <td><b>{line.shortQty}</b></td><td>
            <button type="button" className="small secondary no-print leave-off-button" onClick={() => leaveOff(line.productId)}>Leave off</button>
            <select className="no-print" value={line.shortageReason} onChange={e => setLine(line.productId, { shortageReason: e.target.value })}><option value="">No shortage</option><option>Out of stock</option><option>Damaged</option><option>Expired</option><option>Count discrepancy</option><option>Other</option></select>
            <input className="no-print" value={line.substitution} onChange={e => setLine(line.productId, { substitution: e.target.value })} placeholder="Substitution or note" />
            <span className="print-only">{line.shortageReason || 'Complete'} {line.substitution ? `— ${line.substitution}` : ''}</span>
          </td>
        </tr>)}</tbody></table></div>
        <div className="packing-totals"><span>Ordered <b>{totals.ordered}</b></span><span>Packed <b>{totals.packed}</b></span><span>Short <b>{totals.short}</b></span></div>
        <div className="print-only packing-signoff">Packed by: {packer} &nbsp; Date: {new Date().toLocaleDateString()}</div>
      </div>
      <div className="actions no-print"><button className="secondary" onClick={() => window.print()}>Print packing slip</button>{selected.status !== 'packed' && <><button className="secondary" onClick={() => saveProgress(false)}>Save progress</button><button onClick={() => saveProgress(true)}>Complete and send to driver</button></>}</div>
    </Modal>}
  </>;
}
