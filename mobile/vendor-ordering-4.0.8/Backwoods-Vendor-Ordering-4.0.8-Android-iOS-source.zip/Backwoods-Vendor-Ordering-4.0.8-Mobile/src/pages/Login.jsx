import { useState } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';

const roles = [
  ['owner', 'Owner'], ['manager', 'Manager'], ['sales', 'Salesperson'],
  ['packer', 'Packer'], ['driver', 'Driver'], ['accounting', 'Accounting'], ['customer', 'Customer Portal']
];
const defaultLogo = `${import.meta.env.BASE_URL}brand/backwoods-brew-brewfoot-logo.png`;

export default function Login() {
  const { user, login, demoLogin, firebaseEnabled, error } = useAuth();
  const location = useLocation();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const from = location.state?.from?.pathname || (user?.role === 'customer' ? '/portal' : '/');

  if (user) return <Navigate to={user.role === 'customer' ? '/portal' : from} replace />;

  const submit = async event => {
    event.preventDefault();
    setBusy(true);
    try { await login(username, password); } catch { /* displayed by context */ }
    finally { setBusy(false); }
  };

  return <div className="auth-page">
    <div className="auth-card">
      <img className="auth-logo" src={defaultLogo} alt="Backwoods Brew logo"/>
      <h1>Backwoods Vendor Operations</h1>
      <p>{firebaseEnabled ? 'Sign in with your company account.' : 'Sign in with a user created in this app, or choose a demo role to test.'}</p>
      <form onSubmit={submit}>
        <label>Username<input type="text" value={username} onChange={event => setUsername(event.target.value)} required autoComplete="username" placeholder="Enter your username"/></label>
        <label>Password<input type="password" value={password} onChange={event => setPassword(event.target.value)} required autoComplete="current-password"/></label>
        {error && <div className="auth-error">{error}</div>}
        <button className="auth-submit" disabled={busy}>{busy ? 'Signing in...' : 'Sign in'}</button>
      </form>
      {!firebaseEnabled && <div className="demo-role-grid">
        {roles.map(([role, label]) => <button key={role} onClick={() => demoLogin(role)}>{label}</button>)}
      </div>}
      <small>{firebaseEnabled ? 'After one successful online sign-in, this device can verify that same user while offline and will reconnect automatically.' : 'Local users and demo roles are stored only on this device.'}</small>
    </div>
  </div>;
}
