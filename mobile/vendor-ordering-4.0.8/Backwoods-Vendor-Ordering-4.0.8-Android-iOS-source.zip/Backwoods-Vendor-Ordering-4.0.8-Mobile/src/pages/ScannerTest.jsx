import { useState } from 'react';
import { CheckCircle2, ScanBarcode } from 'lucide-react';
import BarcodeScanner from '../components/BarcodeScanner';

export default function ScannerTest() {
  const [lastScan, setLastScan] = useState('');
  const [history, setHistory] = useState([]);

  const capture = code => {
    const clean = String(code || '').trim();
    if (!clean) return;
    setLastScan(clean);
    setHistory(rows => [{ code: clean, at: new Date().toISOString() }, ...rows].slice(0, 10));
  };

  return <>
    <div className="page-head">
      <div><h1>Scanner Test</h1><p>Test USB scanners, Bluetooth scanners, and the Surface camera before scanning product UPCs.</p></div>
    </div>

    <div className="stats report-stats">
      <div className="card"><span>Last scan</span><strong>{lastScan || '-'}</strong></div>
      <div className="card"><span>Scanner type</span><strong>Keyboard / Camera</strong></div>
    </div>

    <div className="panel scanner-test-panel">
      <div className="panel-title">
        <div><h2><ScanBarcode size={20}/> Scan a test code</h2><p>Use the manual box, a USB/Bluetooth scanner, or the camera selector.</p></div>
      </div>
      <BarcodeScanner onScan={capture} placeholder="Scan or type a UPC, then press Enter"/>
      {lastScan && <div className="success-note"><CheckCircle2 size={17}/> Scanner read {lastScan}</div>}
    </div>

    <div className="panel table-scroll">
      <div className="panel-title"><div><h2>Recent scans</h2><p>Use this list to confirm the same code is being captured each time.</p></div></div>
      <table>
        <thead><tr><th>Code</th><th>Time</th></tr></thead>
        <tbody>{history.map(row => <tr key={`${row.code}-${row.at}`}><td><b>{row.code}</b></td><td>{new Date(row.at).toLocaleString()}</td></tr>)}</tbody>
      </table>
      {!history.length && <div className="empty compact">No scans captured yet.</div>}
    </div>
  </>;
}
