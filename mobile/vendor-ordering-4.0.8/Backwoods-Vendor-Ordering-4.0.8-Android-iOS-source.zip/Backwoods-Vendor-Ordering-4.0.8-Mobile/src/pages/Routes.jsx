import { useMemo, useState } from 'react';
import { CalendarDays, ChevronDown, ChevronUp, MapPin, Plus, Search, Trash2, Truck } from 'lucide-react';
import { makeId, now } from '../lib/helpers';

const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
const blank = { name: '', dayOfWeek: 'Monday', driverId: '', notes: '' };

export default function RoutesPage({ data, update }) {
  const [form, setForm] = useState(blank);
  const [expanded, setExpanded] = useState('');
  const [error, setError] = useState('');
  const [storeSearch, setStoreSearch] = useState('');

  const drivers = data.users.filter(user => user.active !== false && ['driver', 'manager', 'owner'].includes(user.role));
  const plans = useMemo(() => [...(data.routePlans || [])].sort((a, b) => days.indexOf(a.dayOfWeek) - days.indexOf(b.dayOfWeek) || a.name.localeCompare(b.name)), [data.routePlans]);

  const create = () => {
    setError('');
    if (!form.name.trim()) return setError('Enter a route name.');
    const driver = drivers.find(item => (item.id || item.uid) === form.driverId);
    const route = {
      id: makeId('route'),
      name: form.name.trim(),
      dayOfWeek: form.dayOfWeek,
      driverId: form.driverId,
      driverName: driver?.name || driver?.email || '',
      storeIds: [],
      notes: form.notes,
      status: 'active',
      createdAt: now(),
      updatedAt: now()
    };
    update(d => ({ ...d, routePlans: [...(d.routePlans || []), route] }));
    setForm(blank);
    setStoreSearch('');
    setExpanded(route.id);
  };

  const patch = (id, patchValue) => update(d => ({
    ...d,
    routePlans: (d.routePlans || []).map(route => route.id === id ? { ...route, ...patchValue, updatedAt: now() } : route)
  }));

  const addStore = (route, storeId) => update(d => ({
    ...d,
    routePlans: (d.routePlans || []).map(current => {
      const storeIds = (current.storeIds || []).filter(id => id !== storeId);
      return current.id === route.id ? { ...current, storeIds: [...storeIds, storeId], updatedAt: now() } : { ...current, storeIds, updatedAt: now() };
    }),
    customers: d.customers.map(customer => customer.id === storeId ? { ...customer, routeId: route.id } : customer)
  }));

  const removeStore = (route, storeId) => update(d => ({
    ...d,
    routePlans: (d.routePlans || []).map(current => current.id === route.id ? { ...current, storeIds: (current.storeIds || []).filter(id => id !== storeId), updatedAt: now() } : current),
    customers: d.customers.map(customer => customer.id === storeId && customer.routeId === route.id ? { ...customer, routeId: '' } : customer)
  }));

  const moveStore = (route, index, direction) => {
    const next = [...(route.storeIds || [])];
    const target = index + direction;
    if (target < 0 || target >= next.length) return;
    [next[index], next[target]] = [next[target], next[index]];
    patch(route.id, { storeIds: next });
  };

  const removeRoute = route => update(d => ({
    ...d,
    routePlans: (d.routePlans || []).filter(current => current.id !== route.id),
    customers: d.customers.map(customer => customer.routeId === route.id ? { ...customer, routeId: '' } : customer)
  }));

  const routeName = id => plans.find(route => route.id === id)?.name || 'Unassigned';

  return <>
    <div className="page-head"><div><h1>Weekly Routes</h1><p>Create routes, assign a dedicated day, and place stores in delivery order.</p></div></div>

    <div className="panel route-builder">
      <div className="form-grid">
        <label>Route name<input value={form.name} onChange={event => setForm({ ...form, name: event.target.value })} placeholder="Oxford North"/></label>
        <label>Dedicated day<select value={form.dayOfWeek} onChange={event => setForm({ ...form, dayOfWeek: event.target.value })}>{days.map(day => <option key={day}>{day}</option>)}</select></label>
        <label>Driver<select value={form.driverId} onChange={event => setForm({ ...form, driverId: event.target.value })}><option value="">Unassigned</option>{drivers.map(driver => <option key={driver.id || driver.uid} value={driver.id || driver.uid}>{driver.name || driver.email}</option>)}</select></label>
        <label>Notes<input value={form.notes} onChange={event => setForm({ ...form, notes: event.target.value })}/></label>
      </div>
      {error && <div className="alert">{error}</div>}
      <div className="actions"><button onClick={create}><Plus size={17}/>Create route</button></div>
    </div>

    <div className="packing-summary">
      <div className="card"><span>Weekly routes</span><strong>{plans.length}</strong></div>
      <div className="card"><span>Stores assigned</span><strong>{data.customers.filter(customer => customer.routeId).length}</strong></div>
      <div className="card"><span>Stores unassigned</span><strong>{data.customers.filter(customer => !customer.routeId).length}</strong></div>
    </div>

    {plans.map(route => {
      const open = expanded === route.id;
      const stores = (route.storeIds || []).map(id => data.customers.find(customer => customer.id === id)).filter(Boolean);
      const query = storeSearch.trim().toLowerCase();
      const available = data.customers
        .filter(customer => !(route.storeIds || []).includes(customer.id))
        .filter(customer => !query || `${customer.name} ${customer.storeNumber || ''} ${customer.address || ''} ${customer.city || ''}`.toLowerCase().includes(query));
      return <div className="panel route-card" key={route.id}>
        <div className="panel-title">
          <div><h3>{route.name}</h3><p><CalendarDays size={14}/> Every {route.dayOfWeek} {route.driverName && <><Truck size={14}/> {route.driverName}</>}</p></div>
          <div className="route-actions"><span className="status">{stores.length} stores</span><button className="small secondary" onClick={() => setExpanded(open ? '' : route.id)}>{open ? 'Close' : 'Manage'}</button></div>
        </div>
        {open && <div className="route-detail">
          <div className="form-grid">
            <label>Route name<input value={route.name} onChange={event => patch(route.id, { name: event.target.value })}/></label>
            <label>Dedicated day<select value={route.dayOfWeek} onChange={event => patch(route.id, { dayOfWeek: event.target.value })}>{days.map(day => <option key={day}>{day}</option>)}</select></label>
            <label>Driver<select value={route.driverId || ''} onChange={event => { const driver = drivers.find(item => (item.id || item.uid) === event.target.value); patch(route.id, { driverId: event.target.value, driverName: driver?.name || driver?.email || '' }); }}><option value="">Unassigned</option>{drivers.map(driver => <option key={driver.id || driver.uid} value={driver.id || driver.uid}>{driver.name || driver.email}</option>)}</select></label>
            <label>Notes<input value={route.notes || ''} onChange={event => patch(route.id, { notes: event.target.value })}/></label>
          </div>

          <h3>Store order</h3>
          {stores.length ? <div className="route-stops">{stores.map((store, index) => <div className="route-stop" key={store.id}>
            <div className="stop-number">{index + 1}</div>
            <div className="stop-body"><b>{store.name}</b><span><MapPin size={13}/> {store.address}{store.city ? `, ${store.city}` : ''}</span><small>{store.contact || 'No contact'} - {store.phone || 'No phone'}</small></div>
            <div className="stop-buttons"><button className="icon-button" onClick={() => moveStore(route, index, -1)}><ChevronUp size={17}/></button><button className="icon-button" onClick={() => moveStore(route, index, 1)}><ChevronDown size={17}/></button><button className="small danger" onClick={() => removeStore(route, store.id)}>Remove</button></div>
          </div>)}</div> : <div className="empty compact">No stores assigned yet.</div>}

          <div className="route-add-head"><h3>Add stores</h3><label className="search-field"><Search size={16}/><input value={storeSearch} onChange={event => setStoreSearch(event.target.value)} placeholder="Search stores"/></label></div>
          <div className="route-order-pool">{available.map(store => <button className="route-order-option" key={store.id} onClick={() => addStore(route, store.id)}>
            <span><b>{store.name}</b><small>{store.address}{store.city ? `, ${store.city}` : ''}</small></span>
            <span>{store.routeId ? `Move from ${routeName(store.routeId)}` : 'Add store'}</span>
          </button>)}</div>
          {!available.length && <p className="muted">No stores match this search.</p>}
          <div className="actions"><button className="danger" onClick={() => removeRoute(route)}><Trash2 size={16}/>Delete route</button></div>
        </div>}
      </div>;
    })}
    {!plans.length && <div className="panel empty">No weekly routes yet.</div>}
  </>;
}
