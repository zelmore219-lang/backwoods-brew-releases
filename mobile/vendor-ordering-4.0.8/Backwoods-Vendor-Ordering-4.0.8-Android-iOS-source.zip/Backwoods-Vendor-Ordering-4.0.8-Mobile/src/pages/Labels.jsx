import { useEffect, useRef, useState } from 'react';
import JsBarcode from 'jsbarcode';

function Barcode({value}){const ref=useRef(null);useEffect(()=>{if(ref.current&&value)JsBarcode(ref.current,value,{format:'CODE128',displayValue:true,height:48,margin:4,fontSize:12});},[value]);return <svg ref={ref}/>}

export default function Labels({data}){
 const [type,setType]=useState('product'),[productId,setProductId]=useState(data.products[0]?.id||''),[copies,setCopies]=useState(1),[ship,setShip]=useState({name:'',address:'',order:''});
 const product=data.products.find(p=>p.id===productId);
 const labels=Array.from({length:Math.max(1,Number(copies||1))});
 return <><div className="page-head"><div><h1>Product & Shipping Labels</h1><p>Print scannable product labels and delivery carton labels.</p></div><button onClick={()=>window.print()}>Print labels</button></div>
 <div className="panel no-print"><div className="form-grid"><label>Label type<select value={type} onChange={e=>setType(e.target.value)}><option value="product">Product barcode</option><option value="shipping">Shipping carton</option></select></label><label>Copies<input type="number" min="1" max="100" value={copies} onChange={e=>setCopies(e.target.value)}/></label>{type==='product'?<label>Product<select value={productId} onChange={e=>setProductId(e.target.value)}>{data.products.map(p=><option value={p.id} key={p.id}>{p.name}</option>)}</select></label>:<><label>Store / recipient<input value={ship.name} onChange={e=>setShip({...ship,name:e.target.value})}/></label><label>Address<input value={ship.address} onChange={e=>setShip({...ship,address:e.target.value})}/></label><label>Order / route<input value={ship.order} onChange={e=>setShip({...ship,order:e.target.value})}/></label></>}</div></div>
 <div className="label-sheet">{labels.map((_,i)=><div className={`print-label ${type}`} key={i}>{type==='product'?<><strong>{data.company.name}</strong><h3>{product?.name}</h3><span>{product?.sku}</span><Barcode value={product?.barcode||product?.sku||''}/><small>{product?.unit} · Case pack {product?.caseQty}</small></>:<><strong>{data.company.name}</strong><h2>{ship.name||'Store name'}</h2><p>{ship.address||'Delivery address'}</p><h3>{ship.order||'Order / route'}</h3><Barcode value={ship.order||'UNASSIGNED'}/><small>Carton {i+1} of {labels.length}</small></>}</div>)}</div></>;
}
