import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle2, Download, Printer } from 'lucide-react';
import { money, calcOrder, now } from '../lib/helpers';

const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const csvCell = value => `"${String(value ?? '').replaceAll('"', '""')}"`;

function downloadCsv(name, rows) {
  if (!rows.length) return;
  const keys = Object.keys(rows[0]);
  const csv = [keys.join(','), ...rows.map(row => keys.map(key => csvCell(row[key])).join(','))].join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = name;
  link.click();
  URL.revokeObjectURL(url);
}

export default function SalesDay({ data, update }) {
  const [selectedDay, setSelectedDay] = useState(days[new Date().getDay()]);
  const [manifestRoute, setManifestRoute] = useState('all');
  const [closeoutRoute, setCloseoutRoute] = useState('all');
  const todayKey = new Date().toISOString().slice(0, 10);
  const routes = useMemo(() => (data.routePlans || []).filter(route => route.dayOfWeek === selectedDay), [data.routePlans, selectedDay]);
  const dayOrders = data.orders.filter(order => order.deliveryDay === selectedDay && !['cancelled', 'void'].includes(order.status));
  const activeRoutes = manifestRoute === 'all' ? routes : routes.filter(route => route.id === manifestRoute);

  const getVisit = storeId => (data.notifications || []).find(n => n.type === 'route_visit' && n.storeId === storeId && n.date === todayKey);
  const setStatus = (storeId, status, note = '') => update(d => {
    const id = `visit_${todayKey}_${storeId}`;
    const entry = { id, type: 'route_visit', storeId, date: todayKey, status, note, updatedAt: now(), read: true };
    return { ...d, notifications: [...(d.notifications || []).filter(n => n.id !== id), entry] };
  });

  const stops = useMemo(() => routes.flatMap(route => (route.storeIds || []).map((id, index) => {
    const store = data.customers.find(customer => customer.id === id);
    const orders = dayOrders.filter(order => order.customerId === id || order.routeId === route.id);
    const latest = data.orders.filter(order => order.customerId === id).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))[0];
    return store ? { route, store, index, orders, latest } : null;
  }).filter(Boolean)), [routes, data.customers, data.orders, dayOrders]);

  const routeSales = dayOrders.reduce((sum, order) => sum + calcOrder(order).total, 0);
  const completedStops = stops.filter(stop => ['completed', 'skipped', 'closed'].includes(getVisit(stop.store.id)?.status)).length;
  const packedOrders = dayOrders.filter(order => ['packed', 'out_for_delivery', 'delivered', 'completed', 'payment_pending'].includes(order.status)).length;
  const manifestRows = stops
    .filter(stop => manifestRoute === 'all' || stop.route.id === manifestRoute)
    .map(stop => {
      const total = stop.orders.reduce((sum, order) => sum + calcOrder(order).total, 0);
      return {
        route: stop.route.name,
        stop: stop.index + 1,
        store: stop.store.name,
        contact: stop.store.contact || '',
        phone: stop.store.phone || '',
        address: [stop.store.address, stop.store.city, stop.store.state, stop.store.zip].filter(Boolean).join(', '),
        instructions: stop.store.deliveryInstructions || '',
        orders: stop.orders.map(order => order.orderNumber).join(' / '),
        status: getVisit(stop.store.id)?.status || 'not_visited',
        total,
      };
    });
  const closeoutOrders = dayOrders.filter(order => closeoutRoute === 'all' || order.routeId === closeoutRoute);
  const closeoutPayments = closeoutOrders.flatMap(order => (order.payments || []).map(payment => ({ ...payment, order })));
  const closeoutSummary = closeoutOrders.reduce((summary, order) => {
    const totals = calcOrder(order);
    summary.invoices += 1;
    summary.sales += totals.total;
    summary.paid += totals.paid;
    summary.balance += totals.balance;
    summary.returns += (order.items || []).reduce((sum, item) => sum + Number(item.returnQty || 0), 0);
    return summary;
  }, { invoices: 0, sales: 0, paid: 0, balance: 0, returns: 0 });
  closeoutSummary.cash = closeoutPayments.filter(payment => String(payment.method || '').toLowerCase() === 'cash').reduce((sum, payment) => sum + Number(payment.amount || 0), 0);
  closeoutSummary.checks = closeoutPayments.filter(payment => String(payment.method || '').toLowerCase() === 'check').reduce((sum, payment) => sum + Number(payment.amount || 0), 0);
  closeoutSummary.cards = closeoutPayments.filter(payment => String(payment.method || '').toLowerCase().includes('card')).reduce((sum, payment) => sum + Number(payment.amount || 0), 0);
  const closeoutKey = `route_closeout_${todayKey}_${selectedDay}_${closeoutRoute}`;
  const closeoutEntry = (data.notifications || []).find(item => item.id === closeoutKey);
  const closeoutRows = closeoutOrders.map(order => {
    const totals = calcOrder(order);
    return {
      route: order.routeName || 'Unassigned',
      invoice: order.invoiceNumber,
      customer: order.customerName || data.customers.find(customer => customer.id === order.customerId)?.name || '',
      status: order.status,
      total: totals.total,
      paid: totals.paid,
      balance: totals.balance,
      returns: (order.items || []).reduce((sum, item) => sum + Number(item.returnQty || 0), 0),
    };
  });

  const closeRoute = () => update(d => {
    const route = closeoutRoute === 'all' ? null : routes.find(item => item.id === closeoutRoute);
    const entry = {
      id: closeoutKey,
      type: 'route_closeout',
      date: todayKey,
      dayOfWeek: selectedDay,
      routeId: closeoutRoute,
      routeName: route?.name || 'All routes',
      status: 'closed',
      summary: closeoutSummary,
      updatedAt: now(),
      read: true
    };
    return { ...d, notifications: [...(d.notifications || []).filter(item => item.id !== closeoutKey), entry] };
  });

  return <>
    <div className="page-head">
      <div><h1>Route Day Board</h1><p>Plan, track, print, and export delivery routes by assigned day.</p></div>
      <div className="actions no-print">
        <select value={selectedDay} onChange={event => setSelectedDay(event.target.value)}>{days.map(day => <option key={day}>{day}</option>)}</select>
        <Link className="link-button" to="/orders">Create order</Link>
      </div>
    </div>

    <div className="stats">
      <div className="card"><span>Routes</span><strong>{routes.length}</strong></div>
      <div className="card"><span>Stops</span><strong>{stops.length}</strong></div>
      <div className="card"><span>Completed stops</span><strong>{completedStops}</strong></div>
      <div className="card"><span>Route sales</span><strong>{money(routeSales)}</strong></div>
      <div className="card"><span>Packed / loaded</span><strong>{packedOrders}</strong></div>
    </div>

    <div className="panel no-print">
      <div className="panel-title">
        <div><h2>Route manifest</h2><p>Print for the driver or export to a spreadsheet.</p></div>
        <div className="actions">
          <select value={manifestRoute} onChange={event => setManifestRoute(event.target.value)}><option value="all">All {selectedDay} routes</option>{routes.map(route => <option key={route.id} value={route.id}>{route.name}</option>)}</select>
          <button className="secondary" onClick={() => window.print()}><Printer size={17}/>Print</button>
          <button onClick={() => downloadCsv(`route-manifest-${selectedDay}.csv`, manifestRows)}><Download size={17}/>CSV</button>
        </div>
      </div>
    </div>

    <div className="panel no-print route-closeout">
      <div className="panel-title">
        <div><h2>Route closeout</h2><p>Close the day with invoice totals, collections, returns, and remaining balances.</p></div>
        <div className="actions">
          <select value={closeoutRoute} onChange={event => setCloseoutRoute(event.target.value)}><option value="all">All {selectedDay} routes</option>{routes.map(route => <option key={route.id} value={route.id}>{route.name}</option>)}</select>
          <button className="secondary" disabled={!closeoutRows.length} onClick={() => downloadCsv(`route-closeout-${selectedDay}.csv`, closeoutRows)}><Download size={17}/>CSV</button>
          <button disabled={!closeoutRows.length} onClick={closeRoute}><CheckCircle2 size={17}/>{closeoutEntry ? 'Update closeout' : 'Close route'}</button>
        </div>
      </div>
      <div className="closeout-grid">
        <div><span>Invoices</span><strong>{closeoutSummary.invoices}</strong></div>
        <div><span>Sales</span><strong>{money(closeoutSummary.sales)}</strong></div>
        <div><span>Collected</span><strong>{money(closeoutSummary.paid)}</strong></div>
        <div><span>Balance</span><strong>{money(closeoutSummary.balance)}</strong></div>
        <div><span>Cash</span><strong>{money(closeoutSummary.cash)}</strong></div>
        <div><span>Checks</span><strong>{money(closeoutSummary.checks)}</strong></div>
        <div><span>Cards</span><strong>{money(closeoutSummary.cards)}</strong></div>
        <div><span>Returns</span><strong>{closeoutSummary.returns}</strong></div>
      </div>
      {closeoutEntry && <div className="success-note"><CheckCircle2 size={17}/> Closed {new Date(closeoutEntry.updatedAt).toLocaleString()}</div>}
    </div>

    {!routes.length && <div className="panel empty">No routes are assigned to {selectedDay}. Create one under Routes.</div>}

    {activeRoutes.map(route => <div className="panel" key={route.id}>
      <div className="panel-title">
        <div><h2>{route.name}</h2><p>{route.driverName || route.driver || 'Driver not assigned'} - {(route.storeIds || []).length} stops</p></div>
        <span className="status">{selectedDay}</span>
      </div>
      <div className="route-day-list">{(route.storeIds || []).map((id, index) => {
        const store = data.customers.find(customer => customer.id === id);
        if (!store) return null;
        const visit = getVisit(id);
        const stopOrders = dayOrders.filter(order => order.customerId === id || order.routeId === route.id);
        const last = data.orders.filter(order => order.customerId === id).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))[0];
        const stopTotal = stopOrders.reduce((sum, order) => sum + calcOrder(order).total, 0);
        return <div className="route-day-stop" key={id}>
          <div className="stop-number">{index + 1}</div>
          <div>
            <b>{store.name}</b>
            <small>{[store.address, store.city, store.state].filter(Boolean).join(', ')}</small>
            <small>{store.deliveryInstructions || 'No delivery instructions'}</small>
            <small>{last ? `Last order ${new Date(last.createdAt).toLocaleDateString()} - ${money(calcOrder(last).total)}` : 'No previous order'}</small>
          </div>
          <div className="visit-actions">
            <span className="status">{stopOrders.length} order(s) - {money(stopTotal)}</span>
            <select value={visit?.status || 'not_visited'} onChange={event => setStatus(id, event.target.value, visit?.note || '')}>
              <option value="not_visited">Not visited</option>
              <option value="started">Order started</option>
              <option value="completed">Completed</option>
              <option value="skipped">Skipped</option>
              <option value="closed">Store closed</option>
              <option value="follow_up">Follow-up needed</option>
            </select>
            <Link className="small link-button" to={`/orders?store=${id}`}>Order</Link>
            {store.phone && <a className="small secondary link-button" href={`tel:${store.phone}`}>Call</a>}
            {store.address && <a className="small secondary link-button" target="_blank" rel="noreferrer" href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent([store.address, store.city, store.state, store.zip].filter(Boolean).join(' '))}`}>Navigate</a>}
          </div>
        </div>;
      })}</div>
    </div>)}

    <div className="panel route-manifest-print">
      <div className="manifest-head">
        <div><h2>{data.company.name} Route Manifest</h2><p>{selectedDay} - {manifestRoute === 'all' ? 'All routes' : routes.find(route => route.id === manifestRoute)?.name}</p></div>
        <div className="manifest-meta">Printed {new Date().toLocaleString()}<br/>{manifestRows.length} stop(s)</div>
      </div>
      <table className="route-manifest-table">
        <thead><tr><th>Route</th><th>Stop</th><th>Store</th><th>Contact</th><th>Address</th><th>Instructions</th><th>Orders</th><th>Total</th></tr></thead>
        <tbody>{manifestRows.map(row => <tr key={`${row.route}-${row.stop}-${row.store}`}><td>{row.route}</td><td>{row.stop}</td><td>{row.store}</td><td>{row.contact}<small>{row.phone}</small></td><td>{row.address}</td><td>{row.instructions}</td><td>{row.orders}</td><td>{money(row.total)}</td></tr>)}</tbody>
      </table>
    </div>
  </>;
}
