import { useMemo, useState } from 'react';
import { calcOrder, money } from '../lib/helpers';
import { buildSyncRows, syncSummary } from '../lib/syncStatus';

const day = value => value ? new Date(value).toLocaleDateString('en-US') : '-';
const monthKey = value => {
  const d = value ? new Date(value) : new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
};

const downloadCsv = (name, rows) => {
  if (!rows.length) return;
  const keys = Object.keys(rows[0]);
  const csv = [keys.join(','), ...rows.map(row => keys.map(k => `"${String(row[k] ?? '').replaceAll('"', '""')}"`).join(','))].join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = name;
  link.click();
  URL.revokeObjectURL(url);
};

const completedStatuses = ['completed', 'delivered', 'payment_pending', 'paid', 'invoiced'];

function paymentBuckets(payments = []) {
  return payments.reduce((row, payment) => {
    const amount = Number(payment.amount || 0);
    const method = String(payment.method || 'other').toLowerCase();
    if (method === 'cash') row.cash += amount;
    else if (method === 'check') row.checks += amount;
    else if (method.includes('card')) row.cards += amount;
    else if (method === 'ach') row.ach += amount;
    else row.other += amount;
    row.collected += amount;
    return row;
  }, { collected: 0, cash: 0, checks: 0, cards: 0, ach: 0, other: 0 });
}

export default function Reports({ data }) {
  const [range, setRange] = useState('all');
  const [tab, setTab] = useState('sales');
  const now = new Date();
  const orders = data.orders || [];
  const filteredOrders = useMemo(() => orders.filter(order => {
    if (range === 'all') return true;
    const value = new Date(order.deliveredAt || order.createdAt || 0);
    return value >= new Date(now.getTime() - Number(range) * 86400000);
  }), [orders, range]);

  const completed = filteredOrders.filter(order => completedStatuses.includes(String(order.status || '').toLowerCase()));
  const salesTotal = completed.reduce((sum, order) => sum + calcOrder(order).total, 0);
  const collected = filteredOrders.reduce((sum, order) => sum + paymentBuckets(order.payments).collected, 0);
  const outstanding = orders.reduce((sum, order) => sum + calcOrder(order).balance, 0);
  const creditTotal = (data.credits || []).filter(credit => ['approved', 'picked_up'].includes(credit.status)).reduce((sum, credit) => sum + Number(credit.amount || 0), 0);
  const syncStats = syncSummary(data);
  const profit = completed.reduce((sum, order) => sum + (order.items || []).reduce((lineSum, item) => {
    const product = (data.products || []).find(p => p.id === item.productId);
    const qty = Number(item.invoiceQty ?? item.deliveredQty ?? item.qty ?? 0);
    return lineSum + qty * (Number(item.price || 0) - Number(product?.cost || 0));
  }, 0), 0);

  const monthly = useMemo(() => Object.values(completed.reduce((map, order) => {
    const key = monthKey(order.deliveredAt || order.createdAt);
    map[key] ||= { month: key, orders: 0, sales: 0, collected: 0, balance: 0 };
    map[key].orders += 1;
    map[key].sales += calcOrder(order).total;
    map[key].collected += paymentBuckets(order.payments).collected;
    map[key].balance += calcOrder(order).balance;
    return map;
  }, {})).sort((a, b) => b.month.localeCompare(a.month)), [completed]);

  const productRows = useMemo(() => (data.products || []).map(product => {
    let qty = 0;
    let revenue = 0;
    completed.forEach(order => (order.items || []).filter(item => item.productId === product.id).forEach(item => {
      const q = Number(item.invoiceQty ?? item.deliveredQty ?? item.qty ?? 0);
      qty += q;
      revenue += q * Number(item.price || 0);
    }));
    const available = Number(product.onHand || 0) - Number(product.reserved || 0);
    return {
      product: product.name,
      sku: product.sku,
      qty,
      revenue,
      profit: qty * (Number(product.price || 0) - Number(product.cost || 0)),
      onHand: Number(product.onHand || 0),
      reserved: Number(product.reserved || 0),
      available,
      reorder: Number(product.reorderLevel || 10),
    };
  }).sort((a, b) => b.revenue - a.revenue), [completed, data.products]);

  const customerRows = useMemo(() => (data.customers || []).map(customer => {
    const customerOrders = completed.filter(order => order.customerId === customer.id);
    const openBalance = orders.filter(order => order.customerId === customer.id).reduce((sum, order) => sum + calcOrder(order).balance, 0);
    return {
      customer: customer.name,
      route: (data.routePlans || []).find(route => route.id === customer.routeId)?.name || 'Unassigned',
      terms: customer.terms || data.company?.defaultTerms || '',
      orders: customerOrders.length,
      sales: customerOrders.reduce((sum, order) => sum + calcOrder(order).total, 0),
      balance: openBalance,
    };
  }).sort((a, b) => b.sales - a.sales), [completed, data.customers, data.routePlans, orders]);

  const routeRows = useMemo(() => {
    const map = new Map();
    (data.routePlans || []).forEach(route => map.set(route.id, {
      routeId: route.id,
      route: route.name,
      day: route.dayOfWeek || '',
      stops: (route.storeIds || []).length,
      orders: 0,
      sales: 0,
      collected: 0,
      balance: 0,
    }));
    completed.forEach(order => {
      const key = order.routeId || order.routeName || 'unassigned';
      const row = map.get(key) || { routeId: key, route: order.routeName || 'Unassigned', day: order.deliveryDay || '', stops: 0, orders: 0, sales: 0, collected: 0, balance: 0 };
      const totals = calcOrder(order);
      row.orders += 1;
      row.sales += totals.total;
      row.collected += paymentBuckets(order.payments).collected;
      row.balance += totals.balance;
      map.set(key, row);
    });
    return [...map.values()].sort((a, b) => b.sales - a.sales);
  }, [completed, data.routePlans]);

  const driverRows = useMemo(() => {
    const map = new Map();
    filteredOrders.forEach(order => {
      const driver = order.driver || order.driverId || 'Unassigned';
      const row = map.get(driver) || { driver, deliveries: 0, collected: 0, cash: 0, checks: 0, cards: 0, ach: 0, other: 0, unsettled: 0 };
      row.deliveries += order.deliveredAt ? 1 : 0;
      const buckets = paymentBuckets(order.payments || []);
      row.collected += buckets.collected;
      row.cash += buckets.cash;
      row.checks += buckets.checks;
      row.cards += buckets.cards;
      row.ach += buckets.ach;
      row.other += buckets.other;
      row.unsettled += (order.payments || []).filter(payment => !payment.settledAt).reduce((sum, payment) => sum + Number(payment.amount || 0), 0);
      map.set(driver, row);
    });
    return [...map.values()].sort((a, b) => b.collected - a.collected);
  }, [filteredOrders]);

  const arRows = useMemo(() => orders
    .map(order => {
      const totals = calcOrder(order);
      const customer = (data.customers || []).find(c => c.id === order.customerId);
      return {
        invoice: order.invoiceNumber || order.orderNumber || order.id,
        customer: customer?.name || order.customerName || 'Unknown',
        due: order.dueDate || order.deliveredAt || order.createdAt || '',
        status: order.status || '',
        total: totals.total,
        paid: totals.paid,
        balance: totals.balance,
        route: order.routeName || '',
      };
    })
    .filter(row => row.balance > 0.009)
    .sort((a, b) => b.balance - a.balance), [orders, data.customers]);

  const inventoryRows = productRows.slice().sort((a, b) => a.available - b.available);
  const movementRows = (data.inventoryMovements || []).slice().sort((a, b) => String(b.createdAt || '').localeCompare(String(a.createdAt || ''))).slice(0, 200).map(movement => {
    const product = (data.products || []).find(p => p.id === movement.productId);
    return {
      date: movement.createdAt ? new Date(movement.createdAt).toLocaleString() : '',
      product: product?.name || movement.productId || '',
      sku: product?.sku || '',
      type: movement.type || '',
      quantity: Number(movement.quantity || 0),
      reference: movement.reference || '',
      note: movement.note || '',
    };
  });
  const syncRows = buildSyncRows(data);
  const creditRows = (data.credits || []).slice().reverse().map(credit => {
    const order = orders.find(o => o.id === credit.orderId);
    return {
      date: day(credit.createdAt),
      invoice: order?.invoiceNumber || '',
      customer: (data.customers || []).find(customer => customer.id === (credit.customerId || order?.customerId))?.name || '',
      product: (data.products || []).find(product => product.id === credit.productId)?.name || '',
      reason: credit.reason || '',
      status: credit.status || '',
      amount: Number(credit.amount || 0),
    };
  });

  const tabs = [
    ['sales', 'Sales'],
    ['products', 'Products'],
    ['customers', 'Stores'],
    ['routes', 'Routes'],
    ['drivers', 'Settlements'],
    ['ar', 'A/R'],
    ['inventory', 'Inventory'],
    ['movements', 'Movements'],
    ['sync', 'Sync'],
    ['credits', 'Credits'],
  ];

  return <>
    <div className="page-head">
      <div><h1>Reports & Management</h1><p>Review sales, margins, collections, route performance, inventory, credits, and main-app sync readiness.</p></div>
      <div className="actions no-print">
        <select value={range} onChange={event => setRange(event.target.value)}>
          <option value="all">All time</option>
          <option value="7">Last 7 days</option>
          <option value="30">Last 30 days</option>
          <option value="90">Last 90 days</option>
          <option value="365">Last 12 months</option>
        </select>
        <button className="secondary" onClick={() => window.print()}>Print report</button>
      </div>
    </div>

    <div className="stats report-stats">
      <div className="card"><span>Sales</span><strong>{money(salesTotal)}</strong></div>
      <div className="card"><span>Collected</span><strong>{money(collected)}</strong></div>
      <div className="card"><span>Gross profit estimate</span><strong>{money(profit)}</strong></div>
      <div className="card"><span>Outstanding A/R</span><strong>{money(outstanding)}</strong></div>
      <div className="card"><span>Ready to sync</span><strong>{syncStats.ready}</strong><small>{money(syncStats.readyValue)}</small></div>
      <div className="card"><span>Approved credits</span><strong>{money(creditTotal)}</strong></div>
    </div>

    <div className="report-tabs no-print">{tabs.map(([id, label]) => <button key={id} className={tab === id ? 'active secondary' : 'secondary'} onClick={() => setTab(id)}>{label}</button>)}</div>

    {tab === 'sales' && <ReportTable title="Sales by month" sub="Delivered invoice totals, collections, and remaining balance." file="sales-by-month.csv" rows={monthly}>
      <table><thead><tr><th>Month</th><th>Orders</th><th>Sales</th><th>Collected</th><th>Balance</th><th>Collection rate</th></tr></thead><tbody>{monthly.map(row => <tr key={row.month}><td>{row.month}</td><td>{row.orders}</td><td>{money(row.sales)}</td><td>{money(row.collected)}</td><td>{money(row.balance)}</td><td>{row.sales ? `${Math.round(row.collected / row.sales * 100)}%` : '0%'}</td></tr>)}</tbody></table>
    </ReportTable>}

    {tab === 'products' && <ReportTable title="Product performance" sub="Units, revenue, estimated gross profit, and current availability." file="product-performance.csv" rows={productRows}>
      <table><thead><tr><th>Product</th><th>SKU</th><th>Units sold</th><th>Revenue</th><th>Est. profit</th><th>Available</th></tr></thead><tbody>{productRows.map(row => <tr key={row.sku}><td>{row.product}</td><td>{row.sku}</td><td>{row.qty}</td><td>{money(row.revenue)}</td><td>{money(row.profit)}</td><td>{row.available}</td></tr>)}</tbody></table>
    </ReportTable>}

    {tab === 'customers' && <ReportTable title="Store performance" sub="Sales, route, terms, and current unpaid balances by account." file="store-performance.csv" rows={customerRows}>
      <table><thead><tr><th>Store</th><th>Route</th><th>Terms</th><th>Orders</th><th>Sales</th><th>Open balance</th></tr></thead><tbody>{customerRows.map(row => <tr key={row.customer}><td>{row.customer}</td><td>{row.route}</td><td>{row.terms}</td><td>{row.orders}</td><td>{money(row.sales)}</td><td className={row.balance > 0 ? 'amount-due' : ''}>{money(row.balance)}</td></tr>)}</tbody></table>
    </ReportTable>}

    {tab === 'routes' && <ReportTable title="Route performance" sub="Compare route volume, stops, collections, and open balances." file="route-performance.csv" rows={routeRows}>
      <table><thead><tr><th>Route</th><th>Day</th><th>Stops</th><th>Orders</th><th>Sales</th><th>Collected</th><th>Balance</th></tr></thead><tbody>{routeRows.map(row => <tr key={row.routeId}><td>{row.route}</td><td>{row.day}</td><td>{row.stops}</td><td>{row.orders}</td><td>{money(row.sales)}</td><td>{money(row.collected)}</td><td>{money(row.balance)}</td></tr>)}</tbody></table>
    </ReportTable>}

    {tab === 'drivers' && <ReportTable title="Driver settlement report" sub="Deliveries, payment method mix, and unsettled collection totals." file="driver-settlement.csv" rows={driverRows}>
      <table><thead><tr><th>Driver</th><th>Deliveries</th><th>Total collected</th><th>Cash</th><th>Checks</th><th>Cards</th><th>ACH</th><th>Unsettled</th></tr></thead><tbody>{driverRows.map(row => <tr key={row.driver}><td>{row.driver}</td><td>{row.deliveries}</td><td>{money(row.collected)}</td><td>{money(row.cash)}</td><td>{money(row.checks)}</td><td>{money(row.cards)}</td><td>{money(row.ach)}</td><td className={row.unsettled > 0 ? 'amount-due' : ''}>{money(row.unsettled)}</td></tr>)}</tbody></table>
    </ReportTable>}

    {tab === 'ar' && <ReportTable title="Open accounts receivable" sub="Unpaid vendor invoices by store, route, due date, and balance." file="open-ar.csv" rows={arRows}>
      <table><thead><tr><th>Invoice</th><th>Store</th><th>Due/date</th><th>Route</th><th>Status</th><th>Total</th><th>Paid</th><th>Balance</th></tr></thead><tbody>{arRows.map(row => <tr key={row.invoice}><td>{row.invoice}</td><td>{row.customer}</td><td>{day(row.due)}</td><td>{row.route}</td><td><span className="status">{row.status}</span></td><td>{money(row.total)}</td><td>{money(row.paid)}</td><td className="amount-due">{money(row.balance)}</td></tr>)}</tbody></table>
    </ReportTable>}

    {tab === 'inventory' && <ReportTable title="Inventory health" sub="On-hand, reserved, available, and reorder quantities." file="inventory-health.csv" rows={inventoryRows}>
      <table><thead><tr><th>Product</th><th>SKU</th><th>On hand</th><th>Reserved</th><th>Available</th><th>Reorder at</th></tr></thead><tbody>{inventoryRows.map(row => <tr key={row.sku} className={row.available <= row.reorder ? 'short-line' : ''}><td>{row.product}</td><td>{row.sku}</td><td>{row.onHand}</td><td>{row.reserved}</td><td><b>{row.available}</b></td><td>{row.reorder}</td></tr>)}</tbody></table>
    </ReportTable>}

    {tab === 'movements' && <ReportTable title="Inventory movement history" sub="Recent purchasing receipts, deliveries, returns, credits, and manual adjustments." file="inventory-movements.csv" rows={movementRows}>
      <table><thead><tr><th>Date</th><th>Product</th><th>SKU</th><th>Type</th><th>Qty</th><th>Reference</th><th>Note</th></tr></thead><tbody>{movementRows.map((row, index) => <tr key={`${row.date}-${row.sku}-${index}`}><td>{row.date}</td><td>{row.product}</td><td>{row.sku}</td><td><span className="status">{row.type}</span></td><td>{row.quantity}</td><td>{row.reference}</td><td className="movement-note">{row.note}</td></tr>)}</tbody></table>
    </ReportTable>}

    {tab === 'sync' && <ReportTable title="Main app sync status" sub="Invoices waiting for import, already synced, or needing attention." file="main-app-sync.csv" rows={syncRows}>
      <table><thead><tr><th>Invoice</th><th>Store</th><th>Order status</th><th>Main app status</th><th>Synced at</th><th>Total</th><th>Balance</th><th>Message</th></tr></thead><tbody>{syncRows.map(row => <tr key={row.id}><td>{row.invoice}</td><td>{row.customer}</td><td><span className="status">{row.orderStatus}</span></td><td><span className="status">{row.syncStatus}</span></td><td>{row.syncedAt ? new Date(row.syncedAt).toLocaleString() : '-'}</td><td>{money(row.total)}</td><td>{money(row.balance)}</td><td>{row.message || '-'}</td></tr>)}</tbody></table>
    </ReportTable>}

    {tab === 'credits' && <ReportTable title="Credits and returns" sub="Credit value, reason, pickup status, and affected invoice." file="credits-and-returns.csv" rows={creditRows}>
      <table><thead><tr><th>Date</th><th>Invoice</th><th>Store</th><th>Product</th><th>Reason</th><th>Status</th><th>Amount</th></tr></thead><tbody>{creditRows.map((row, index) => <tr key={`${row.invoice}-${index}`}><td>{row.date}</td><td>{row.invoice}</td><td>{row.customer}</td><td>{row.product}</td><td>{row.reason}</td><td><span className="status">{row.status}</span></td><td>{money(row.amount)}</td></tr>)}</tbody></table>
    </ReportTable>}
  </>;
}

function ReportTable({ title, sub, file, rows, children }) {
  return <div className="panel table-scroll">
    <div className="panel-title">
      <div><h2>{title}</h2><p>{sub}</p></div>
      <button className="small secondary no-print" onClick={() => downloadCsv(file, rows)}>Download CSV</button>
    </div>
    {children}
    {!rows.length && <div className="empty compact">No rows for this report yet.</div>}
  </div>;
}
