import { useState } from 'react';
import Modal from '../components/Modal';
import { makeId, money, now } from '../lib/helpers';

const blank={name:'',contact:'',email:'',phone:'',address:'',accountNumber:'',terms:'Net 30',leadTimeDays:7,minimumOrder:0,notes:'',active:true};

export default function Suppliers({data,update}){
  const [open,setOpen]=useState(false),[editing,setEditing]=useState(null),[f,setF]=useState(blank);
  const edit=s=>{setEditing(s.id);setF({...blank,...s});setOpen(true)};
  const save=()=>{
    if(!f.name.trim())return;
    update(d=>{
      const supplier={...f,id:editing||makeId('sup'),leadTimeDays:Number(f.leadTimeDays||0),minimumOrder:Number(f.minimumOrder||0),updatedAt:now(),createdAt:editing?(d.suppliers.find(s=>s.id===editing)?.createdAt||now()):now()};
      const suppliers=editing?d.suppliers.map(s=>s.id===editing?supplier:s):[...d.suppliers,supplier];
      const audit={id:makeId('audit'),action:editing?'supplier_updated':'supplier_created',entityType:'supplier',entityId:supplier.id,summary:supplier.name,createdAt:now()};
      return {...d,suppliers,auditLogs:[...(d.auditLogs||[]),audit]};
    });
    setOpen(false);setEditing(null);setF(blank);
  };
  const supplierSpend=id=>(data.purchaseOrders||[]).filter(po=>po.supplierId===id&&po.status!=='cancelled').reduce((sum,po)=>sum+Number(po.total||0),0);
  return <>
    <div className="page-head"><div><h1>Suppliers</h1><p>Vendor contacts, terms, lead times, and purchasing history.</p></div><button onClick={()=>{setEditing(null);setF(blank);setOpen(true)}}>Add supplier</button></div>
    <div className="panel"><table><thead><tr><th>Supplier</th><th>Contact</th><th>Terms</th><th>Lead time</th><th>Minimum</th><th>PO spend</th><th></th></tr></thead><tbody>{(data.suppliers||[]).map(s=><tr key={s.id}><td><b>{s.name}</b><small>{s.accountNumber||'No account number'} · {s.active?'Active':'Inactive'}</small></td><td>{s.contact||'—'}<small>{s.email||s.phone||''}</small></td><td>{s.terms}</td><td>{s.leadTimeDays} days</td><td>{money(s.minimumOrder)}</td><td>{money(supplierSpend(s.id))}</td><td><button className="small" onClick={()=>edit(s)}>Edit</button></td></tr>)}</tbody></table>{!(data.suppliers||[]).length&&<div className="empty">No suppliers have been added.</div>}</div>
    {open&&<Modal title={editing?'Edit supplier':'Add supplier'} wide onClose={()=>setOpen(false)}><div className="form-grid">{Object.keys(blank).map(k=>k==='active'?<label className="toggle" key={k}><input type="checkbox" checked={Boolean(f[k])} onChange={e=>setF({...f,[k]:e.target.checked})}/><span>Active supplier</span></label>:<label key={k}>{k.replace(/([A-Z])/g,' $1')} {k==='notes'?<textarea value={f[k]} onChange={e=>setF({...f,[k]:e.target.value})}/>:<input type={['leadTimeDays','minimumOrder'].includes(k)?'number':'text'} step={k==='minimumOrder'?'0.01':'1'} value={f[k]} onChange={e=>setF({...f,[k]:e.target.value})}/>}</label>)}</div><div className="actions"><button disabled={!f.name.trim()} onClick={save}>Save supplier</button></div></Modal>}
  </>;
}
