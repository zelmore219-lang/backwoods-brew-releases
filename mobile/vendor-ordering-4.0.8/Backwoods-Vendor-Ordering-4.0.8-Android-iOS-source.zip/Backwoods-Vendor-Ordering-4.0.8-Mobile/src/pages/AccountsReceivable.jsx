import { useMemo, useState } from 'react';
import Modal from '../components/Modal';
import InvoiceView from '../components/InvoiceView';
import { calcOrder, makeId, money, now } from '../lib/helpers';

const METHODS = ['Cash','Check','Credit Card','ACH','Other'];

export default function AccountsReceivable({ data, update }) {
  const [selected, setSelected] = useState(null);
  const [paymentOpen, setPaymentOpen] = useState(null);
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState('Check');
  const [reference, setReference] = useState('');
  const [notes, setNotes] = useState('');
  const [statementCustomer, setStatementCustomer] = useState(null);
  const [error, setError] = useState('');

  const rows = useMemo(() => data.orders.map(order => ({
    order,
    customer: data.customers.find(c => c.id === order.customerId),
    totals: calcOrder(order)
  })).filter(x => x.totals.balance > 0.009).sort((a,b) => new Date(a.order.createdAt) - new Date(b.order.createdAt)), [data.orders, data.customers]);

  const totalDue = rows.reduce((s,r) => s + r.totals.balance, 0);
  const overdue = rows.filter(r => {
    const days = Math.floor((Date.now() - new Date(r.order.createdAt).getTime()) / 86400000);
    const terms = Number(String(r.customer?.terms || '').match(/\d+/)?.[0] || 0);
    return terms > 0 && days > terms;
  });

  const openPayment = row => {
    setPaymentOpen(row);
    setAmount(String(row.totals.balance.toFixed(2)));
    setMethod('Check');
    setReference('');
    setNotes('');
    setError('');
  };

  const savePayment = () => {
    const value = Number(amount || 0);
    if (!value || value <= 0) return setError('Enter a payment amount greater than $0.00.');
    if (value > paymentOpen.totals.balance + 0.009) return setError(`Payment cannot exceed ${money(paymentOpen.totals.balance)}.`);
    if (method === 'Check' && !reference.trim()) return setError('Enter the check number.');
    const payment = {
      id: makeId('pay'), orderId: paymentOpen.order.id, invoiceNumber: paymentOpen.order.invoiceNumber,
      customerId: paymentOpen.order.customerId, amount: value, method,
      checkNumber: method === 'Check' ? reference.trim() : '', reference: method !== 'Check' ? reference.trim() : '',
      notes: notes.trim(), source: 'office', createdAt: now()
    };
    update(d => ({
      ...d,
      payments: [...d.payments, payment],
      orders: d.orders.map(o => o.id === paymentOpen.order.id ? {
        ...o,
        payments: [...(o.payments || []), payment],
        status: calcOrder({...o, payments:[...(o.payments || []), payment]}).balance <= 0.009 ? 'completed' : 'payment_pending',
        updatedAt: now()
      } : o)
    }));
    setPaymentOpen(null);
  };

  const customerStatementRows = statementCustomer ? data.orders
    .filter(o => o.customerId === statementCustomer.id)
    .map(order => ({ order, totals: calcOrder(order) }))
    .sort((a,b) => new Date(a.order.createdAt) - new Date(b.order.createdAt)) : [];

  return <>
    <div className="page-head"><div><h1>Accounts Receivable</h1><p>Track unpaid invoices, collect office payments, and print customer statements.</p></div></div>
    <div className="stats">
      <div className="card"><span>Total outstanding</span><strong>{money(totalDue)}</strong></div>
      <div className="card"><span>Open invoices</span><strong>{rows.length}</strong></div>
      <div className="card"><span>Overdue invoices</span><strong>{overdue.length}</strong></div>
      <div className="card"><span>Payments recorded</span><strong>{data.payments.length}</strong></div>
    </div>
    <div className="panel"><div className="panel-title"><div><h2>Open balances</h2><p>Invoices with a remaining balance.</p></div></div>
      <table><thead><tr><th>Invoice</th><th>Customer</th><th>Terms</th><th>Total</th><th>Paid</th><th>Balance</th><th></th></tr></thead>
      <tbody>{rows.map(row => <tr key={row.order.id} className={overdue.includes(row) ? 'overdue-row' : ''}>
        <td>{row.order.invoiceNumber}<small>{new Date(row.order.createdAt).toLocaleDateString()}</small></td>
        <td>{row.customer?.name}</td><td>{row.customer?.terms || 'Due on receipt'}</td>
        <td>{money(row.totals.total)}</td><td>{money(row.totals.paid)}</td><td><b>{money(row.totals.balance)}</b></td>
        <td><div className="row-actions"><button className="small secondary" onClick={() => setSelected(row.order)}>View</button><button className="small" onClick={() => openPayment(row)}>Payment</button><button className="small secondary" onClick={() => setStatementCustomer(row.customer)}>Statement</button></div></td>
      </tr>)}</tbody></table>{!rows.length && <div className="empty">All invoices are paid.</div>}
    </div>

    {selected && <Modal title={selected.invoiceNumber} wide onClose={() => setSelected(null)}><InvoiceView order={selected} customer={data.customers.find(c => c.id === selected.customerId)} company={data.company}/><div className="actions no-print"><button onClick={() => window.print()}>Print / Save PDF</button></div></Modal>}

    {paymentOpen && <Modal title={`Record payment · ${paymentOpen.order.invoiceNumber}`} onClose={() => setPaymentOpen(null)}>
      {error && <div className="alert">{error}</div>}
      <div className="payment-preview"><span>Invoice total<b>{money(paymentOpen.totals.total)}</b></span><span>Already paid<b>{money(paymentOpen.totals.paid)}</b></span><span>Balance due<b>{money(paymentOpen.totals.balance)}</b></span></div>
      <div className="form-grid"><label>Amount<input type="number" min="0.01" step="0.01" value={amount} onChange={e => setAmount(e.target.value)}/></label><label>Method<select value={method} onChange={e => setMethod(e.target.value)}>{METHODS.map(x => <option key={x}>{x}</option>)}</select></label><label>{method === 'Check' ? 'Check number' : 'Reference'}<input value={reference} onChange={e => setReference(e.target.value)}/></label><label>Notes<input value={notes} onChange={e => setNotes(e.target.value)}/></label></div>
      <div className="actions"><button onClick={savePayment}>Apply payment</button></div>
    </Modal>}

    {statementCustomer && <Modal title={`${statementCustomer.name} statement`} wide onClose={() => setStatementCustomer(null)}>
      <div className="statement-print">
        <div className="invoice-head"><div>{data.company.logo && <img className="invoice-logo" src={data.company.logo} alt="logo"/>}<h1>{data.company.name}</h1><p>{data.company.address}<br/>{data.company.phone}<br/>{data.company.email}</p></div><div className="invoice-meta"><h2>STATEMENT</h2><p>{new Date().toLocaleDateString()}</p></div></div>
        <div className="invoice-grid"><div><b>Customer</b><p>{statementCustomer.name}<br/>{statementCustomer.contact}<br/>{statementCustomer.address}</p></div><div><b>Terms</b><p>{statementCustomer.terms || 'Due on receipt'}</p></div></div>
        <table><thead><tr><th>Date</th><th>Invoice</th><th>Total</th><th>Paid</th><th>Balance</th></tr></thead><tbody>{customerStatementRows.map(r => <tr key={r.order.id}><td>{new Date(r.order.createdAt).toLocaleDateString()}</td><td>{r.order.invoiceNumber}</td><td>{money(r.totals.total)}</td><td>{money(r.totals.paid)}</td><td>{money(r.totals.balance)}</td></tr>)}</tbody></table>
        <div className="totals"><p className="grand"><span>Total due</span><b>{money(customerStatementRows.reduce((s,r) => s + r.totals.balance, 0))}</b></p></div>
      </div><div className="actions no-print"><button onClick={() => window.print()}>Print / Save PDF</button></div>
    </Modal>}
  </>;
}
