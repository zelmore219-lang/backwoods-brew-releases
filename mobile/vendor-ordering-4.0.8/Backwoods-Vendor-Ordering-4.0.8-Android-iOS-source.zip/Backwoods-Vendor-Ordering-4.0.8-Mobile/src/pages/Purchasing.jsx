import { useMemo, useState } from 'react';
import Modal from '../components/Modal';
import BarcodeScanner from '../components/BarcodeScanner';
import { makeId, money, now } from '../lib/helpers';

const poBlank={supplierId:'',expectedDate:'',terms:'Net 30',freight:0,tax:0,supplierInvoiceNumber:'',supplierInvoiceStatus:'not_received',supplierInvoiceDueDate:'',notes:'',items:[]};
const statusOrder=['draft','submitted','partially_received','received','cancelled'];

function calc(po){
  const subtotal=(po.items||[]).reduce((s,i)=>s+Number(i.qty||0)*Number(i.unitCost||0),0);
  const freight=Number(po.freight||0),tax=Number(po.tax||0);
  return {subtotal,freight,tax,total:subtotal+freight+tax};
}
function poNumber(data){return `PO-${new Date().getFullYear()}-${String((data.purchaseOrders||[]).length+1).padStart(5,'0')}`;}

export default function Purchasing({data,update}){
  const [tab,setTab]=useState('orders');
  const [open,setOpen]=useState(false),[editing,setEditing]=useState(null),[f,setF]=useState(poBlank);
  const [receiving,setReceiving]=useState(null),[receiveLines,setReceiveLines]=useState([]),[receiveNote,setReceiveNote]=useState(''),[scanMsg,setScanMsg]=useState('');
  const suppliers=(data.suppliers||[]).filter(s=>s.active!==false);
  const productMap=useMemo(()=>new Map(data.products.map(p=>[p.id,p])),[data.products]);
  const lowStock=data.products.filter(p=>Number(p.onHand)-Number(p.reserved||0)<=Number(p.reorderLevel||0));
  const totals=useMemo(()=>({open:(data.purchaseOrders||[]).filter(p=>['draft','submitted','partially_received'].includes(p.status)).length,onOrder:(data.purchaseOrders||[]).filter(p=>['submitted','partially_received'].includes(p.status)).reduce((s,p)=>s+(p.items||[]).reduce((a,i)=>a+Math.max(0,Number(i.qty||0)-Number(i.receivedQty||0)),0),0),low:lowStock.length}),[data.purchaseOrders,lowStock.length]);

  const startPo=()=>{setEditing(null);setF({...poBlank,supplierId:suppliers[0]?.id||'',expectedDate:new Date(Date.now()+7*86400000).toISOString().slice(0,10)});setOpen(true)};
  const editPo=po=>{setEditing(po.id);setF({...poBlank,...po,items:(po.items||[]).map(i=>({...i}))});setOpen(true)};
  const addLine=()=>setF(v=>({...v,items:[...v.items,{id:makeId('pol'),productId:data.products[0]?.id||'',qty:1,unitCost:Number(data.products[0]?.cost||0),receivedQty:0,lotNumber:'',expirationDate:''}]}));
  const patchLine=(id,patch)=>setF(v=>({...v,items:v.items.map(i=>i.id===id?{...i,...patch}:i)}));
  const removeLine=id=>setF(v=>({...v,items:v.items.filter(i=>i.id!==id)}));
  const savePo=(submit=false)=>{
    if(!f.supplierId||!f.items.length)return;
    update(d=>{
      const amounts=calc(f);const old=d.purchaseOrders.find(p=>p.id===editing);
      const po={...f,...amounts,id:editing||makeId('po'),poNumber:old?.poNumber||poNumber(d),status:submit?'submitted':(old?.status||'draft'),createdAt:old?.createdAt||now(),updatedAt:now(),submittedAt:submit?(old?.submittedAt||now()):old?.submittedAt};
      const purchaseOrders=editing?d.purchaseOrders.map(p=>p.id===editing?po:p):[...d.purchaseOrders,po];
      const audit={id:makeId('audit'),action:submit?'purchase_order_submitted':editing?'purchase_order_updated':'purchase_order_created',entityType:'purchaseOrder',entityId:po.id,summary:po.poNumber,createdAt:now()};
      return {...d,purchaseOrders,auditLogs:[...(d.auditLogs||[]),audit]};
    });setOpen(false);
  };
  const cancelPo=id=>{if(!confirm('Cancel this purchase order?'))return;update(d=>({...d,purchaseOrders:d.purchaseOrders.map(p=>p.id===id?{...p,status:'cancelled',updatedAt:now()}:p)}));};
  const openReceiving=po=>{setReceiving(po);setReceiveLines((po.items||[]).map(i=>({...i,receiveNow:0,damagedQty:0,missingQty:0,lotNumber:i.lotNumber||'',expirationDate:i.expirationDate||''})));setReceiveNote('');setScanMsg('');};
  const patchReceive=(id,patch)=>setReceiveLines(v=>v.map(i=>i.id===id?{...i,...patch}:i));
  const scanReceive=code=>{
    const p=data.products.find(x=>[x.barcode,x.sku].filter(Boolean).some(v=>String(v).toLowerCase()===String(code).toLowerCase()));
    if(!p){setScanMsg(`Barcode ${code} was not found.`);return;}
    const line=receiveLines.find(i=>i.productId===p.id);
    if(!line){setScanMsg(`${p.name} is not on this purchase order.`);return;}
    const remaining=Math.max(0,Number(line.qty||0)-Number(line.receivedQty||0)-Number(line.receiveNow||0));
    if(!remaining){setScanMsg(`${p.name} is already fully received.`);return;}
    patchReceive(line.id,{receiveNow:Number(line.receiveNow||0)+1});setScanMsg(`${p.name}: ${Number(line.receiveNow||0)+1} scanned this receipt.`);
  };
  const completeReceipt=()=>{
    const any=receiveLines.some(i=>Number(i.receiveNow||0)>0||Number(i.damagedQty||0)>0||Number(i.missingQty||0)>0);
    if(!any)return alert('Enter or scan at least one received, damaged, or missing quantity.');
    update(d=>{
      const receiptId=makeId('rcv');
      const movements=[];
      const receivedBase=receiveLines.reduce((s,i)=>s+Number(i.receiveNow||0)*Number(i.unitCost||0),0);
      const extra=Number(receiving.freight||0)+Number(receiving.tax||0);
      const products=d.products.map(p=>{
        const line=receiveLines.find(i=>i.productId===p.id);if(!line)return p;
        const good=Number(line.receiveNow||0);
        const base=good*Number(line.unitCost||0);
        const allocatedExtra=receivedBase>0?extra*(base/receivedBase):0;
        const landedUnitCost=good>0?(base+allocatedExtra)/good:Number(p.cost||0);
        if(good>0)movements.push({id:makeId('mv'),productId:p.id,type:'purchase_receipt',quantity:good,note:`Received on ${receiving.poNumber}${line.lotNumber?` · lot ${line.lotNumber}`:''} · landed cost ${landedUnitCost.toFixed(2)}`,referenceId:receiptId,createdAt:now()});
        return {...p,onHand:Number(p.onHand||0)+good,cost:landedUnitCost,lastSupplierId:receiving.supplierId,lastReceivedAt:good>0?now():p.lastReceivedAt};
      });
      const items=receiveLines.map(i=>({...i,receivedQty:Number(i.receivedQty||0)+Number(i.receiveNow||0),damagedReceivedQty:Number(i.damagedReceivedQty||0)+Number(i.damagedQty||0),missingQtyTotal:Number(i.missingQtyTotal||0)+Number(i.missingQty||0)}));
      const complete=items.every(i=>Number(i.receivedQty||0)>=Number(i.qty||0));
      const updatedPo={...receiving,items,status:complete?'received':'partially_received',receivedAt:complete?now():receiving.receivedAt,updatedAt:now()};
      const receipt={id:receiptId,purchaseOrderId:receiving.id,poNumber:receiving.poNumber,supplierId:receiving.supplierId,items:receiveLines.filter(i=>Number(i.receiveNow||0)>0||Number(i.damagedQty||0)>0||Number(i.missingQty||0)>0).map(i=>({...i,receivedQtyThisReceipt:Number(i.receiveNow||0)})),notes:receiveNote,freight:Number(receiving.freight||0),tax:Number(receiving.tax||0),landedCostTotal:receivedBase+extra,createdAt:now()};
      return {...d,products,purchaseOrders:d.purchaseOrders.map(p=>p.id===receiving.id?updatedPo:p),purchaseReceipts:[...(d.purchaseReceipts||[]),receipt],inventoryMovements:[...(d.inventoryMovements||[]),...movements],auditLogs:[...(d.auditLogs||[]),{id:makeId('audit'),action:'purchase_order_received',entityType:'purchaseOrder',entityId:receiving.id,summary:`${receiving.poNumber} · ${items.reduce((s,i)=>s+Number(i.receiveNow||0),0)} units`,createdAt:now()}]};
    });setReceiving(null);
  };
  const createSuggested=product=>{const supplier=product.lastSupplierId||suppliers[0]?.id;if(!supplier)return alert('Add a supplier first.');const target=Math.max(Number(product.reorderLevel||0)*2,Number(product.caseQty||1));const qty=Math.max(Number(product.caseQty||1),target-(Number(product.onHand||0)-Number(product.reserved||0)));setEditing(null);setF({...poBlank,supplierId:supplier,expectedDate:new Date(Date.now()+7*86400000).toISOString().slice(0,10),items:[{id:makeId('pol'),productId:product.id,qty,unitCost:Number(product.cost||0),receivedQty:0,lotNumber:'',expirationDate:''}]});setOpen(true);};

  return <>
    <div className="page-head"><div><h1>Purchasing & Receiving</h1><p>Create purchase orders, receive shipments by barcode, and update inventory automatically.</p></div><button onClick={startPo}>New purchase order</button></div>
    <div className="packing-summary"><div className="card"><span>Open POs</span><strong>{totals.open}</strong></div><div className="card"><span>Units on order</span><strong>{totals.onOrder}</strong></div><div className="card"><span>Low-stock products</span><strong>{totals.low}</strong></div></div>
    <div className="report-tabs"><button className={tab==='orders'?'active':''} onClick={()=>setTab('orders')}>Purchase orders</button><button className={tab==='reorder'?'active':''} onClick={()=>setTab('reorder')}>Reorder suggestions</button><button className={tab==='receipts'?'active':''} onClick={()=>setTab('receipts')}>Receiving history</button></div>
    {tab==='orders'&&<div className="panel table-scroll"><table><thead><tr><th>PO</th><th>Supplier</th><th>Status</th><th>Expected</th><th>Received</th><th>Supplier invoice</th><th>Total</th><th></th></tr></thead><tbody>{[...(data.purchaseOrders||[])].sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt))).map(po=>{const q=(po.items||[]).reduce((s,i)=>s+Number(i.qty||0),0),r=(po.items||[]).reduce((s,i)=>s+Number(i.receivedQty||0),0);return <tr key={po.id}><td><b>{po.poNumber}</b><small>{po.items?.length||0} lines</small></td><td>{data.suppliers.find(s=>s.id===po.supplierId)?.name||'Unknown'}</td><td><span className="status">{po.status.replaceAll('_',' ')}</span></td><td>{po.expectedDate||'—'}</td><td>{r} / {q}</td><td>{po.supplierInvoiceNumber||'—'}<small>{String(po.supplierInvoiceStatus||'not_received').replaceAll('_',' ')}</small></td><td>{money(po.total)}</td><td><div className="actions"><button className="small secondary" onClick={()=>editPo(po)}>Open</button>{['submitted','partially_received'].includes(po.status)&&<button className="small" onClick={()=>openReceiving(po)}>Receive</button>}{['draft','submitted'].includes(po.status)&&<button className="small danger" onClick={()=>cancelPo(po.id)}>Cancel</button>}</div></td></tr>})}</tbody></table>{!(data.purchaseOrders||[]).length&&<div className="empty">No purchase orders yet.</div>}</div>}
    {tab==='reorder'&&<div className="panel"><table><thead><tr><th>Product</th><th>Available</th><th>Reorder level</th><th>Suggested supplier</th><th></th></tr></thead><tbody>{lowStock.map(p=><tr key={p.id}><td><b>{p.name}</b><small>{p.sku}</small></td><td>{Number(p.onHand)-Number(p.reserved||0)}</td><td>{p.reorderLevel||0}</td><td>{data.suppliers.find(s=>s.id===p.lastSupplierId)?.name||'Not assigned'}</td><td><button className="small" onClick={()=>createSuggested(p)}>Create PO</button></td></tr>)}</tbody></table>{!lowStock.length&&<div className="empty">All products are above their reorder levels.</div>}</div>}
    {tab==='receipts'&&<div className="panel table-scroll"><table><thead><tr><th>Date</th><th>PO</th><th>Supplier</th><th>Received</th><th>Damaged</th><th>Missing</th><th>Notes</th></tr></thead><tbody>{[...(data.purchaseReceipts||[])].sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt))).map(r=><tr key={r.id}><td>{new Date(r.createdAt).toLocaleString()}</td><td>{r.poNumber}</td><td>{data.suppliers.find(s=>s.id===r.supplierId)?.name||'Unknown'}</td><td>{r.items.reduce((s,i)=>s+Number(i.receivedQtyThisReceipt||0),0)}</td><td>{r.items.reduce((s,i)=>s+Number(i.damagedQty||0),0)}</td><td>{r.items.reduce((s,i)=>s+Number(i.missingQty||0),0)}</td><td>{r.notes||'—'}</td></tr>)}</tbody></table>{!(data.purchaseReceipts||[]).length&&<div className="empty">No shipments have been received.</div>}</div>}

    {open&&<Modal title={editing?'Edit purchase order':'New purchase order'} wide onClose={()=>setOpen(false)}><div className="form-grid"><label>Supplier<select value={f.supplierId} onChange={e=>setF({...f,supplierId:e.target.value,terms:data.suppliers.find(s=>s.id===e.target.value)?.terms||f.terms})}><option value="">Select supplier</option>{suppliers.map(s=><option key={s.id} value={s.id}>{s.name}</option>)}</select></label><label>Expected date<input type="date" value={f.expectedDate} onChange={e=>setF({...f,expectedDate:e.target.value})}/></label><label>Terms<input value={f.terms} onChange={e=>setF({...f,terms:e.target.value})}/></label><label>Freight<input type="number" step="0.01" value={f.freight} onChange={e=>setF({...f,freight:e.target.value})}/></label><label>Tax<input type="number" step="0.01" value={f.tax} onChange={e=>setF({...f,tax:e.target.value})}/></label><label>Supplier invoice #<input value={f.supplierInvoiceNumber} onChange={e=>setF({...f,supplierInvoiceNumber:e.target.value})}/></label><label>Invoice status<select value={f.supplierInvoiceStatus} onChange={e=>setF({...f,supplierInvoiceStatus:e.target.value})}><option value="not_received">Not received</option><option value="unpaid">Unpaid</option><option value="partially_paid">Partially paid</option><option value="paid">Paid</option></select></label><label>Invoice due date<input type="date" value={f.supplierInvoiceDueDate} onChange={e=>setF({...f,supplierInvoiceDueDate:e.target.value})}/></label><label>Notes<input value={f.notes} onChange={e=>setF({...f,notes:e.target.value})}/></label></div><div className="panel inset"><div className="panel-title"><h3>Products</h3><button className="small" onClick={addLine}>Add line</button></div><div className="table-scroll"><table><thead><tr><th>Product</th><th>Qty</th><th>Unit cost</th><th>Line total</th><th>Lot</th><th>Expiration</th><th></th></tr></thead><tbody>{f.items.map(i=><tr key={i.id}><td><select value={i.productId} onChange={e=>{const p=productMap.get(e.target.value);patchLine(i.id,{productId:e.target.value,unitCost:Number(p?.cost||0)})}}>{data.products.map(p=><option key={p.id} value={p.id}>{p.name}</option>)}</select></td><td><input type="number" min="1" value={i.qty} onChange={e=>patchLine(i.id,{qty:e.target.value})}/></td><td><input type="number" min="0" step="0.01" value={i.unitCost} onChange={e=>patchLine(i.id,{unitCost:e.target.value})}/></td><td>{money(Number(i.qty)*Number(i.unitCost))}</td><td><input value={i.lotNumber||''} onChange={e=>patchLine(i.id,{lotNumber:e.target.value})}/></td><td><input type="date" value={i.expirationDate||''} onChange={e=>patchLine(i.id,{expirationDate:e.target.value})}/></td><td><button className="small danger" onClick={()=>removeLine(i.id)}>Remove</button></td></tr>)}</tbody></table></div><div className="purchase-total"><span>Subtotal <b>{money(calc(f).subtotal)}</b></span><span>Freight <b>{money(calc(f).freight)}</b></span><span>Total <b>{money(calc(f).total)}</b></span></div></div><div className="actions"><button className="secondary" disabled={!f.supplierId||!f.items.length} onClick={()=>savePo(false)}>Save draft</button><button disabled={!f.supplierId||!f.items.length} onClick={()=>savePo(true)}>Submit purchase order</button><button className="secondary" onClick={()=>window.print()}>Print</button></div></Modal>}

    {receiving&&<Modal title={`Receive ${receiving.poNumber}`} wide onClose={()=>setReceiving(null)}><div className="scan-pack-box"><h3>Scan received products</h3><BarcodeScanner onScan={scanReceive}/>{scanMsg&&<div className="success-note">{scanMsg}</div>}</div><div className="table-scroll"><table><thead><tr><th>Product</th><th>Ordered</th><th>Previously received</th><th>Receive now</th><th>Damaged</th><th>Missing/backorder</th><th>Lot</th><th>Expiration</th></tr></thead><tbody>{receiveLines.map(i=>{const p=productMap.get(i.productId);const remaining=Math.max(0,Number(i.qty)-Number(i.receivedQty||0));return <tr key={i.id}><td><b>{p?.name}</b><small>{p?.sku}</small></td><td>{i.qty}</td><td>{i.receivedQty||0}</td><td><input type="number" min="0" max={remaining} value={i.receiveNow} onChange={e=>patchReceive(i.id,{receiveNow:Math.min(remaining,Number(e.target.value||0))})}/></td><td><input type="number" min="0" value={i.damagedQty} onChange={e=>patchReceive(i.id,{damagedQty:Number(e.target.value||0)})}/></td><td><input type="number" min="0" value={i.missingQty} onChange={e=>patchReceive(i.id,{missingQty:Number(e.target.value||0)})}/></td><td><input value={i.lotNumber||''} onChange={e=>patchReceive(i.id,{lotNumber:e.target.value})}/></td><td><input type="date" value={i.expirationDate||''} onChange={e=>patchReceive(i.id,{expirationDate:e.target.value})}/></td></tr>})}</tbody></table></div><label>Receiving notes<textarea value={receiveNote} onChange={e=>setReceiveNote(e.target.value)} placeholder="Carrier, bill of lading, damages, shortages, or backorder notes"/></label><div className="actions"><button onClick={completeReceipt}>Post receipt and update inventory</button></div></Modal>}
  </>;
}
