import { now } from '../lib/helpers';
export default function Notifications({data,update}){
 const alerts=[];
 data.products.filter(p=>Number(p.onHand)-Number(p.reserved||0)<=Number(p.reorderLevel||0)).forEach(p=>alerts.push({id:`stock_${p.id}`,title:'Low stock',text:`${p.name} has ${Number(p.onHand)-Number(p.reserved||0)} available.`,level:'warning'}));
 data.customers.filter(c=>Number(c.creditLimit||0)>0&&Number(c.balance||0)>=Number(c.creditLimit||0)).forEach(c=>alerts.push({id:`credit_${c.id}`,title:'Credit limit reached',text:`${c.name} has a balance of $${Number(c.balance||0).toFixed(2)}.`,level:'danger'}));
 data.orders.filter(o=>o.status==='packed').forEach(o=>alerts.push({id:`packed_${o.id}`,title:'Order ready',text:`${o.orderNumber} is packed and ready for delivery.`,level:'success'}));
 const custom=(data.notifications||[]).filter(n=>n.type!=='route_visit');
 const all=[...alerts,...custom].slice(0,100);
 const markAll=()=>update(d=>({...d,notifications:(d.notifications||[]).map(n=>({...n,read:true,readAt:now()}))}));
 return <><div className="page-head"><div><h1>Notifications</h1><p>Inventory, credit, packing, route, and account alerts.</p></div><button onClick={markAll}>Mark all read</button></div><div className="alert-list">{all.map(a=><div className={`panel alert-card ${a.level||''}`} key={a.id}><div><b>{a.title||a.type?.replaceAll('_',' ')}</b><p>{a.text||a.message}</p></div><span>{a.read?'Read':'New'}</span></div>)}</div>{!all.length&&<div className="panel empty">No active alerts.</div>}</>;
}
