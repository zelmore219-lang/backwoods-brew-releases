import { useState } from 'react';
import { Download, Upload } from 'lucide-react';
import { downloadCsvTemplate, parseBool, parseNumber, pick, rowsFromCsv } from '../lib/csv';
import { makeId, now } from '../lib/helpers';

const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
const cleanKey = value => String(value || '').trim().toLowerCase();
const routeDay = value => days.find(day => day.toLowerCase().startsWith(cleanKey(value).slice(0, 3))) || 'Monday';
const productHeaders = ['sku', 'barcode', 'name', 'category', 'subcategory', 'unit', 'caseQty', 'price', 'cost', 'onHand', 'location', 'reorderLevel'];
const storeHeaders = ['storeNumber', 'name', 'contact', 'phone', 'email', 'address', 'city', 'state', 'zip', 'terms', 'route', 'day', 'deliveryWindow', 'salesperson', 'taxExempt', 'taxRate', 'creditLimit'];
const routeHeaders = ['route', 'day', 'driver', 'stop', 'storeNumber', 'storeName', 'address', 'city', 'phone', 'deliveryInstructions'];

const templateRows = {
  products: [{ sku: 'MC-10', barcode: '012345678905', name: 'Midnight Campfire 10 oz', category: 'Coffee', subcategory: 'Bagged Coffee', unit: 'bag', caseQty: 6, price: 8.5, cost: 4.1, onHand: 120, location: 'A-01', reorderLevel: 12 }],
  stores: [{ storeNumber: '101', name: 'Pine Hill Market', contact: 'Jordan Smith', phone: '256-555-0133', email: 'orders@pinehill.example', address: '100 Main Street', city: 'Oxford', state: 'AL', zip: '36203', terms: 'Net 14', route: 'Oxford North', day: 'Monday', deliveryWindow: '8:00-11:00 AM', salesperson: 'Sales Rep', taxExempt: 'no', taxRate: '', creditLimit: 1000 }],
  routes: [{ route: 'Oxford North', day: 'Monday', driver: 'Driver Name', stop: 1, storeNumber: '101', storeName: 'Pine Hill Market', address: '100 Main Street', city: 'Oxford', phone: '256-555-0133', deliveryInstructions: 'Use back door' }]
};

async function readCsvFile(file) {
  if (!file) return [];
  return rowsFromCsv(await file.text());
}

function findProduct(products, row) {
  const sku = cleanKey(pick(row, ['sku']));
  const barcode = cleanKey(pick(row, ['barcode', 'upc']));
  return products.find(product =>
    (sku && cleanKey(product.sku) === sku) ||
    (barcode && cleanKey(product.barcode || product.upc) === barcode)
  );
}

function findStore(customers, row) {
  const storeNumber = cleanKey(pick(row, ['storeNumber', 'number', 'storeNo']));
  const name = cleanKey(pick(row, ['name', 'storeName', 'store', 'customer']));
  return customers.find(customer =>
    (storeNumber && cleanKey(customer.storeNumber) === storeNumber) ||
    (name && cleanKey(customer.name) === name)
  );
}

function findRoute(routes, name, day) {
  const key = cleanKey(name);
  return routes.find(route => cleanKey(route.name) === key && (!day || route.dayOfWeek === day));
}

function ensureRoute(routes, name, day, driverName = '') {
  if (!name) return null;
  const existing = findRoute(routes, name, day);
  if (existing) return existing;
  const route = {
    id: makeId('route'),
    name,
    dayOfWeek: day || 'Monday',
    driverId: '',
    driverName,
    storeIds: [],
    notes: 'Imported from CSV',
    status: 'active',
    createdAt: now(),
    updatedAt: now()
  };
  routes.push(route);
  return route;
}

function mergeRouteStop(routes, routeId, customerId) {
  if (!routeId || !customerId) return routes;
  return routes.map(route => {
    const storeIds = (route.storeIds || []).filter(id => id !== customerId);
    return route.id === routeId ? { ...route, storeIds: [...storeIds, customerId], updatedAt: now() } : { ...route, storeIds, updatedAt: now() };
  });
}

export default function ImportTools({ data, update }) {
  const [message, setMessage] = useState('');

  const importProducts = async event => {
    const rows = await readCsvFile(event.target.files?.[0]);
    event.target.value = '';
    if (!rows.length) return setMessage('No product rows found.');
    update(d => {
      const products = [...(d.products || [])];
      const movements = [...(d.inventoryMovements || [])];
      rows.forEach(row => {
        const existing = findProduct(products, row);
        const product = {
          ...(existing || { id: makeId('p'), reserved: 0, damagedStock: 0, expiredStock: 0, quarantineStock: 0 }),
          sku: pick(row, ['sku'], existing?.sku || ''),
          barcode: pick(row, ['barcode', 'upc'], existing?.barcode || ''),
          name: pick(row, ['name', 'productName', 'product'], existing?.name || ''),
          category: pick(row, ['category'], existing?.category || 'Coffee'),
          subcategory: pick(row, ['subcategory', 'subCategory'], existing?.subcategory || 'Bagged Coffee'),
          unit: pick(row, ['unit'], existing?.unit || 'each'),
          caseQty: parseNumber(pick(row, ['caseQty', 'caseQuantity'], existing?.caseQty || 1), 1),
          price: parseNumber(pick(row, ['price', 'wholesalePrice'], existing?.price || 0), 0),
          cost: parseNumber(pick(row, ['cost'], existing?.cost || 0), 0),
          onHand: parseNumber(pick(row, ['onHand', 'stock', 'inventory'], existing?.onHand || 0), 0),
          location: pick(row, ['location', 'warehouseLocation'], existing?.location || ''),
          reorderLevel: parseNumber(pick(row, ['reorderLevel', 'reorder'], existing?.reorderLevel || 10), 10)
        };
        if (!product.sku || !product.name) return;
        const oldOnHand = Number(existing?.onHand || 0);
        const delta = Number(product.onHand || 0) - oldOnHand;
        if (existing) products[products.findIndex(item => item.id === existing.id)] = product;
        else products.push(product);
        if (delta !== 0) movements.push({ id: makeId('mov'), productId: product.id, type: existing ? 'csv_adjustment' : 'csv_opening_balance', quantity: delta, reference: product.sku, note: 'CSV product import', createdAt: now() });
      });
      return { ...d, products, inventoryMovements: movements };
    });
    setMessage(`Imported ${rows.length} product row(s).`);
  };

  const importStores = async event => {
    const rows = await readCsvFile(event.target.files?.[0]);
    event.target.value = '';
    if (!rows.length) return setMessage('No store rows found.');
    update(d => {
      let customers = [...(d.customers || [])];
      let routePlans = [...(d.routePlans || [])];
      rows.forEach(row => {
        const existing = findStore(customers, row);
        const routeName = pick(row, ['route', 'routeName']);
        const day = routeDay(pick(row, ['day', 'dayOfWeek'], 'Monday'));
        const route = ensureRoute(routePlans, routeName, day);
        const id = existing?.id || makeId('c');
        const customer = {
          ...(existing || { id, balance: 0, approvedProductIds: [], favoriteProductIds: [], customPrices: {} }),
          id,
          storeNumber: pick(row, ['storeNumber', 'number', 'storeNo'], existing?.storeNumber || ''),
          name: pick(row, ['name', 'storeName', 'store', 'customer'], existing?.name || ''),
          contact: pick(row, ['contact'], existing?.contact || ''),
          phone: pick(row, ['phone'], existing?.phone || ''),
          email: pick(row, ['email'], existing?.email || ''),
          address: pick(row, ['address', 'street'], existing?.address || ''),
          city: pick(row, ['city'], existing?.city || ''),
          state: pick(row, ['state'], existing?.state || 'AL'),
          zip: pick(row, ['zip', 'postal'], existing?.zip || ''),
          terms: pick(row, ['terms'], existing?.terms || 'Net 14'),
          routeId: route?.id || existing?.routeId || '',
          deliveryWindow: pick(row, ['deliveryWindow', 'window'], existing?.deliveryWindow || ''),
          salesperson: pick(row, ['salesperson', 'rep'], existing?.salesperson || ''),
          taxExempt: parseBool(pick(row, ['taxExempt'], existing?.taxExempt ? 'yes' : 'no')),
          taxRate: pick(row, ['taxRate'], existing?.taxRate ?? ''),
          creditLimit: parseNumber(pick(row, ['creditLimit'], existing?.creditLimit || 0), 0),
          deliveryInstructions: pick(row, ['deliveryInstructions', 'instructions'], existing?.deliveryInstructions || ''),
          notes: pick(row, ['notes'], existing?.notes || '')
        };
        if (!customer.name) return;
        customers = existing ? customers.map(item => item.id === existing.id ? customer : item) : [...customers, customer];
        routePlans = mergeRouteStop(routePlans, customer.routeId, customer.id);
      });
      return { ...d, customers, routePlans };
    });
    setMessage(`Imported ${rows.length} store row(s).`);
  };

  const importRoutes = async event => {
    const rows = await readCsvFile(event.target.files?.[0]);
    event.target.value = '';
    if (!rows.length) return setMessage('No route rows found.');
    update(d => {
      let customers = [...(d.customers || [])];
      let routePlans = [...(d.routePlans || [])];
      const groups = new Map();
      rows.forEach(row => {
        const name = pick(row, ['route', 'routeName', 'name']);
        if (!name) return;
        const day = routeDay(pick(row, ['day', 'dayOfWeek'], 'Monday'));
        const key = `${cleanKey(name)}|${day}`;
        const current = groups.get(key) || { name, day, driverName: pick(row, ['driver', 'driverName']), rows: [] };
        current.rows.push(row);
        groups.set(key, current);
      });

      groups.forEach(group => {
        const route = ensureRoute(routePlans, group.name, group.day, group.driverName);
        const importedStops = group.rows
          .map(row => {
            let customer = findStore(customers, row);
            const storeName = pick(row, ['storeName', 'store', 'customer']);
            if (!customer && storeName) {
              customer = {
                id: makeId('c'),
                storeNumber: pick(row, ['storeNumber', 'number', 'storeNo']),
                name: storeName,
                contact: '',
                phone: pick(row, ['phone']),
                email: '',
                address: pick(row, ['address']),
                city: pick(row, ['city']),
                state: pick(row, ['state'], 'AL'),
                zip: pick(row, ['zip']),
                terms: 'Net 14',
                routeId: route.id,
                balance: 0,
                deliveryInstructions: pick(row, ['deliveryInstructions', 'instructions']),
                approvedProductIds: [],
                favoriteProductIds: [],
                customPrices: {}
              };
              customers.push(customer);
            }
            return customer ? { id: customer.id, stop: parseNumber(pick(row, ['stop', 'sequence', 'order'], 9999), 9999) } : null;
          })
          .filter(Boolean)
          .sort((a, b) => a.stop - b.stop)
          .map(stop => stop.id);
        const uniqueStops = [...new Set(importedStops)];
        routePlans = routePlans.map(item => item.id === route.id ? {
          ...item,
          driverName: group.driverName || item.driverName || '',
          storeIds: uniqueStops.length ? [...uniqueStops, ...(item.storeIds || []).filter(id => !uniqueStops.includes(id))] : item.storeIds || [],
          updatedAt: now()
        } : item);
        customers = customers.map(customer => uniqueStops.includes(customer.id) ? { ...customer, routeId: route.id } : customer);
      });
      return { ...d, customers, routePlans };
    });
    setMessage(`Imported ${rows.length} route row(s).`);
  };

  return <>
    <div className="page-head">
      <div><h1>Import Tools</h1><p>Load products, stores, and route stops from CSV files.</p></div>
    </div>

    {message && <div className="notice">{message}</div>}

    <div className="import-grid">
      <ImportCard title="Products" description="SKU, UPC, price, cost, stock, category, case quantity, and warehouse location." headers={productHeaders} rows={templateRows.products} onImport={importProducts}/>
      <ImportCard title="Stores" description="Store details, terms, taxes, credit limit, delivery window, and assigned route/day." headers={storeHeaders} rows={templateRows.stores} onImport={importStores}/>
      <ImportCard title="Routes" description="Route names, dedicated days, drivers, stop order, and store assignments." headers={routeHeaders} rows={templateRows.routes} onImport={importRoutes}/>
    </div>
  </>;
}

function ImportCard({ title, description, headers, rows, onImport }) {
  return <section className="panel import-card">
    <div><h2>{title}</h2><p>{description}</p></div>
    <div className="import-actions">
      <button className="secondary" onClick={() => downloadCsvTemplate(`backwoods-${title.toLowerCase()}-template.csv`, headers, rows)}><Download size={17}/>Template</button>
      <label className="file-button"><Upload size={17}/>Import CSV<input type="file" accept=".csv,text/csv" onChange={onImport}/></label>
    </div>
    <small>{headers.join(', ')}</small>
  </section>;
}
