import { useMemo, useState } from 'react';
import Modal from '../components/Modal';
import { makeId, money } from '../lib/helpers';

const blank = {
  name: '',
  storeNumber: '',
  contact: '',
  phone: '',
  email: '',
  address: '',
  city: '',
  state: 'AL',
  zip: '',
  terms: 'Net 14',
  priceLevel: 'Wholesale',
  creditLimit: 0,
  routeId: '',
  notes: '',
  deliveryInstructions: '',
  deliveryWindow: '',
  salesperson: '',
  gps: '',
  accountHold: false,
  taxExempt: false,
  taxRate: '',
  approvedProductIds: [],
  favoriteProductIds: [],
  customPrices: {}
};

const syncRouteStops = (routePlans, customerId, routeId) => (routePlans || []).map(route => {
  const storeIds = (route.storeIds || []).filter(id => id !== customerId);
  return route.id === routeId ? { ...route, storeIds: [...storeIds, customerId] } : { ...route, storeIds };
});

export default function Customers({ data, update }) {
  const [open, setOpen] = useState(false);
  const [catalogOpen, setCatalogOpen] = useState(false);
  const [f, setF] = useState(blank);
  const [editing, setEditing] = useState(null);
  const [search, setSearch] = useState('');
  const [catalogSearch, setCatalogSearch] = useState('');
  const routes = data.routePlans || [];
  const filtered = useMemo(() => data.customers.filter(c => `${c.name} ${c.storeNumber || ''} ${c.city || ''} ${c.address || ''}`.toLowerCase().includes(search.toLowerCase())), [data.customers, search]);
  const catalogProducts = useMemo(() => data.products.filter(p => `${p.name} ${p.sku} ${p.category} ${p.subcategory || ''}`.toLowerCase().includes(catalogSearch.toLowerCase())), [data.products, catalogSearch]);

  const openStore = c => {
    setEditing(c?.id || null);
    setF(c ? { ...blank, ...c, approvedProductIds: c.approvedProductIds || [], favoriteProductIds: c.favoriteProductIds || [], customPrices: c.customPrices || {}, taxRate: c.taxRate ?? '' } : blank);
    setOpen(true);
  };
  const manageCatalog = c => {
    setEditing(c.id);
    setF({ ...blank, ...c, approvedProductIds: c.approvedProductIds || [], favoriteProductIds: c.favoriteProductIds || [], customPrices: c.customPrices || {}, taxRate: c.taxRate ?? '' });
    setCatalogOpen(true);
  };
  const save = () => {
    update(d => {
      const id = editing || makeId('c');
      const existing = d.customers.find(c => c.id === editing);
      const customer = {
        ...f,
        id,
        balance: editing ? Number(existing?.balance || 0) : 0,
        creditLimit: Number(f.creditLimit || 0),
        taxExempt: Boolean(f.taxExempt),
        taxRate: f.taxRate === '' || f.taxRate == null ? '' : Number(f.taxRate)
      };
      return {
        ...d,
        customers: editing ? d.customers.map(c => c.id === editing ? customer : c) : [...d.customers, customer],
        routePlans: syncRouteStops(d.routePlans, id, customer.routeId)
      };
    });
    setOpen(false);
    setEditing(null);
    setF(blank);
  };
  const saveCatalog = () => {
    update(d => ({
      ...d,
      customers: d.customers.map(c => c.id === editing ? { ...c, approvedProductIds: f.approvedProductIds || [], favoriteProductIds: f.favoriteProductIds || [], customPrices: f.customPrices || {} } : c)
    }));
    setCatalogOpen(false);
    setEditing(null);
    setF(blank);
  };
  const routeName = id => routes.find(r => r.id === id)?.name || 'Unassigned';
  const toggle = (key, id) => setF(x => ({ ...x, [key]: (x[key] || []).includes(id) ? x[key].filter(v => v !== id) : [...(x[key] || []), id] }));

  return <>
    <div className="page-head"><div><h1>Stores</h1><p>Manage store details, routes, delivery windows, terms, taxes, approved products, favorites, and store-specific pricing.</p></div><button onClick={() => openStore(null)}>Add store</button></div>
    <div className="panel toolbar-panel"><input className="search-input" value={search} onChange={e => setSearch(e.target.value)} placeholder="Search stores by name, number, city, or address"/></div>
    <div className="panel table-scroll">
      <table>
        <thead><tr><th>Store</th><th>Contact</th><th>Route</th><th>Terms / tax</th><th>Catalog</th><th>Balance</th><th></th></tr></thead>
        <tbody>{filtered.map(c => <tr key={c.id}>
          <td><b>{c.name}</b>{c.accountHold && <span className="status danger-status">On hold</span>}<small>{c.storeNumber ? `#${c.storeNumber} - ` : ''}{c.address}{c.city ? `, ${c.city}` : ''}</small></td>
          <td>{c.contact}<small>{c.phone}{c.email ? ` - ${c.email}` : ''}</small></td>
          <td><span className="status">{routeName(c.routeId)}</span><small>{c.deliveryWindow || ''}</small></td>
          <td>{c.terms}<small>{c.taxExempt ? 'Tax exempt' : c.taxRate !== '' && c.taxRate != null ? `${c.taxRate}% tax` : 'Company tax'} - {c.priceLevel || 'Wholesale'}</small></td>
          <td>{(c.approvedProductIds || []).length || 'All'} approved<small>{(c.favoriteProductIds || []).length} favorites</small></td>
          <td>{money(c.balance)}<small>Limit {money(c.creditLimit || 0)}</small></td>
          <td><div className="row-actions"><button className="small secondary" onClick={() => manageCatalog(c)}>Catalog</button><button className="small" onClick={() => openStore(c)}>Edit</button></div></td>
        </tr>)}</tbody>
      </table>
      {!filtered.length && <p className="empty">No stores match your search.</p>}
    </div>

    {open && <Modal title={editing ? 'Edit store' : 'Add store'} wide onClose={() => setOpen(false)}>
      <div className="form-grid">
        <label>Store name<input value={f.name} onChange={e => setF({ ...f, name: e.target.value })}/></label>
        <label>Store number<input value={f.storeNumber} onChange={e => setF({ ...f, storeNumber: e.target.value })}/></label>
        <label>Contact<input value={f.contact} onChange={e => setF({ ...f, contact: e.target.value })}/></label>
        <label>Phone<input value={f.phone} onChange={e => setF({ ...f, phone: e.target.value })}/></label>
        <label>Email<input value={f.email} onChange={e => setF({ ...f, email: e.target.value })}/></label>
        <label>Address<input value={f.address} onChange={e => setF({ ...f, address: e.target.value })}/></label>
        <label>City<input value={f.city} onChange={e => setF({ ...f, city: e.target.value })}/></label>
        <label>State<input value={f.state} onChange={e => setF({ ...f, state: e.target.value })}/></label>
        <label>ZIP<input value={f.zip} onChange={e => setF({ ...f, zip: e.target.value })}/></label>
        <label>GPS coordinates<input value={f.gps} onChange={e => setF({ ...f, gps: e.target.value })} placeholder="33.6143,-85.8349"/></label>
        <label>Dedicated route<select value={f.routeId} onChange={e => setF({ ...f, routeId: e.target.value })}><option value="">Unassigned</option>{routes.map(r => <option key={r.id} value={r.id}>{r.name} - {r.dayOfWeek}</option>)}</select></label>
        <label>Delivery window<input value={f.deliveryWindow} onChange={e => setF({ ...f, deliveryWindow: e.target.value })} placeholder="8:00-11:00 AM"/></label>
        <label>Salesperson<input value={f.salesperson} onChange={e => setF({ ...f, salesperson: e.target.value })}/></label>
        <label>Terms<input value={f.terms} onChange={e => setF({ ...f, terms: e.target.value })}/></label>
        <label>Price level<input value={f.priceLevel} onChange={e => setF({ ...f, priceLevel: e.target.value })}/></label>
        <label>Credit limit<input type="number" value={f.creditLimit} onChange={e => setF({ ...f, creditLimit: e.target.value })}/></label>
        <label>Account hold<select value={f.accountHold ? 'yes' : 'no'} onChange={e => setF({ ...f, accountHold: e.target.value === 'yes' })}><option value="no">No</option><option value="yes">Yes</option></select></label>
        <label>Tax exempt<select value={f.taxExempt ? 'yes' : 'no'} onChange={e => setF({ ...f, taxExempt: e.target.value === 'yes' })}><option value="no">No</option><option value="yes">Yes</option></select></label>
        <label>Store tax rate (%)<input type="number" min="0" max="100" step="0.01" value={f.taxRate} onChange={e => setF({ ...f, taxRate: e.target.value })} placeholder="Use company default"/></label>
        <label className="span-2">Delivery instructions<textarea value={f.deliveryInstructions} onChange={e => setF({ ...f, deliveryInstructions: e.target.value })}/></label>
        <label className="span-2">Notes<textarea value={f.notes} onChange={e => setF({ ...f, notes: e.target.value })}/></label>
      </div>
      <div className="actions"><button disabled={!f.name} onClick={save}>Save store</button></div>
    </Modal>}

    {catalogOpen && <Modal title={`${f.name} product catalog`} wide onClose={() => setCatalogOpen(false)}>
      <p className="muted">Leave approved products empty to allow every product. Mark favorites for one-tap ordering and enter custom prices only where needed.</p>
      <input value={catalogSearch} onChange={e => setCatalogSearch(e.target.value)} placeholder="Search products"/>
      <div className="catalog-table"><table><thead><tr><th>Product</th><th>Approved</th><th>Favorite</th><th>Default</th><th>Store price</th></tr></thead><tbody>{catalogProducts.map(p => <tr key={p.id}>
        <td><b>{p.name}</b><small>{p.category} / {p.subcategory} - {p.sku}</small></td>
        <td><input type="checkbox" checked={(f.approvedProductIds || []).includes(p.id)} onChange={() => toggle('approvedProductIds', p.id)}/></td>
        <td><input type="checkbox" checked={(f.favoriteProductIds || []).includes(p.id)} onChange={() => toggle('favoriteProductIds', p.id)}/></td>
        <td>{money(p.price)}</td>
        <td><input className="price" type="number" step="0.01" placeholder={String(p.price)} value={f.customPrices?.[p.id] ?? ''} onChange={e => setF(x => ({ ...x, customPrices: { ...(x.customPrices || {}), [p.id]: e.target.value === '' ? '' : Number(e.target.value) } }))}/></td>
      </tr>)}</tbody></table></div>
      <div className="actions"><button onClick={saveCatalog}>Save store catalog</button></div>
    </Modal>}
  </>;
}
