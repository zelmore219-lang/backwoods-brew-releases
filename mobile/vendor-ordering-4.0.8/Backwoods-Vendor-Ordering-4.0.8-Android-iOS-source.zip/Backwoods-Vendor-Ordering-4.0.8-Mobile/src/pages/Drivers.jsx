import { getCurrentLocation } from '../lib/mobile';
import { useEffect, useMemo, useRef, useState } from 'react';
import SignaturePad from 'signature_pad';
import Modal from '../components/Modal';
import InvoiceView from '../components/InvoiceView';
import { useAuth } from '../auth/AuthContext';
import { calcOrder, makeId, money, now } from '../lib/helpers';

const methods = ['Cash', 'Check', 'Credit Card', 'ACH', 'Net Terms', 'No Payment'];

function deliveryLine(item) {
  const packedQty = Number(item.packedQty ?? item.qty ?? 0);
  return {
    ...item,
    packedQty,
    deliveredQty: Number(item.deliveredQty ?? packedQty),
    refusedQty: Number(item.refusedQty ?? 0),
    deliveryNote: item.deliveryNote || ''
  };
}

export default function Drivers({ data, update }) {
  const { user } = useAuth();
  const [selected, setSelected] = useState(null);
  const [lines, setLines] = useState([]);
  const [method, setMethod] = useState('Cash');
  const [amount, setAmount] = useState('');
  const [checkNumber, setCheckNumber] = useState('');
  const [signedBy, setSignedBy] = useState('');
  const [deliveryNotes, setDeliveryNotes] = useState('');
  const [error, setError] = useState('');
  const [showInvoice, setShowInvoice] = useState(false);
  const [returnPhotos, setReturnPhotos] = useState([]);
  const [gps, setGps] = useState(null);
  const [gpsStatus, setGpsStatus] = useState('');
  const canvasRef = useRef(null);
  const padRef = useRef(null);

  const deliveries = data.orders.filter(o => ['packed', 'out_for_delivery', 'partially_delivered'].includes(o.status));
  const completed = data.orders.filter(o => ['completed', 'delivered', 'payment_pending'].includes(o.status)).slice(-8).reverse();

  const customer = selected ? data.customers.find(c => c.id === selected.customerId) : null;
  const pendingCredits = selected ? data.credits.filter(c => c.orderId === selected.id && c.status === 'approved' && c.pickupRequired && !c.pickedUpAt) : [];

  const previewOrder = useMemo(() => selected ? {
    ...selected,
    items: lines.map(line => ({ ...line, invoiceQty: Number(line.deliveredQty || 0) }))
  } : null, [selected, lines]);
  const totals = previewOrder ? calcOrder(previewOrder) : { total: 0, balance: 0, paid: 0 };

  useEffect(() => {
    if (!selected || showInvoice || !canvasRef.current) return undefined;
    const canvas = canvasRef.current;
    const ratio = Math.max(window.devicePixelRatio || 1, 1);
    const width = canvas.clientWidth || 620;
    const height = 180;
    canvas.width = width * ratio;
    canvas.height = height * ratio;
    canvas.getContext('2d').scale(ratio, ratio);
    padRef.current = new SignaturePad(canvas, { minWidth: 0.8, maxWidth: 2.4 });
    return () => { padRef.current?.off(); padRef.current = null; };
  }, [selected, showInvoice]);

  const openDelivery = order => {
    const initialLines = order.items.map(item => Number(item.qty || 0) > 0 ? deliveryLine(item) : { ...item, packedQty: 0, deliveredQty: 0, refusedQty: 0, deliveryNote: item.deliveryNote || '' });
    const preview = { ...order, items: initialLines.map(line => ({ ...line, invoiceQty: line.deliveredQty })) };
    const balance = calcOrder(preview).balance;
    setSelected(order);
    setLines(initialLines);
    setMethod(order.paymentMethod || (data.customers.find(c => c.id === order.customerId)?.terms === 'COD' ? 'Cash' : 'Net Terms'));
    setAmount(String(order.paymentMethod === 'Net Terms' ? 0 : balance));
    setCheckNumber(order.checkNumber || '');
    setSignedBy(order.signedBy || '');
    setDeliveryNotes(order.deliveryNotes || '');
    setError('');
    setShowInvoice(false);
    setReturnPhotos(order.returnPhotos || []);
    setGps(order.proofOfDeliveryGps || null);
    setGpsStatus(order.proofOfDeliveryGps ? 'GPS already captured' : '');
  };

  const changeDelivered = (productId, value) => setLines(current => current.map(line => {
    if (line.productId !== productId) return line;
    const deliveredQty = Math.max(0, Math.min(Number(value || 0), line.packedQty));
    return { ...line, deliveredQty, refusedQty: line.packedQty - deliveredQty };
  }));

  const setLine = (productId, patch) => setLines(current => current.map(line => line.productId === productId ? { ...line, ...patch } : line));

  const markOutForDelivery = order => update(d => ({
    ...d,
    orders: d.orders.map(o => o.id === order.id ? {
      ...o,
      status: 'out_for_delivery',
      driver: user?.name || 'Route Driver',
      driverId: user?.uid || '',
      loadedAt: o.loadedAt || now(),
      updatedAt: now()
    } : o)
  }));


  const captureGps = async () => {
    setGpsStatus('Capturing location...');
    try {
      const pos = await getCurrentLocation();
      setGps({ latitude: pos.coords.latitude, longitude: pos.coords.longitude, accuracy: pos.coords.accuracy, capturedAt: now() });
      setGpsStatus(`Captured within about ${Math.round(pos.coords.accuracy)} meters`);
    } catch (err) { setGpsStatus(err.message || 'Could not capture GPS location.'); }
  };

  const addReturnPhotos = async event => {
    const files = [...(event.target.files || [])].slice(0, 4 - returnPhotos.length);
    const converted = await Promise.all(files.map(file => new Promise(resolve => {
      const reader = new FileReader();
      reader.onload = () => {
        const img = new Image();
        img.onload = () => {
          const max = 1200, scale = Math.min(1, max / Math.max(img.width, img.height));
          const canvas = document.createElement('canvas'); canvas.width = Math.round(img.width * scale); canvas.height = Math.round(img.height * scale);
          canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
          resolve({ id: makeId('photo'), name: file.name, dataUrl: canvas.toDataURL('image/jpeg', .72), createdAt: now() });
        };
        img.src = reader.result;
      };
      reader.readAsDataURL(file);
    })));
    setReturnPhotos(current => [...current, ...converted].slice(0, 4));
    event.target.value = '';
  };

  const paymentLink = order => {
    const base = data.company.paymentLinkBase;
    if (!base) return '';
    const totals = calcOrder(order);
    const url = new URL(base, window.location.href);
    url.searchParams.set('invoice', order.invoiceNumber || '');
    url.searchParams.set('amount', Number(totals.balance || 0).toFixed(2));
    url.searchParams.set('customer', data.customers.find(c => c.id === order.customerId)?.name || '');
    return url.toString();
  };

  const copyPaymentLink = async order => {
    const link = paymentLink(order);
    if (!link) { alert('Add a customer payment-link base URL in Company Settings first.'); return; }
    await navigator.clipboard.writeText(link);
    alert('Payment link copied.');
  };

  const saveRouteOffline = () => {
    const assigned = deliveries.filter(o => !user?.uid || !o.driverId || o.driverId === user.uid);
    localStorage.setItem('backwoods_driver_offline_route', JSON.stringify({ savedAt: now(), orders: assigned, customers: data.customers, products: data.products }));
    alert(`${assigned.length} deliveries saved on this device for offline use.`);
  };

  const completeDelivery = () => {
    setError('');
    const collected = Number(amount || 0);
    const signature = padRef.current && !padRef.current.isEmpty() ? padRef.current.toDataURL('image/png') : selected.signature || null;
    const orderForTotals = { ...selected, items: lines.map(line => ({ ...line, invoiceQty: line.deliveredQty })) };
    const due = calcOrder(orderForTotals).balance;

    if (!gps) return setError('Capture GPS proof of delivery before completing the stop.');
    if (!signedBy.trim()) return setError('Enter the name of the store representative receiving the delivery.');
    if (!signature) return setError('A customer signature is required to complete delivery.');
    if (lines.some(line => line.deliveredQty < 0 || line.deliveredQty > line.packedQty)) return setError('Delivered quantities must be between zero and the packed quantity.');
    if (lines.some(line => Number(line.returnQty||0)>0 && !line.returnReason)) return setError('Every return must have a return reason.');
    if (lines.some(line => Number(line.returnQty||0)>0 && !line.returnDisposition)) return setError('Every return must have an inventory disposition.');
    if (method === 'Check' && !checkNumber.trim()) return setError('Enter the check number.');
    if (method === 'No Payment' || method === 'Net Terms') {
      if (collected !== 0) return setError(`Amount collected must be $0.00 for ${method}.`);
    } else if (collected < 0 || collected > due + 0.009) {
      return setError(`Amount collected must be between $0.00 and ${money(due)}.`);
    }

    const payment = collected > 0 ? {
      id: makeId('pay'),
      orderId: selected.id,
      invoiceNumber: selected.invoiceNumber,
      customerId: selected.customerId,
      amount: collected,
      method,
      checkNumber: method === 'Check' ? checkNumber.trim() : '',
      driver: user?.name || 'Route Driver',
      driverId: user?.uid || '',
      createdAt: now()
    } : null;

    update(d => {
      const movementRows = [];
      const products = d.products.map(product => {
        const line = lines.find(x => x.productId === product.id);
        if (!line) return product;
        const delivered = Number(line.deliveredQty || 0);
        const packed = Number(line.packedQty || 0);
        const returned = Number(line.returnQty || 0);
        const disposition = line.returnDisposition || 'sellable';
        if (returned) movementRows.push({ id: makeId('mov'), productId: product.id, type: `return_${disposition}`, quantity: returned, reference: selected.invoiceNumber, note: `${customer?.name || 'Customer'} return - ${line.returnReason || 'Return'} (${disposition})`, createdAt: now() });
        if (delivered) movementRows.push({
          id: makeId('mov'), productId: product.id, type: 'delivery', quantity: -delivered,
          reference: selected.invoiceNumber, note: `${customer?.name || 'Customer'} delivery`, createdAt: now()
        });
        return {
          ...product,
          onHand: Math.max(0, Number(product.onHand || 0) - delivered + (disposition === 'sellable' ? returned : 0)),
          damagedStock: Number(product.damagedStock || 0) + (disposition === 'damaged' ? returned : 0),
          expiredStock: Number(product.expiredStock || 0) + (disposition === 'expired' ? returned : 0),
          quarantineStock: Number(product.quarantineStock || 0) + (disposition === 'quarantine' ? returned : 0),
          reserved: Math.max(0, Number(product.reserved || 0) - packed)
        };
      });

      const payments = payment ? [...d.payments, payment] : d.payments;
      const updatedOrder = {
        ...selected,
        items: lines.map(line => ({ ...line, invoiceQty: Number(line.deliveredQty || 0) })),
        status: collected >= due - 0.009 ? 'completed' : collected > 0 ? 'payment_pending' : 'delivered',
        driver: user?.name || 'Route Driver',
        driverId: user?.uid || '',
        paymentMethod: method,
        checkNumber: method === 'Check' ? checkNumber.trim() : '',
        amountCollected: collected,
        payments: payment ? [...(selected.payments || []), payment] : (selected.payments || []),
        signedBy: signedBy.trim(),
        signature,
        deliveryNotes,
        returnPhotos,
        proofOfDeliveryGps: gps,
        paymentLink: paymentLink(orderForTotals),
        deliveredAt: now(),
        updatedAt: now()
      };

      return {
        ...d,
        products,
        payments,
        inventoryMovements: [...d.inventoryMovements, ...movementRows],
        orders: d.orders.map(o => o.id === selected.id ? updatedOrder : o)
      };
    });
    setSelected(null);
  };

  const confirmPickup = credit => update(d => {
    const product = d.products.find(p => p.id === credit.productId);
    const qty = Number(credit.qty || 0);
    return {
      ...d,
      credits: d.credits.map(c => c.id === credit.id ? { ...c, status: 'picked_up', pickedUpAt: now(), pickedUpBy: user?.name || 'Route Driver' } : c),
      products: d.products.map(p => p.id === credit.productId ? { ...p, onHand: Number(p.onHand || 0) + qty } : p),
      inventoryMovements: [...d.inventoryMovements, {
        id: makeId('mov'), productId: credit.productId, type: 'credit_return', quantity: qty,
        reference: selected.invoiceNumber, note: `Credit pickup from ${customer?.name || 'customer'}`, createdAt: now()
      }],
      orders: d.orders.map(o => o.id === selected.id ? {
        ...o,
        credits: (o.credits || []).map(c => c.id === credit.id ? { ...c, status: 'picked_up', pickedUpAt: now() } : c)
      } : o)
    };
  });

  return <>
    <div className="page-head"><div><h1>Driver Deliveries</h1><p>Works with Firestore offline caching. Save today’s route before leaving Wi-Fi, then sync automatically when service returns.</p></div><button onClick={saveRouteOffline}>Save route offline</button></div>
    <div className="packing-summary">
      <div className="card"><span>Ready to load</span><strong>{deliveries.filter(o => o.status === 'packed').length}</strong></div>
      <div className="card"><span>Out for delivery</span><strong>{deliveries.filter(o => o.status === 'out_for_delivery').length}</strong></div>
      <div className="card"><span>Completed recently</span><strong>{completed.length}</strong></div>
    </div>

    <div className="grid-cards">{deliveries.map(order => {
      const c = data.customers.find(x => x.id === order.customerId);
      const due = calcOrder(order).balance;
      return <div className="panel" key={order.id}>
        <div className="panel-title"><div><h3>{c?.name}</h3><p>{order.orderNumber}</p></div><span className="status">{order.status.replaceAll('_', ' ')}</span></div>
        <p>{c?.address}</p><strong>{money(due)}</strong>
        <small>{order.items.reduce((s, i) => s + Number(i.packedQty ?? i.qty), 0)} units · {order.items.length} lines</small>
        <div className="actions"><button className="secondary" onClick={()=>copyPaymentLink(order)}>Payment link</button>{order.status === 'packed' && <button className="secondary" onClick={() => markOutForDelivery(order)}>Load / start route</button>}<button onClick={() => openDelivery(order)}>Open delivery</button></div>
      </div>;
    })}</div>
    {!deliveries.length && <div className="panel empty">No packed orders are waiting for a driver.</div>}

    {completed.length > 0 && <div className="panel"><h2>Recent completed deliveries</h2><table><thead><tr><th>Invoice</th><th>Customer</th><th>Collected</th><th>Status</th><th></th></tr></thead><tbody>{completed.map(o => <tr key={o.id}><td>{o.invoiceNumber}</td><td>{data.customers.find(c => c.id === o.customerId)?.name}</td><td>{money(o.amountCollected || 0)}</td><td>{o.status.replaceAll('_', ' ')}</td><td><button className="small secondary" onClick={() => { setSelected(o); setLines(o.items.map(deliveryLine)); setShowInvoice(true); }}>Invoice</button></td></tr>)}</tbody></table></div>}

    {selected && <Modal title={showInvoice ? selected.invoiceNumber : `Deliver ${selected.invoiceNumber}`} wide onClose={() => setSelected(null)}>
      {showInvoice ? <><InvoiceView order={previewOrder || selected} customer={customer} company={data.company}/><div className="actions no-print"><button className="secondary" onClick={() => setShowInvoice(false)}>Back to delivery</button><button onClick={() => window.print()}>Print / Save PDF</button></div></> : <>
        {error && <div className="alert">{error}</div>}
        <div className="delivery-summary"><div><h3>{customer?.name}</h3><p>{customer?.address}</p></div><div className="delivery-balance"><small>Current invoice</small><strong>{money(totals.total)}</strong></div></div>

        <div className="packing-table-wrap"><table><thead><tr><th>Product</th><th>Packed</th><th>Delivered</th><th>Refused / returned</th><th>Note</th></tr></thead><tbody>{lines.map(line => <tr key={line.productId} className={line.refusedQty ? 'short-line' : ''}><td><b>{line.name}</b><small>{line.sku}</small></td><td>{line.packedQty}</td><td><input className="qty" type="number" min="0" max={line.packedQty} value={line.deliveredQty} onChange={e => changeDelivered(line.productId, e.target.value)}/></td><td><b>{line.refusedQty}</b></td><td><input value={line.deliveryNote} onChange={e => setLine(line.productId, { deliveryNote: e.target.value })} placeholder="Damage, refusal, shortage"/></td></tr>)}</tbody></table></div>

        {pendingCredits.length > 0 && <div className="credit-pickups"><h3>Credit pickups</h3>{pendingCredits.map(credit => <div className="credit-pickup" key={credit.id}><div><b>{data.products.find(p => p.id === credit.productId)?.name}</b><span>{credit.qty} units · {credit.reason} · {money(credit.amount)}</span></div><button className="secondary" onClick={() => confirmPickup(credit)}>Confirm pickup</button></div>)}</div>}

        <div className="form-grid">
          <label>Payment method<select value={method} onChange={e => { const next = e.target.value; setMethod(next); if (next === 'Net Terms' || next === 'No Payment') setAmount('0'); else if (!Number(amount)) setAmount(String(totals.balance)); }}>{methods.map(x => <option key={x}>{x}</option>)}</select></label>
          <label>Amount collected<input type="number" min="0" step="0.01" value={amount} onChange={e => setAmount(e.target.value)}/></label>
          {method === 'Check' && <label>Check number<input value={checkNumber} onChange={e => setCheckNumber(e.target.value)} placeholder="Check number"/></label>}
          <label>Received by<input value={signedBy} onChange={e => setSignedBy(e.target.value)} placeholder="Store representative"/></label>
        </div>
        <label>Delivery notes<input value={deliveryNotes} onChange={e => setDeliveryNotes(e.target.value)} placeholder="Dock, refusal, payment, or follow-up notes"/></label>
        <div className="proof-grid">
          <div className="panel inset"><h3>GPS proof of delivery</h3><button type="button" className="secondary" onClick={captureGps}>Capture current location</button><small>{gpsStatus}</small>{gps&&<a href={`https://maps.google.com/?q=${gps.latitude},${gps.longitude}`} target="_blank" rel="noreferrer">View captured location</a>}</div>
          <div className="panel inset"><h3>Damaged-return photos</h3><input type="file" accept="image/*" capture="environment" multiple onChange={addReturnPhotos}/><small>Up to four compressed photos are attached to the delivery record.</small><div className="photo-strip">{returnPhotos.map(photo=><div key={photo.id}><img src={photo.dataUrl} alt={photo.name}/><button type="button" className="small danger" onClick={()=>setReturnPhotos(x=>x.filter(p=>p.id!==photo.id))}>Remove</button></div>)}</div></div>
        </div>
        <label>Customer signature<canvas ref={canvasRef} className="signature-pad"/></label>
        <div className="payment-preview"><span>Invoice total <b>{money(totals.total)}</b></span><span>Collecting <b>{money(amount)}</b></span><span>Remaining after collection <b>{money(Math.max(0, totals.balance - Number(amount || 0)))}</b></span></div>
        <div className="actions"><button className="secondary" onClick={() => padRef.current?.clear()}>Clear signature</button><button className="secondary" onClick={() => setShowInvoice(true)}>Preview invoice</button><button onClick={completeDelivery}>Complete delivery</button></div>
      </>}
    </Modal>}
  </>;
}
