import { useMemo, useState } from 'react';
import { Download, Printer, RefreshCw } from 'lucide-react';
import { makeId, money, now } from '../lib/helpers';

const csvCell = value => `"${String(value ?? '').replaceAll('"', '""')}"`;

function downloadCsv(name, rows) {
  if (!rows.length) return;
  const keys = Object.keys(rows[0]);
  const csv = [keys.join(','), ...rows.map(row => keys.map(key => csvCell(row[key])).join(','))].join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = name;
  link.click();
  URL.revokeObjectURL(url);
}

const cleanMethod = value => String(value || 'Other').toLowerCase();
const driverKey = (order, payment) => payment.driverId || payment.driver || order.driverId || order.driver || 'Unassigned';
const driverLabel = (order, payment, data) => {
  const key = driverKey(order, payment);
  const user = (data.users || []).find(row => row.uid === key || row.id === key || row.name === key || row.email === key);
  return user?.name || payment.driver || order.driver || key;
};

function openPaymentRows(data) {
  return (data.orders || []).flatMap(order => (order.payments || [])
    .filter(payment => !payment.settledAt && Number(payment.amount || 0) > 0)
    .map(payment => {
      const method = cleanMethod(payment.method);
      return {
        id: payment.id,
        orderId: order.id,
        invoice: order.invoiceNumber || order.orderNumber || order.id,
        customer: order.customerName || (data.customers || []).find(customer => customer.id === order.customerId)?.name || 'Unknown',
        driverKey: driverKey(order, payment),
        driver: driverLabel(order, payment, data),
        method: payment.method || 'Other',
        cash: method === 'cash' ? Number(payment.amount || 0) : 0,
        checks: method === 'check' ? Number(payment.amount || 0) : 0,
        cards: method.includes('card') ? Number(payment.amount || 0) : 0,
        ach: method === 'ach' ? Number(payment.amount || 0) : 0,
        other: !['cash', 'check', 'ach'].includes(method) && !method.includes('card') ? Number(payment.amount || 0) : 0,
        amount: Number(payment.amount || 0),
        reference: payment.checkNumber || payment.reference || '',
        createdAt: payment.createdAt || order.deliveredAt || order.updatedAt || order.createdAt || '',
      };
    }));
}

function groupRows(rows) {
  const map = new Map();
  rows.forEach(row => {
    const current = map.get(row.driverKey) || {
      driverKey: row.driverKey,
      driver: row.driver,
      payments: 0,
      cash: 0,
      checks: 0,
      cards: 0,
      ach: 0,
      other: 0,
      total: 0,
      invoices: new Set(),
    };
    current.payments += 1;
    current.cash += row.cash;
    current.checks += row.checks;
    current.cards += row.cards;
    current.ach += row.ach;
    current.other += row.other;
    current.total += row.amount;
    current.invoices.add(row.invoice);
    map.set(row.driverKey, current);
  });
  return [...map.values()]
    .map(row => ({ ...row, invoices: row.invoices.size }))
    .sort((a, b) => b.total - a.total);
}

export default function Settlements({ data, update }) {
  const [selectedDriver, setSelectedDriver] = useState('');
  const rows = useMemo(() => openPaymentRows(data), [data]);
  const groups = useMemo(() => groupRows(rows), [rows]);
  const visibleRows = selectedDriver ? rows.filter(row => row.driverKey === selectedDriver) : rows;
  const settledHistory = (data.driverSettlements || []).slice().sort((a, b) => String(b.settledAt || '').localeCompare(String(a.settledAt || '')));
  const totals = {
    payments: rows.length,
    cash: rows.reduce((sum, row) => sum + row.cash, 0),
    checks: rows.reduce((sum, row) => sum + row.checks, 0),
    cards: rows.reduce((sum, row) => sum + row.cards, 0),
    ach: rows.reduce((sum, row) => sum + row.ach, 0),
    other: rows.reduce((sum, row) => sum + row.other, 0),
    total: rows.reduce((sum, row) => sum + row.amount, 0),
  };

  const settleDriver = driver => {
    if (!driver || !confirm(`Mark ${driver.driver}'s ${money(driver.total)} as settled?`)) return;
    const settledAt = now();
    update(d => ({
      ...d,
      orders: (d.orders || []).map(order => ({
        ...order,
        payments: (order.payments || []).map(payment => !payment.settledAt && driverKey(order, payment) === driver.driverKey
          ? { ...payment, settledAt, settlementId: `settle_${driver.driverKey}_${settledAt}` }
          : payment)
      })),
      driverSettlements: [...(d.driverSettlements || []), {
        id: makeId('settle'),
        driverKey: driver.driverKey,
        driver: driver.driver,
        payments: driver.payments,
        invoices: driver.invoices,
        cash: driver.cash,
        checks: driver.checks,
        cards: driver.cards,
        ach: driver.ach,
        other: driver.other,
        total: driver.total,
        settledAt,
      }],
      auditLogs: [...(d.auditLogs || []), {
        id: makeId('audit'),
        action: 'Driver settlement recorded',
        entityType: 'settlement',
        entityId: driver.driverKey,
        details: `${driver.driver}: ${money(driver.total)}`,
        createdAt: settledAt,
      }]
    }));
  };

  const exportRows = visibleRows.map(row => ({
    date: row.createdAt ? new Date(row.createdAt).toLocaleString() : '',
    driver: row.driver,
    invoice: row.invoice,
    customer: row.customer,
    method: row.method,
    reference: row.reference,
    amount: row.amount,
  }));

  return <>
    <div className="page-head">
      <div><h1>Driver Settlements</h1><p>Close out route collections by driver, with cash, checks, cards, ACH, and references.</p></div>
      <div className="actions no-print">
        <button className="secondary" onClick={() => location.reload()}><RefreshCw size={17}/>Refresh</button>
        <button className="secondary" onClick={() => window.print()}><Printer size={17}/>Print</button>
        <button onClick={() => downloadCsv('driver-settlement-detail.csv', exportRows)}><Download size={17}/>Export CSV</button>
      </div>
    </div>

    <div className="stats report-stats">
      <div className="card"><span>Open payments</span><strong>{totals.payments}</strong></div>
      <div className="card"><span>Cash</span><strong>{money(totals.cash)}</strong></div>
      <div className="card"><span>Checks</span><strong>{money(totals.checks)}</strong></div>
      <div className="card"><span>Total to settle</span><strong>{money(totals.total)}</strong></div>
    </div>

    <div className="settlement-grid">
      {groups.map(group => <div className="card settlement-card" key={group.driverKey}>
        <span>{group.driver}</span>
        <strong>{money(group.total)}</strong>
        <small>{group.payments} payment(s) across {group.invoices} invoice(s)</small>
        <div className="settlement-breakdown">
          <span>Cash {money(group.cash)}</span>
          <span>Checks {money(group.checks)}</span>
          <span>Cards {money(group.cards)}</span>
          <span>ACH {money(group.ach)}</span>
        </div>
        <div className="actions">
          <button className="secondary small" onClick={() => setSelectedDriver(group.driverKey)}>Review</button>
          <button className="small" onClick={() => settleDriver(group)}>Mark settled</button>
        </div>
      </div>)}
      {!groups.length && <div className="panel empty">No unsettled driver collections are waiting.</div>}
    </div>

    <div className="panel table-scroll">
      <div className="panel-title">
        <div><h2>Open collection detail</h2><p>Use this table to compare driver envelopes, checks, and payment references.</p></div>
        <select value={selectedDriver} onChange={event => setSelectedDriver(event.target.value)}>
          <option value="">All drivers</option>
          {groups.map(group => <option key={group.driverKey} value={group.driverKey}>{group.driver}</option>)}
        </select>
      </div>
      <table>
        <thead><tr><th>Date</th><th>Driver</th><th>Invoice</th><th>Customer</th><th>Method</th><th>Reference</th><th>Amount</th></tr></thead>
        <tbody>{visibleRows.map(row => <tr key={`${row.orderId}-${row.id}`}>
          <td>{row.createdAt ? new Date(row.createdAt).toLocaleString() : '-'}</td>
          <td>{row.driver}</td>
          <td>{row.invoice}</td>
          <td>{row.customer}</td>
          <td>{row.method}</td>
          <td>{row.reference || '-'}</td>
          <td>{money(row.amount)}</td>
        </tr>)}</tbody>
      </table>
      {!visibleRows.length && <div className="empty compact">No payment rows match this view.</div>}
    </div>

    <div className="panel table-scroll">
      <div className="panel-title"><div><h2>Settlement history</h2><p>Previous closeouts stay here for accounting review.</p></div></div>
      <table>
        <thead><tr><th>Settled at</th><th>Driver</th><th>Payments</th><th>Invoices</th><th>Cash</th><th>Checks</th><th>Cards</th><th>ACH</th><th>Total</th></tr></thead>
        <tbody>{settledHistory.map(row => <tr key={row.id}>
          <td>{row.settledAt ? new Date(row.settledAt).toLocaleString() : '-'}</td>
          <td>{row.driver}</td>
          <td>{row.payments || row.count || 0}</td>
          <td>{row.invoices || '-'}</td>
          <td>{money(row.cash)}</td>
          <td>{money(row.checks)}</td>
          <td>{money(row.cards)}</td>
          <td>{money(row.ach)}</td>
          <td>{money(row.total)}</td>
        </tr>)}</tbody>
      </table>
      {!settledHistory.length && <div className="empty compact">No settlement history yet.</div>}
    </div>
  </>;
}
