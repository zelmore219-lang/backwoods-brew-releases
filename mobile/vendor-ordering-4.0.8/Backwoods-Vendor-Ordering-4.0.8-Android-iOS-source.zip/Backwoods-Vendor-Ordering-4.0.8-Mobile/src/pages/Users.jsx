import { useMemo, useState } from 'react';
import { initializeApp, getApps } from 'firebase/app';
import { createUserWithEmailAndPassword, getAuth, signOut } from 'firebase/auth';
import Modal from '../components/Modal';
import { makeId } from '../lib/helpers';
import { firebaseConfig } from '../lib/firebase';
import { useAuth } from '../auth/AuthContext';

const roles = ['owner', 'manager', 'sales', 'packer', 'driver', 'accounting', 'customer', 'pending'];
const blank = { uid: '', username: '', password: '', name: '', email: '', role: 'sales', active: true, customerId: '' };
const creatorAppName = 'BackwoodsUserCreator';

const loginDomain = () => String(import.meta.env.VITE_LOGIN_EMAIL_DOMAIN || 'backwoodsbrew-e3584-d52a3.firebaseapp.com').trim().toLowerCase();
const cleanUsername = value => String(value || '').trim().toLowerCase();
const loginEmailFor = value => {
  const cleaned = cleanUsername(value);
  return cleaned.includes('@') ? cleaned : `${cleaned}@${loginDomain()}`;
};

async function createFirebaseLogin(email, password) {
  const app = getApps().find(item => item.name === creatorAppName) || initializeApp(firebaseConfig, creatorAppName);
  const secondaryAuth = getAuth(app);
  const credential = await createUserWithEmailAndPassword(secondaryAuth, email, password);
  await signOut(secondaryAuth).catch(() => {});
  return credential.user.uid;
}

export default function Users({ data, update, firebaseEnabled }) {
  const { user: me } = useAuth();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [f, setF] = useState(blank);
  const [message, setMessage] = useState('');
  const [busy, setBusy] = useState(false);

  const users = useMemo(() => [...data.users].sort((a, b) => (a.name || '').localeCompare(b.name || '')), [data.users]);

  const startAdd = () => {
    setEditing(null);
    setF(blank);
    setMessage('');
    setOpen(true);
  };

  const startEdit = user => {
    setEditing(user.id);
    setF({
      uid: user.uid || user.id,
      username: user.username || '',
      password: '',
      name: user.name || '',
      email: user.email || '',
      role: user.role || 'pending',
      active: user.active !== false,
      customerId: user.customerId || ''
    });
    setMessage('');
    setOpen(true);
  };

  const save = async () => {
    setMessage('');
    const username = cleanUsername(f.username || f.email);
    const name = f.name.trim();
    const email = cleanUsername(f.email || username);
    const loginEmail = firebaseEnabled ? loginEmailFor(email || username) : email;
    const existing = data.users.find(user => user.id === editing);
    const duplicate = data.users.find(user => user.id !== editing && [user.username, user.email, user.uid, user.id]
      .filter(Boolean)
      .some(value => cleanUsername(value) === username || cleanUsername(value) === loginEmail));

    if (!name) return setMessage('Enter the user name.');
    if (!username) return setMessage('Enter a username.');
    if (!f.role) return setMessage('Choose a role.');
    if (duplicate) return setMessage('That username or email is already assigned to another user.');
    if (!editing && !firebaseEnabled && !f.password.trim()) return setMessage('Enter a password for this local app user.');
    if (!editing && firebaseEnabled && !f.uid.trim() && !f.password.trim()) return setMessage('Enter a temporary password, or paste an existing Firebase UID.');
    if (firebaseEnabled && f.password.trim() && f.password.trim().length < 6) return setMessage('Firebase passwords must be at least 6 characters.');

    setBusy(true);
    try {
      let uid = f.uid.trim() || existing?.uid || existing?.id || '';
      if (firebaseEnabled && !editing && !uid) uid = await createFirebaseLogin(loginEmail, f.password.trim());
      if (!firebaseEnabled && !uid) uid = editing || `local_${username.replace(/[^a-z0-9_-]/g, '_') || makeId('user')}`;
      if (!uid) return setMessage('A user ID could not be created.');

      const savedUser = {
        id: uid,
        uid,
        username,
        name,
        email: firebaseEnabled ? loginEmail : email,
        role: f.role,
        active: Boolean(f.active),
        customerId: f.role === 'customer' ? f.customerId : ''
      };

      if (!firebaseEnabled) savedUser.password = f.password.trim() || existing?.password || '';

      await update(d => ({
        ...d,
        users: [
          ...d.users.filter(user => user.id !== editing && user.id !== uid),
          savedUser
        ]
      }));
      setOpen(false);
      setEditing(null);
      setF(blank);
    } catch (err) {
      setMessage(err.code === 'auth/email-already-in-use'
        ? 'That Firebase login already exists. Paste its Firebase UID instead, or use a different username.'
        : err.message || 'The user could not be saved.');
    } finally {
      setBusy(false);
    }
  };

  const toggle = user => update(d => ({
    ...d,
    users: d.users.map(item => item.id === user.id ? { ...item, active: item.id === me.uid ? true : item.active === false } : item)
  }));

  return <>
    <div className="page-head"><div><h1>User Management</h1><p>Create app users, assign job roles, and disable access.</p></div><button onClick={startAdd}>Add user</button></div>
    {!firebaseEnabled && <div className="notice">Local mode: users created here can sign in on this installed app with their username and password.</div>}
    {firebaseEnabled && <div className="notice">Firebase mode: adding a user can create the Firebase login and the role profile at the same time.</div>}

    <div className="panel table-scroll"><table><thead><tr><th>User</th><th>Username</th><th>Role</th><th>Status</th><th>UID</th><th></th></tr></thead><tbody>
      {users.length === 0 && <tr><td colSpan="6">No users yet.</td></tr>}
      {users.map(user => <tr key={user.id}>
        <td><b>{user.name}</b><small>{user.email || 'No email entered'}</small></td>
        <td>{user.username || '-'}</td>
        <td><span className="status">{user.role}</span></td>
        <td>{user.active === false ? 'Disabled' : 'Active'}</td>
        <td><code>{user.uid || user.id}</code></td>
        <td><div className="row-actions"><button className="small secondary" onClick={() => startEdit(user)}>Edit</button><button className="small danger" disabled={user.id === me.uid} onClick={() => toggle(user)}>{user.active === false ? 'Enable' : 'Disable'}</button></div></td>
      </tr>)}
    </tbody></table></div>

    {open && <Modal title={editing ? 'Edit user' : 'Add user'} onClose={() => setOpen(false)}>
      <div className="form-grid">
        <label>Name<input value={f.name} onChange={event => setF({ ...f, name: event.target.value })}/></label>
        <label>Username<input value={f.username} onChange={event => setF({ ...f, username: event.target.value })} placeholder="jane"/></label>
        <label>Email<input type="text" value={f.email} onChange={event => setF({ ...f, email: event.target.value })} placeholder={firebaseEnabled ? `jane@${loginDomain()}` : 'optional'}/></label>
        <label>{editing ? 'New password' : 'Password'}<input type="password" value={f.password} onChange={event => setF({ ...f, password: event.target.value })} autoComplete="new-password" placeholder={editing ? 'Leave blank to keep current password' : 'Temporary password'}/></label>
        {firebaseEnabled && <label>Firebase UID<input value={f.uid} disabled={Boolean(editing)} onChange={event => setF({ ...f, uid: event.target.value })} placeholder="Optional if entering a password"/></label>}
        <label>Role<select value={f.role} onChange={event => setF({ ...f, role: event.target.value })}>{roles.map(role => <option key={role}>{role}</option>)}</select></label>
        {f.role === 'customer' && <label>Customer account<select value={f.customerId} onChange={event => setF({ ...f, customerId: event.target.value })}><option value="">Choose customer</option>{data.customers.map(customer => <option key={customer.id} value={customer.id}>{customer.name}</option>)}</select></label>}
        <label className="check-label"><input type="checkbox" checked={f.active} onChange={event => setF({ ...f, active: event.target.checked })}/> Active account</label>
      </div>
      {message && <div className="auth-error">{message}</div>}
      <div className="actions"><button className="secondary" onClick={() => setOpen(false)}>Cancel</button><button disabled={busy} onClick={save}>{busy ? 'Saving...' : 'Save user'}</button></div>
    </Modal>}
  </>;
}
