import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from './AuthContext';

export default function ProtectedRoute({ children, roles }) {
  const { user, loading } = useAuth();
  const location = useLocation();

  if (loading) return <div className="auth-loading">Loading account…</div>;
  if (!user) return <Navigate to="/login" state={{ from: location }} replace />;
  if (user.active === false || user.role === 'pending') return <Navigate to="/unauthorized" replace />;
  if (roles && !roles.includes(user.role)) return <Navigate to="/unauthorized" replace />;
  return children;
}
