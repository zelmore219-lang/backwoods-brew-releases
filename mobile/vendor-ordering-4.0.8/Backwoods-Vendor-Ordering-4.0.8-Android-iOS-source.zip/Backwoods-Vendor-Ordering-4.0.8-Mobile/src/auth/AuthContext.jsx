import { createContext, useContext, useEffect, useMemo, useRef, useState } from 'react';
import {
  onAuthStateChanged,
  signInWithEmailAndPassword,
  signOut as firebaseSignOut
} from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { auth, db, firebaseEnabled } from '../lib/firebase';

const AuthContext = createContext(null);
const DEMO_KEY = 'backwoods_vendor_demo_user';
const APP_DATA_KEY = 'backwoods_vendor_app_v2';
const OFFLINE_USERS_KEY = 'backwoods_vendor_offline_users_v1';

const demoUsers = {
  owner: { uid: 'demo-owner', email: 'owner@demo.local', name: 'Demo Owner', role: 'owner' },
  manager: { uid: 'demo-manager', email: 'manager@demo.local', name: 'Demo Manager', role: 'manager' },
  sales: { uid: 'demo-sales', email: 'sales@demo.local', name: 'Demo Salesperson', role: 'sales' },
  packer: { uid: 'demo-packer', email: 'packer@demo.local', name: 'Demo Packer', role: 'packer' },
  driver: { uid: 'demo-driver', email: 'driver@demo.local', name: 'Demo Driver', role: 'driver' },
  accounting: { uid: 'demo-accounting', email: 'accounting@demo.local', name: 'Demo Accounting', role: 'accounting' },
  customer: { uid: 'demo-customer', email: 'orders@pinehill.example', name: 'Pine Hill Market', role: 'customer', customerId: 'c1' }
};

const normalizeLogin = value => String(value || '').trim().toLowerCase();
const loginEmailFor = value => {
  const normalized = normalizeLogin(value);
  const loginDomain = String(import.meta.env.VITE_LOGIN_EMAIL_DOMAIN || 'backwoodsbrew-e3584-d52a3.firebaseapp.com').trim().toLowerCase();
  return normalized.includes('@') ? normalized : `${normalized}@${loginDomain}`;
};
const isNetworkAuthError = error => {
  const raw = String(error?.code || error?.message || error || '').toLowerCase();
  return raw.includes('network') || raw.includes('offline') || raw.includes('failed to fetch') || (typeof navigator !== 'undefined' && navigator.onLine === false);
};
const readOfflineUsers = () => {
  try { return JSON.parse(localStorage.getItem(OFFLINE_USERS_KEY) || '[]'); } catch { return []; }
};
const saveOfflineUsers = users => localStorage.setItem(OFFLINE_USERS_KEY, JSON.stringify(Array.isArray(users) ? users : []));
const publicUser = row => row ? {
  uid: row.uid,
  email: row.email,
  name: row.name || row.email,
  role: row.role || 'pending',
  active: row.active !== false,
  customerId: row.customerId || '',
  offlineAuth: Boolean(row.offlineAuth)
} : null;
const findOfflineUser = value => {
  const key = normalizeLogin(value);
  return readOfflineUsers().find(row => [
    row.uid,
    row.email,
    row.username,
    ...(row.loginKeys || [])
  ].filter(Boolean).map(normalizeLogin).includes(key));
};
async function sha256(text) {
  const data = new TextEncoder().encode(String(text));
  const hash = await crypto.subtle.digest('SHA-256', data);
  return Array.from(new Uint8Array(hash)).map(byte => byte.toString(16).padStart(2, '0')).join('');
}
async function hashPassword(password, salt = globalThis.crypto?.randomUUID ? globalThis.crypto.randomUUID() : `${Date.now()}_${Math.random()}`) {
  return { passwordSalt: salt, passwordHash: await sha256(`${salt}:${password}`), passwordVersion: 'sha256-v1' };
}
async function verifyOfflinePassword(row, password) {
  if (!row?.passwordHash || !row?.passwordSalt) return false;
  return (await sha256(`${row.passwordSalt}:${password}`)) === row.passwordHash;
}
function upsertOfflineUser(row) {
  const clean = { ...row, loginKeys: [...new Set((row.loginKeys || []).filter(Boolean).map(normalizeLogin))] };
  const users = readOfflineUsers();
  const index = users.findIndex(existing => existing.uid === clean.uid || normalizeLogin(existing.email) === normalizeLogin(clean.email));
  if (index >= 0) users[index] = { ...users[index], ...clean, passwordHash: clean.passwordHash || users[index].passwordHash, passwordSalt: clean.passwordSalt || users[index].passwordSalt };
  else users.push(clean);
  saveOfflineUsers(users);
  return clean;
}
async function loadVendorUser(firebaseUser) {
  const profileRef = doc(db, 'vendorUsers', firebaseUser.uid);
  let profileSnap = await getDoc(profileRef);

  if (!profileSnap.exists() && firebaseUser.email?.toLowerCase() === 'admin@backwoodsbrew-e3584-d52a3.firebaseapp.com') {
    await setDoc(profileRef, {
      name: 'Backwoods Brew Admin',
      email: firebaseUser.email,
      role: 'owner',
      active: true,
      createdAt: new Date().toISOString(),
      bootstrapOwner: true
    });
    profileSnap = await getDoc(profileRef);
  }

  const profile = profileSnap.exists() ? profileSnap.data() : {};
  return {
    uid: firebaseUser.uid,
    email: firebaseUser.email,
    username: normalizeLogin(firebaseUser.email),
    name: profile.name || firebaseUser.displayName || firebaseUser.email,
    role: profile.role || 'pending',
    active: profile.active !== false,
    customerId: profile.customerId || '',
    cachedAt: new Date().toISOString(),
    loginKeys: [firebaseUser.uid, firebaseUser.email, profile.email, profile.username].filter(Boolean)
  };
}

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(firebaseEnabled);
  const [error, setError] = useState('');
  const pendingOnlineLogin = useRef(null);

  useEffect(() => {
    if (!user) return undefined;
    const timeoutMinutes = Math.max(5, Number(import.meta.env.VITE_SESSION_TIMEOUT_MINUTES || 60));
    let timer;
    const reset = () => {
      clearTimeout(timer);
      timer = setTimeout(() => logout(), timeoutMinutes * 60 * 1000);
    };
    const events = ['mousemove','mousedown','keydown','touchstart','scroll'];
    events.forEach(event => window.addEventListener(event, reset, { passive:true }));
    reset();
    return () => { clearTimeout(timer); events.forEach(event => window.removeEventListener(event, reset)); };
  }, [user]);

  useEffect(() => {
    if (!firebaseEnabled) {
      const saved = localStorage.getItem(DEMO_KEY);
      setUser(saved ? JSON.parse(saved) : null);
      setLoading(false);
      return undefined;
    }

    return onAuthStateChanged(auth, async firebaseUser => {
      setError('');
      if (!firebaseUser) {
        setUser(null);
        setLoading(false);
        return;
      }

      try {
        const loaded = await loadVendorUser(firebaseUser);
        upsertOfflineUser(loaded);
        setUser(publicUser(loaded));
      } catch (err) {
        const cached = findOfflineUser(firebaseUser.uid) || findOfflineUser(firebaseUser.email);
        if (cached) {
          setError('Offline profile loaded. Changes will sync when this device reconnects.');
          setUser(publicUser({ ...cached, offlineAuth: true }));
        } else {
          setError('Signed in, but the user profile could not be loaded.');
          setUser({ uid: firebaseUser.uid, email: firebaseUser.email, name: firebaseUser.email, role: 'pending', active: true });
        }
      } finally {
        setLoading(false);
      }
    });
  }, []);

  useEffect(() => {
    if (!firebaseEnabled) return undefined;
    const resume = async () => {
      const pending = pendingOnlineLogin.current;
      if (!pending || (typeof navigator !== 'undefined' && !navigator.onLine)) return;
      try {
        const onlineUser = await signInOnline(pending.username, pending.password);
        pendingOnlineLogin.current = null;
        setError('');
        setUser(onlineUser);
      } catch {
        // Keep the offline session active; the next online event/interval will retry.
      }
    };
    window.addEventListener('online', resume);
    const timer = setInterval(resume, 30000);
    resume();
    return () => { window.removeEventListener('online', resume); clearInterval(timer); };
  }, []);

  async function signInOnline(username, password) {
    const value = normalizeLogin(username);
    const loginEmail = loginEmailFor(value);
    const credential = await signInWithEmailAndPassword(auth, loginEmail, password);
    const loaded = await loadVendorUser(credential.user);
    const secret = await hashPassword(password);
    const cached = upsertOfflineUser({
      ...loaded,
      ...secret,
      username: value,
      loginKeys: [value, loginEmail, loaded.uid, loaded.email, ...(loaded.loginKeys || [])]
    });
    localStorage.setItem(DEMO_KEY, JSON.stringify(publicUser(cached)));
    return publicUser(cached);
  }

  const login = async (username, password) => {
    setError('');
    if (!firebaseEnabled) {
      try {
        const value = String(username || '').trim().toLowerCase();
        const appData = JSON.parse(localStorage.getItem(APP_DATA_KEY) || '{}');
        const users = appData.users || [];
        const profile = users.find(u => [u.username, u.email, u.name, u.uid, u.id]
          .filter(Boolean)
          .some(field => String(field).trim().toLowerCase() === value));

        if (!profile || String(profile.password || '') !== String(password || '')) {
          const friendly = 'The username or password is incorrect.';
          setError(friendly);
          throw new Error(friendly);
        }
        if (profile.active === false || profile.role === 'pending') {
          const friendly = 'This user is disabled or still pending approval.';
          setError(friendly);
          throw new Error(friendly);
        }

        const localUser = {
          uid: profile.uid || profile.id,
          email: profile.email || `${profile.username || profile.id}@local.app`,
          name: profile.name,
          role: profile.role,
          active: profile.active !== false,
          customerId: profile.customerId || ''
        };
        localStorage.setItem(DEMO_KEY, JSON.stringify(localUser));
        setUser(localUser);
        return;
      } catch (err) {
        if (!error) setError(err.message || 'Unable to sign in.');
        throw err;
      }
    }
    try {
      const onlineUser = await signInOnline(username, password);
      pendingOnlineLogin.current = null;
      setUser(onlineUser);
    } catch (err) {
      const cached = findOfflineUser(username) || findOfflineUser(loginEmailFor(username));
      if (isNetworkAuthError(err) && cached && cached.active !== false && await verifyOfflinePassword(cached, password)) {
        const offlineUser = publicUser({ ...cached, offlineAuth: true });
        pendingOnlineLogin.current = { username, password };
        localStorage.setItem(DEMO_KEY, JSON.stringify(offlineUser));
        setError('Offline login active. This device will reconnect and sync when internet returns.');
        setUser(offlineUser);
        return;
      }
      const friendly = err.code === 'auth/invalid-credential'
        ? 'The username or password is incorrect.'
        : isNetworkAuthError(err)
          ? 'Offline login is available after this user signs in online once on this device.'
        : 'Unable to sign in. Check your Firebase settings and try again.';
      setError(friendly);
      throw new Error(friendly);
    }
  };

  const demoLogin = role => {
    const demoUser = demoUsers[role];
    localStorage.setItem(DEMO_KEY, JSON.stringify(demoUser));
    setUser(demoUser);
  };

  const logout = async () => {
    pendingOnlineLogin.current = null;
    if (firebaseEnabled) {
      const flushSync = window.__backwoodsVendorFlushSync;
      if (typeof flushSync === 'function') await flushSync().catch(() => {});
      window.dispatchEvent(new Event('backwoods:flush-sync'));
      await firebaseSignOut(auth);
    }
    localStorage.removeItem(DEMO_KEY);
    setUser(null);
  };

  const value = useMemo(() => ({ user, loading, error, login, demoLogin, logout, firebaseEnabled }), [user, loading, error]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const value = useContext(AuthContext);
  if (!value) throw new Error('useAuth must be used inside AuthProvider');
  return value;
}
