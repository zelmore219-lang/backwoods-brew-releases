export const SOURCE='vendor-ordering';
export const owned=row=>row?.sourceSystem===SOURCE;
export const id=(kind,value)=>`vendor:${kind}:${encodeURIComponent(String(value))}`;
export function money(value,label='Amount'){
 const n=Number(value??0);if(!Number.isFinite(n))throw new Error(`${label} is invalid.`);
 const v=Math.round((n+Math.sign(n)*Number.EPSILON)*100);if(!Number.isSafeInteger(v))throw new Error(`${label} is too large.`);return v;
}
const dollars=v=>v/100;
const nonneg=(value,label)=>{const n=money(value,label);if(n<0)throw new Error(`${label} cannot be negative.`);return n;};
export function dateOf(value){const date=String(value||'').slice(0,10);if(!/^\d{4}-\d{2}-\d{2}$/.test(date)||new Date(date+'T12:00:00Z').toISOString().slice(0,10)!==date)throw new Error('A valid transaction date is required.');return date;}
const qty=(v,label)=>{const n=Number(v||0);if(!Number.isFinite(n)||n<0)throw new Error(`${label} is invalid.`);return n;};
const journal=(key,date,storeId,memo,lines)=>({id:key,date,storeId:String(storeId),memo,sourceSystem:SOURCE,lines:lines.filter(l=>l.debit||l.credit).map(l=>({...l,debit:dollars(l.debit||0),credit:dollars(l.credit||0)}))});
const pair=(dr,cr,value)=>[{account:dr,debit:value},{account:cr,credit:value}];
export function balanced(entry){return entry.lines.reduce((n,l)=>n+money(l.debit)-money(l.credit),0)===0;}
export function projectOrder(order,source,config={}){
 if(!order.id)throw new Error('Vendor order is missing its ID.');
 const prior=order.mainAccountingSnapshot;
 const status=String(order.status||'').toLowerCase();
 if(!['delivered','completed','payment_pending','paid','invoiced','void','cancelled'].includes(status)){if(prior)throw new Error('Previously posted invoice is no longer delivered; review the correction.');return null;}
 if(order.mainAppSyncStatus==='ignored'){if(prior)throw new Error('Previously posted invoice was ignored; review its accounting correction.');return null;}
 if(['void','cancelled'].includes(status)){
  if(prior)throw new Error('A previously included invoice was voided. Review its refund/credit and accounting correction before replacing the posted snapshot.');
  return null;
 }
 const customer=source.customers.find(c=>String(c.id)===String(order.customerId));
 if(!customer)throw new Error('Customer record is missing.');
 const invoiceNo=order.invoiceNumber||order.orderNumber;if(!invoiceNo)throw new Error('Invoice number is missing.');
 if(!order.items?.length)throw new Error('Invoice has no items.');
 const date=dateOf(order.deliveredAt||order.invoiceDate||order.createdAt);
 const storeId=String(config.storeId||'1');
 let gross=0,returns=0,cogs=0;const lineCosts={};
 for(const line of order.items){
  const units=qty(line.invoiceQty??line.deliveredQty??line.qty,'Delivered quantity');
  const back=qty(line.returnQty,'Returned quantity');
  const pct=Number(line.returnCreditPercent??100);if(!Number.isFinite(pct)||pct<0||pct>100)throw new Error('Invalid return credit percentage.');
  gross+=Math.round(units*nonneg(line.price,'Price'));returns+=Math.round(back*nonneg(line.returnPrice??line.price,'Return price')*pct/100);
  const key=String(line.productId||line.sku||'');
  let cost=line.unitCost??prior?.lineCosts?.[key]?.unitCost??config.historicalCosts?.[key];
  if((units||back)&&cost==null)throw new Error(`Review the historical unit cost for ${line.name||key}.`);
  cost=Number(cost??0);if(!Number.isFinite(cost)||cost<0)throw new Error('Unit cost is invalid.');
  const returnCost=Number(line.returnUnitCost??prior?.lineCosts?.[key]?.returnUnitCost??cost);
  if(!Number.isFinite(returnCost)||returnCost<0)throw new Error('Return unit cost is invalid.');
  lineCosts[key]={unitCost:cost,returnUnitCost:returnCost};
  cogs+=money(units*cost);
  if(!line.returnDisposition||line.returnDisposition==='sellable')cogs-=money(back*returnCost);
 }
 const credit=(order.credits||[]).reduce((n,c)=>n+nonneg(c.amount,'Approved credit'),0);
 const net=gross-returns-credit;if(net<0)throw new Error('Credit exceeds invoice value; a separate credit memo needs review.');
 const tax=nonneg(order.tax,'Tax');const total=net+tax;
 const payments=new Map();
 for(const p of [...(order.payments||[]),...(source.payments||[]).filter(p=>String(p.orderId)===String(order.id))]){
  if(!p.id)throw new Error('A payment is missing its stable ID.');
  const amount=nonneg(p.amount,'Payment');const method=String(p.method||'').toLowerCase();if(!method)throw new Error('Payment method is missing.');
  const old=payments.get(p.id);if(old&&(old.amount!==amount||old.method!==method))throw new Error('Conflicting copies of a payment require review.');
  payments.set(p.id,{id:p.id,amount,method,date:dateOf(p.createdAt||p.date),reference:p.checkNumber||p.reference||''});
 }
 const paid=[...payments.values()].reduce((n,p)=>n+p.amount,0);if(paid>total)throw new Error('Payments exceed the invoice; review customer credits/refunds.');
 if(Number(order.amountCollected||0)>0&&!payments.size)throw new Error('Collection amount has no payment record.');
 const invoice={id:id('invoice',order.id),sourceSystem:SOURCE,vendorAccounting:true,sourceOrderId:order.id,invoiceNo,date,dueDate:dateOf(order.dueDate||new Date(new Date(date+'T12:00:00Z').getTime()+Number(String(customer.terms||'').match(/net\s*(\d+)/i)?.[1]||0)*86400000).toISOString()),customer:customer.name||order.customerName||'',account:'4000',subtotal:dollars(net),amount:dollars(net),tax:dollars(tax),total:dollars(total),paidAmount:dollars(paid),balance:dollars(total-paid),status:paid===total?'Paid':paid?'Partial':'Open',saleType:'Wholesale',storeId,description:`Vendor Ordering ${invoiceNo}`};
 const lines=[{account:'1100 Accounts Receivable',debit:total},{account:'4000 Sales Revenue',credit:net},{account:'2100 Sales Tax Payable',credit:tax}];
 const entries=[journal(id('sale',order.id),date,storeId,`Vendor invoice ${invoiceNo}`,lines)];
 for(const p of payments.values())entries.push(journal(id('payment',p.id),p.date,storeId,`Vendor payment ${invoiceNo} ${p.reference}`,pair(p.method==='cash'?'1010 Cash on Hand':'1020 Bank Account','1100 Accounts Receivable',p.amount)));
 if(cogs)entries.push(journal(id('cogs',order.id),date,storeId,`Vendor COGS ${invoiceNo}`,cogs>0?pair('5000 Cost of Goods Sold','1200 Inventory Asset',cogs):pair('1200 Inventory Asset','5000 Cost of Goods Sold',-cogs)));
 if(!entries.every(balanced))throw new Error('Vendor journal does not balance.');
 return {schemaVersion:1,invoice,journalEntries:entries,lineCosts};
}
export function stripVendor(data){
 const next={...data};for(const key of ['invoices','bills','journalEntries','inventory','wholesaleCustomers'])if(Array.isArray(data[key]))next[key]=data[key].filter(row=>!owned(row));
 delete next.vendorAccountingSummary;delete next.vendorInventory;return next;
}
export function combine(native,source,config={}){
 const base=stripVendor(native);const invoices=[],entries=[],issues=[],snapshots=[];const storeId=String(config.storeId||'1');
 if(!config.enabled)return {data:base,issues,snapshots};
 for(const order of source.orders||[]){
  try{
   const projection=projectOrder(order,source,config);if(!projection)continue;
   const prior=order.mainAccountingSnapshot;
   for(const entry of projection.journalEntries){
    const locked=(base.accountingPeriods||[]).some(p=>p.locked&&entry.date>=p.startDate&&entry.date<=p.endDate);
    const old=prior?.journalEntries?.find(row=>row.id===entry.id);
    if(locked&&JSON.stringify(old)!==JSON.stringify(entry))throw new Error(`Accounting period ${entry.date} is locked.`);
   }
   invoices.push(projection.invoice);entries.push(...projection.journalEntries);snapshots.push({order,projection});
  }catch(error){
   issues.push({id:order.id,invoice:order.invoiceNumber||order.orderNumber||order.id,message:error.message});
   if(order.mainAccountingSnapshot?.schemaVersion===1){invoices.push(order.mainAccountingSnapshot.invoice);entries.push(...order.mainAccountingSnapshot.journalEntries);}
  }
 }
 const inventory=(source.products||[]).map(p=>({id:id('stock',p.id),sourceSystem:SOURCE,vendorAccounting:true,vendorProductId:p.id,item:`Vendor / ${p.name}`,sku:p.sku||'',category:`Vendor / ${p.category||'Products'}`,qty:qty(p.onHand,'Stock'),unit:p.unit||'each',cost:Number(p.cost||0),low:Number(p.reorderLevel||0),reserved:Number(p.reserved||0),damagedStock:Number(p.damagedStock||0),expiredStock:Number(p.expiredStock||0),quarantineStock:Number(p.quarantineStock||0),vendor:p.lastSupplierId||'',storeId}));
 
 const bills=[];
 for(const receipt of source.purchaseReceipts||[]){
  try{
   const po=(source.purchaseOrders||[]).find(p=>p.id===receipt.purchaseOrderId);
   const supplier=(source.suppliers||[]).find(s=>s.id===(receipt.supplierId||po?.supplierId));
   const value=nonneg(receipt.landedCostTotal,'Received inventory cost');if(!value)continue;
   if(!receipt.accountingCostCaptured)throw new Error('Review this older receipt’s landed cost before including it in accounting.');
   const date=dateOf(receipt.createdAt);
   const bill={id:id('receipt-bill',receipt.id),sourceSystem:SOURCE,vendorAccounting:true,date,dueDate:po?.dueDate||date,vendor:supplier?.name||'Vendor supplier',category:'Inventory received',account:'1200',amount:dollars(value),status:'Open',storeId,description:receipt.poNumber||po?.poNumber||receipt.id};
   bills.push(bill);entries.push(journal(id('receipt',receipt.id),date,storeId,`Vendor goods received ${bill.description}`,pair('1200 Inventory Asset','2000 Accounts Payable',value)));
  }catch(error){issues.push({id:receipt.id,invoice:receipt.poNumber||receipt.id,message:error.message});}
 }
 for(const movement of source.inventoryMovements||[]){
  if(!movement.accountingCostCaptured||!['adjustment','opening_balance','bulk_opening_balance'].includes(movement.type))continue;
  try{
   const quantity=Number(movement.quantity);if(!Number.isFinite(quantity))throw new Error('Invalid stock adjustment quantity.');
   const value=money(quantity*nonneg(movement.unitCost,'Stock adjustment unit cost')/100);if(!value)continue;
   const date=dateOf(movement.createdAt),opening=movement.type!=='adjustment',offset=opening?'3000 Owner Equity':'5000 Cost of Goods Sold';
   entries.push(journal(id('stock-movement',movement.id),date,storeId,movement.note||'Vendor inventory adjustment',value>0?pair('1200 Inventory Asset',offset,value):pair(offset,'1200 Inventory Asset',-value)));
  }catch(error){issues.push({id:movement.id,invoice:'Stock adjustment',message:error.message});}
 }
 for(const po of source.purchaseOrders||[]){
  if(['paid','partially_paid'].includes(po.supplierInvoiceStatus))issues.push({id:po.id,invoice:po.poNumber||po.id,message:'Supplier invoice is marked paid without a dated supplier payment transaction. Review its bank/payment journal before clearing the payable.'});
 }
 const currentValue=inventory.reduce((n,p)=>n+money(p.qty*p.cost),0);
 const inventoryPosted=entries.flatMap(e=>e.lines).filter(l=>String(l.account).startsWith('1200')).reduce((n,l)=>n+money(l.debit)-money(l.credit),0);
 const opening=currentValue-inventoryPosted;
 if(config.openingApproved){
  const approved=money(config.openingValue);if(approved)entries.push(journal(id('opening','inventory'),config.openingDate||new Date().toISOString().slice(0,10),storeId,'Approved vendor opening inventory reconciliation',approved>0?pair('1200 Inventory Asset','3000 Owner Equity',approved):pair('3000 Owner Equity','1200 Inventory Asset',-approved)));
 }else if(currentValue||inventoryPosted){issues.push({id:'inventory-opening',invoice:'Inventory opening',message:`Review the vendor opening inventory reconciliation of $${dollars(opening).toFixed(2)}.`,openingValue:dollars(opening)});}
 if(config.openingApproved&&Math.abs(money(config.openingValue)-opening)>1)issues.push({id:'inventory-reconcile',invoice:'Inventory reconciliation',message:`Vendor stock value differs from its ledger by $${dollars(opening-money(config.openingValue)).toFixed(2)}. Review adjustments and missing costs; no automatic equity adjustment was made.`});
 const data={...base,invoices:[...base.invoices,...invoices],bills:[...base.bills,...bills],journalEntries:[...base.journalEntries,...entries],vendorInventory:inventory};
 data.vendorAccountingSummary={invoiceCount:invoices.length,sales:invoices.reduce((n,i)=>n+i.subtotal,0),receivable:invoices.reduce((n,i)=>n+i.balance,0),inventoryValue:dollars(currentValue),openingValue:dollars(opening),issues:issues.length};
 return {data,issues,snapshots};
}
export function profitLoss(original,data){
 const vendor=(data.journalEntries||[]).filter(owned).flatMap(e=>e.lines||[]);
 const sales=vendor.filter(l=>String(l.account).startsWith('4000')).reduce((n,l)=>n+Number(l.credit||0)-Number(l.debit||0),0);
 const cogs=vendor.filter(l=>String(l.account).startsWith('5000')).reduce((n,l)=>n+Number(l.debit||0)-Number(l.credit||0),0);
 return original.map(row=>({...row,amount:row.amount+(['Net Sales'].includes(row.line)?sales:row.line==='COGS + Waste'?cogs:['Gross Profit','Net Profit'].includes(row.line)?sales-cogs:0)}));
}
