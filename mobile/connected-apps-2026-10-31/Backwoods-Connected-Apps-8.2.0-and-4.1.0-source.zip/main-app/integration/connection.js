import {combine,stripVendor,profitLoss,owned,money} from './accounting.js';
const empty=()=>({orders:[],customers:[],products:[],payments:[],purchaseReceipts:[],purchaseOrders:[],suppliers:[],inventoryMovements:[]});
let lastAttempt=0;
let source=empty(),identity='',lastFetch=0,status='Open Vendor Connection to connect.',busy=false,revision=0,lastResult=null,lastNative=null,lastConfig='',currentKey='',projection=null,stale=false;
const ctx=()=>window.__backwoodsMainContext;
const allowed=()=>['owner','admin','administrator','manager','accountant','accounting','bookkeeper'].includes(String(ctx()?.getUser()?.role||'').toLowerCase());
const account=()=>{const c=ctx(),u=c?.getAuth()?.currentUser;return allowed()&&u?`${c.projectId}:${u.uid}`:'';};
const settings=()=>ctx()?.getData()?.vendorAccountingLink||{};
function clear(){source=empty();lastFetch=0;identity='';projection=null;lastResult=null;lastNative=null;revision++;}
function result(data){
 if(account()!==identity||!identity||!allowed())return {data:stripVendor(data),issues:[],snapshots:[]};
 const config=JSON.stringify(settings()),key=`${revision}:${config}`;
 if(lastNative===data&&currentKey===key&&lastResult)return lastResult;
 lastNative=data;currentKey=key;
 try{lastResult=combine(data,source,settings());}catch(e){lastResult={data:stripVendor(data),issues:[{invoice:'Vendor data',message:e.message}],snapshots:[]};}
 return lastResult;
}
window.__vendorLink={project:data=>result(data).data,strip:stripVendor,profitLoss,owned};
export function decode(value){
 if('nullValue'in value)return null;if('stringValue'in value)return value.stringValue;if('booleanValue'in value)return value.booleanValue;
 if('integerValue'in value)return Number(value.integerValue);if('doubleValue'in value)return value.doubleValue;if('timestampValue'in value)return value.timestampValue;
 if(value.arrayValue)return(value.arrayValue.values||[]).map(decode);if(value.mapValue)return Object.fromEntries(Object.entries(value.mapValue.fields||{}).map(([k,v])=>[k,decode(v)]));
 throw new Error('Unsupported Firestore value.');
}
export function encode(value){
 if(value==null)return{nullValue:null};if(typeof value==='string')return{stringValue:value};if(typeof value==='boolean')return{booleanValue:value};
 if(typeof value==='number'){if(!Number.isFinite(value))throw new Error('Invalid accounting amount.');return Number.isInteger(value)?{integerValue:String(value)}:{doubleValue:value};}
 if(Array.isArray(value))return{arrayValue:{values:value.map(encode)}};
 return{mapValue:{fields:Object.fromEntries(Object.entries(value).filter(([,v])=>v!==undefined).map(([k,v])=>[k,encode(v)]))}};
}
function base(){return`https://firestore.googleapis.com/v1/projects/${encodeURIComponent(ctx().projectId)}/databases/(default)/documents`;}
async function api(path,options={},expected=identity){
 if(!expected||account()!==expected)throw new Error('Sign in to your Firebase account again.');
 const token=await ctx().getAuth().currentUser.getIdToken();
 const response=await fetch(`${base()}/${path}`,{...options,headers:{Authorization:`Bearer ${token}`,'Content-Type':'application/json',...options.headers},signal:AbortSignal.timeout(30000)});
 if(account()!==expected)throw new Error('Account changed; refresh cancelled.');
 const payload=await response.json();
 if(!response.ok)throw new Error(payload.error?.status==='PERMISSION_DENIED'?'Missing permission: this account needs an active vendor profile and vendor accounting access.':payload.error?.message||`Connection failed (${response.status}).`);
 return payload;
}
const masks={orders:['id','status','items','customerId','customerName','invoiceNumber','orderNumber','tax','credits','payments','deliveredAt','invoiceDate','createdAt','dueDate','amountCollected','mainAccountingSnapshot','mainAppSyncedAt','mainAppSyncStatus','mainAppSyncFingerprint'],customers:['id','name','terms'],products:['id','name','sku','category','onHand','unit','cost','reorderLevel','reserved','damagedStock','expiredStock','quarantineStock'],payments:['id','orderId','amount','method','date','createdAt','checkNumber','reference'],purchaseReceipts:['id','purchaseOrderId','poNumber','supplierId','landedCostTotal','createdAt','accountingCostCaptured'],purchaseOrders:['id','supplierId','poNumber','dueDate','supplierInvoiceStatus'],suppliers:['id','name'],inventoryMovements:['id','type','quantity','unitCost','accountingCostCaptured','createdAt','note']};
export async function list(name,expected=identity){
 const collection='vendor'+name[0].toUpperCase()+name.slice(1);let pageToken='',rows=[];
 do{
  const query=new URLSearchParams({pageSize:'200'});for(const field of masks[name])query.append('mask.fieldPaths',field);if(pageToken)query.set('pageToken',pageToken);
  const payload=await api(`${collection}?${query}`,{},expected);
  for(const document of payload.documents||[])rows.push({...Object.fromEntries(Object.entries(document.fields||{}).map(([k,v])=>[k,decode(v)])),id:decodeURIComponent(document.name.split('/').pop()),_updateTime:document.updateTime});
  pageToken=payload.nextPageToken||'';
 }while(pageToken);
 return rows;
}
async function fingerprint(value){const bytes=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify(value)));return Array.from(new Uint8Array(bytes),v=>v.toString(16).padStart(2,'0')).join('');}
function cache(){try{localStorage.setItem(`backwoods-vendor-accounting-v1:${identity}`,JSON.stringify({source,lastFetch}));}catch{status='Connected; offline cache could not be saved.';}}
async function acknowledge(rows,expected){
 for(const {order,projection}of rows){
  const hash=await fingerprint(projection);if(order.mainAppSyncFingerprint===hash&&order.mainAppSyncedAt)continue;
  const fields={mainAccountingSnapshot:projection,mainAppSyncFingerprint:hash,mainAppSyncStatus:'synced',mainAppSyncedAt:new Date().toISOString(),mainAppImportedBy:ctx().getAuth().currentUser.uid};
  const query=new URLSearchParams();for(const key of Object.keys(fields))query.append('updateMask.fieldPaths',key);if(order._updateTime)query.set('currentDocument.updateTime',order._updateTime);
  const response=await api(`vendorOrders/${encodeURIComponent(order.id)}?${query}`,{method:'PATCH',body:JSON.stringify({fields:Object.fromEntries(Object.entries(fields).map(([k,v])=>[k,encode(v)]))})},expected);
  Object.assign(order,fields,{_updateTime:response.updateTime});
 }
}
async function refresh(manual=false){
 if(busy)return;const key=account();if(!key){status='Sign in with a main app account that also has vendor accounting access.';render();return;}
 if(!settings().enabled&&!manual)return;
 busy=true;lastAttempt=Date.now();status='Reading vendor records…';render();
 try{
  if(identity!==key){clear();identity=key;}
  const names=Object.keys(masks);const rows=await Promise.all(names.map(name=>list(name,key)));
  if(account()!==key)return;
  source=Object.fromEntries(names.map((name,index)=>[name,rows[index]]));lastFetch=Date.now();stale=false;revision++;cache();ctx().refresh();
  const projected=result(ctx().getData());
  if(settings().enabled){await acknowledge(projected.snapshots,key);cache();}
  status=`Connected. Updated ${new Date(lastFetch).toLocaleTimeString()}.`;
 }catch(error){status=error.message;stale=true;}
 finally{busy=false;render();}
}
function configure(patch){if(!allowed())return;ctx().setData(data=>({...stripVendor(data),vendorAccountingLink:{...data.vendorAccountingLink,...patch}}));revision++;setTimeout(()=>{ctx()?.refresh();render();},0);}
function node(tag,text,parent){const n=document.createElement(tag);if(text!=null)n.textContent=text;parent?.append(n);return n;}
function button(parent,text,action){const b=node('button',text,parent);b.type='button';b.onclick=action;return b;}
function currency(v){return new Intl.NumberFormat('en-US',{style:'currency',currency:'USD'}).format(v||0);}
let panel;
function render(){
 if(!panel?.isConnected)return;
 if(!allowed()){panel.remove();return;}
 if(panel.querySelector(':focus')?.matches('input,select'))return;
 panel.replaceChildren();const header=node('div',null,panel);header.className='vendor-link-header';node('h2','Vendor Connection',header);button(header,'Close',()=>panel.remove());
 node('p','Vendor sales feed main accounting. Coffee-shop sales and supplies stay separate. Edit vendor invoices, payments, and stock in Vendor Ordering.',panel);
 node('p',status+(stale&&lastFetch?` Showing cached records from ${new Date(lastFetch).toLocaleString()}.`:''),panel);
 const config=settings(),actions=node('div',null,panel);actions.className='vendor-link-actions';
 if(!config.enabled){
  const label=node('label','Accounting store ',panel);const select=node('select',null,label);select.id='vendor-accounting-store';
  const stores=ctx().getData().stores||[{id:'1',name:'Main store'}];for(const store of stores){const option=node('option',store.name||store.id,select);option.value=String(store.id);}
  select.value=String(config.storeId||ctx().getData().settings?.activeStoreId||stores[0]?.id||'1');
  button(actions,'Enable accounting connection',()=>{configure({enabled:true,storeId:select.value||'1'});setTimeout(()=>refresh(true),0);});
 }else button(actions,'Disable accounting connection',()=>configure({enabled:false}));
 button(actions,'Refresh now',()=>refresh(true)).disabled=busy;
 const projected=result(ctx().getData()),summary=projected.data.vendorAccountingSummary;
 if(summary){node('p',`${summary.invoiceCount} vendor invoices · Sales ${currency(summary.sales)} · Receivables ${currency(summary.receivable)} · Vendor inventory ${currency(summary.inventoryValue)}`,panel);}
 if(source.orders.length&&config.enabled){
  const missing=new Map();for(const order of source.orders){if(!['delivered','completed','paid','payment_pending','invoiced'].includes(String(order.status).toLowerCase()))continue;for(const line of order.items||[]){const key=String(line.productId||line.sku||'');if((Number(line.invoiceQty??line.deliveredQty??line.qty)||Number(line.returnQty))&&line.unitCost==null&&order.mainAccountingSnapshot?.lineCosts?.[key]?.unitCost==null&&config.historicalCosts?.[key]==null)missing.set(key,line.name||key);}}
  if(missing.size){node('h3','Historical cost review',panel);node('p','Enter the documented cost per unit for older invoices. This applies to earlier invoices for that product; use the vendor invoice editor for invoice-specific costs. Enter zero only for a documented zero cost.',panel);const form=node('form',null,panel);const fields=[];
   for(const [id,name]of missing){const label=node('label',name+' ',form);const input=node('input',null,label);input.type='number';input.min='0';input.step='0.0001';input.required=true;input.setAttribute('aria-label',`Historical cost ${name}`);fields.push([id,input]);}
   const save=node('button','Approve entered historical costs',form);save.type='submit';form.onsubmit=event=>{event.preventDefault();const costs={...config.historicalCosts};for(const[id,input]of fields)costs[id]=Number(input.value);configure({historicalCosts:costs});setTimeout(()=>refresh(true),0);};
  }
 }
 if(summary&&!config.openingApproved&&summary.openingValue!==0){node('p',`Opening inventory reconciliation: ${currency(summary.openingValue)}. This posts inventory against opening owner equity; review source costs and all invoice issues first.`,panel);button(panel,'Approve opening inventory reconciliation',()=>{if(!window.confirm(`Post ${currency(summary.openingValue)} as opening vendor inventory against owner equity?`))return;configure({openingApproved:true,openingValue:summary.openingValue,openingDate:new Date().toISOString().slice(0,10)});}).disabled=projected.issues.some(issue=>issue.id!=='inventory-opening');}
 if(projected.issues.length){node('h3','Needs review',panel);const ul=node('ul',null,panel);for(const issue of projected.issues)node('li',`${issue.invoice}: ${issue.message}`,ul);}
 if(source.products.length){node('h3','Vendor stock — separate from coffee-shop supplies',panel);const scroll=node('div',null,panel);scroll.className='vendor-stock-scroll';const table=node('table',null,scroll),head=node('tr',null,table);for(const text of ['Product','SKU','On hand','Reserved','Unit cost'])node('th',text,head);for(const product of source.products){const row=node('tr',null,table);for(const text of [product.name,product.sku,product.onHand||0,product.reserved||0,currency(product.cost)])node('td',String(text??''),row);}}
}
function open(){if(panel?.isConnected){render();return;}panel=document.createElement('section');panel.id='vendor-connection-panel';panel.setAttribute('role','dialog');panel.setAttribute('aria-label','Vendor Connection');document.body.append(panel);render();}
setInterval(()=>{
 const key=account();if(key!==identity){clear();identity=key;if(key)try{const saved=JSON.parse(localStorage.getItem(`backwoods-vendor-accounting-v1:${key}`)||'null');if(saved){source=saved.source;lastFetch=saved.lastFetch;stale=true;status=`Offline cache loaded. Last update ${new Date(lastFetch).toLocaleString()}.`;revision++;}}catch{}ctx()?.refresh();}
 const aside=document.querySelector('.bb-app > aside');let b=document.getElementById('vendor-connection-button');
 if(allowed()&&aside){if(!b){b=node('button','Vendor Connection',aside);b.id='vendor-connection-button';b.type='button';b.onclick=open;}}
 else{b?.remove();panel?.remove();}
 if(key&&settings().enabled&&!busy&&Date.now()-lastAttempt>30000&&navigator.onLine)refresh();
},2000);
window.addEventListener('online',()=>refresh());
