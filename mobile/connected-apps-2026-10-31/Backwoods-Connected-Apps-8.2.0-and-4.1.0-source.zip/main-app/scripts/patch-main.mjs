import {readFile,writeFile} from 'node:fs/promises';
let source=await readFile('integration/main-baseline.js','utf8');
function once(a,b){if(source.split(a).length!==2)throw new Error('Main patch target changed: '+a.slice(0,100));source=source.replace(a,b);}
function section(start,end,edit){const first=source.indexOf(start),last=source.indexOf(end,first+start.length);if(first<0||last<0)throw new Error('Missing section '+start);source=source.slice(0,first)+edit(source.slice(first,last))+source.slice(last);}
for(const [start,end]of [['function io(t = {}) {','function Wd('],['function Ga(t) {','function Wn(t) {']]){
 // io has additional helpers before Wd; keep changes scoped to its own source boundary.
 const first=source.indexOf(start);const boundary=start.startsWith('function io')?source.indexOf('\nfunction ',first+start.length):source.indexOf(end,first+start.length);
 if(first<0||boundary<0)throw new Error('Missing ledger function');
 let text=source.slice(first,boundary);for(const name of ['invoices','bills']){const needle=`(t.${name} || []).forEach(`;if(!text.includes(needle))throw new Error('Missing ledger '+name);text=text.replaceAll(needle,`(t.${name} || []).filter(row => row.sourceSystem !== "vendor-ordering").forEach(`);}source=source.slice(0,first)+text+source.slice(boundary);
}
section('function Qo(t) {','function Go(t) {',text=>text.replace('function Qo(t) {','function vendorNativeProfitLoss(t) {').replace('(t.invoices || []).reduce','(t.invoices || []).filter(row => row.sourceSystem !== "vendor-ordering").reduce').replace('(t.bills || []).filter(o => o.status === "Paid")','(t.bills || []).filter(o => o.status === "Paid" && o.sourceSystem !== "vendor-ordering")')+'function Qo(t) { const original = vendorNativeProfitLoss(t); return window.__vendorLink ? window.__vendorLink.profitLoss(original,t) : original; }\n');
once('async function Ji(t) {','async function Ji(t) {\n  t = window.__vendorLink ? window.__vendorLink.strip(t) : t;');
once('async function uu(t) {','async function uu(t) {\n  t = window.__vendorLink ? window.__vendorLink.strip(t) : t;');
once('...Ma(typeof J == "function" ? J(r) : J),','...Ma(window.__vendorLink ? window.__vendorLink.strip(typeof J == "function" ? J(r) : J) : (typeof J == "function" ? J(r) : J)),');
once('  if (t) return e.createElement("div", {\n    className: "min-h-screen bg-stone-950 text-white p-10"','  window.__backwoodsMainContext = { getData: () => r, getUser: () => a, getAuth: () => Ba, projectId: cd.projectId, setData: g, refresh: () => s(previous => ({...previous})) };\n  if (t) return e.createElement("div", {\n    className: "min-h-screen bg-stone-950 text-white p-10"');
once('  const F = r,\n    b = De(a == null ? void 0 : a.role),','  const F = window.__vendorLink ? window.__vendorLink.project(r) : r,\n    b = De(a == null ? void 0 : a.role),');
once('a && e.createElement("td", null, a(s))','a && e.createElement("td", null, s.sourceSystem === "vendor-ordering" ? "Manage in Vendor Ordering" : a(s))');
once('c = u(s[a] || s.total);','c = u(s.sourceSystem === "vendor-ordering" && s.balance != null ? s.balance : (s[a] || s.total));');
source=source.split('\n').map(line=>line.includes('.invoices || []).filter')&&line.includes('paid')&&line.includes('.reduce(')?line.replace(/u\((\w+)\.total(?: \|\| \1\.amount)?\)/g,'u($1.sourceSystem === "vendor-ordering" ? $1.balance : ($1.total || $1.amount))'):line).join('\n');
section('function _p({','function ',text=>text.replace('B + u(ue.total), 0),\n    E = F.reduce((B, ue) => B + u(ue.total), 0),','B + u(ue.sourceSystem === "vendor-ordering" ? ue.balance : ue.total), 0),\n    E = F.reduce((B, ue) => B + u(ue.sourceSystem === "vendor-ordering" ? ue.balance : ue.total), 0),'));
once('fields: ["invoiceNo", "date", "dueDate", "saleType", "customer", "account", "subtotal", "tax", "total", "status"]','fields: ["invoiceNo", "date", "dueDate", "saleType", "customer", "account", "subtotal", "tax", "total", "paidAmount", "balance", "status", "sourceSystem"]');
await writeFile('www/assets/main-CnsZnSKS.js',source);
console.log('Patched preserved main app: vendor accounting projection, journals, partial A/R, read-only source rows.');
