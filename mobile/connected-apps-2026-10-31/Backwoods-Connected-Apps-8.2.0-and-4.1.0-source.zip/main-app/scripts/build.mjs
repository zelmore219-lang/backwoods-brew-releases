import { cp, mkdir, readFile, writeFile, rm } from 'node:fs/promises';
import { build } from 'esbuild';
await rm('www', { recursive: true, force: true });
await mkdir('www', { recursive: true });
await cp('packaged-web', 'www', { recursive: true });
await build({ entryPoints: ['mobile/main.js'], bundle: true, format: 'iife', outfile: 'www/mobile.js', minify: true, target: ['chrome110', 'safari15'], legalComments: 'eof' });
for (const file of ['index.html', 'clock.html']) {
  let html = await readFile(`www/${file}`, 'utf8');
  html = html.replace('initial-scale=1.0', 'initial-scale=1.0, viewport-fit=cover');
  // Weather requests use the original browser fallback instead of Electron IPC.
  html = html.replace("connect-src 'self'", "connect-src 'self' blob: data: https://api.weather.gov");
  html = html.replace('</head>', '<link rel="stylesheet" href="./mobile.css"><script src="./mobile.js"></script></head>');
  await writeFile(`www/${file}`, html);
}
await import('./patch-main.mjs');
console.log('Main 8.2.0 web assets built.');
