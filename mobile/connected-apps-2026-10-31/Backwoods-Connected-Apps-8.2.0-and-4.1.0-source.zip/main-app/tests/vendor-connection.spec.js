import {test,expect} from '@playwright/test';
const encode=v=>v==null?{nullValue:null}:typeof v==='string'?{stringValue:v}:typeof v==='number'?{doubleValue:v}:typeof v==='boolean'?{booleanValue:v}:Array.isArray(v)?{arrayValue:{values:v.map(encode)}}:{mapValue:{fields:Object.fromEntries(Object.entries(v).map(([k,x])=>[k,encode(x)]))}};
const collection={vendorOrders:[{id:'o',invoiceNumber:'INV-TEST',customerId:'c',status:'delivered',deliveredAt:'2026-10-30',items:[{productId:'p',name:'Vendor product',invoiceQty:2,price:10,unitCost:3}],payments:[{id:'pay',orderId:'o',amount:5,method:'Cash',createdAt:'2026-10-30'}]}],vendorCustomers:[{id:'c',name:'Test store'}],vendorProducts:[{id:'p',name:'Vendor product',onHand:8,cost:3}],vendorPayments:[],vendorPurchaseReceipts:[],vendorPurchaseOrders:[],vendorSuppliers:[]};
async function setup(page,{denied=false}={}){
 let patches=[];
 await page.route('**/integration-harness',route=>route.fulfill({contentType:'text/html',body:'<!doctype html><html><head><link rel="stylesheet" href="/mobile.css"><script src="/mobile.js"></script></head><body><div class="bb-app"><aside></aside><main>Isolated integration test</main></div></body></html>'}));
 await page.route('https://firestore.googleapis.com/**',async route=>{
  const request=route.request(),url=new URL(request.url());
  if(denied)return route.fulfill({status:403,contentType:'application/json',body:JSON.stringify({error:{status:'PERMISSION_DENIED'}})});
  if(request.method()==='PATCH'){patches.push(JSON.parse(request.postData()));return route.fulfill({contentType:'application/json',body:JSON.stringify({updateTime:'2026-10-31T13:00:00Z'})});}
  const name=url.pathname.split('/').pop(),rows=collection[name]||[];
  await route.fulfill({contentType:'application/json',body:JSON.stringify({documents:rows.map(row=>({name:`projects/isolated-test/databases/(default)/documents/${name}/${row.id}`,fields:encode(row).mapValue.fields,updateTime:'2026-10-30T13:00:00Z'}))})});
 });
 await page.addInitScript(()=>{
  window.__fixtureUser={role:'owner'};window.__fixtureAuth={currentUser:{uid:'isolated-owner',getIdToken:async()=>'FAKE-TEST-TOKEN'}};
  window.__fixtureData={orders:[{id:'coffee-shop-sale',total:100}],stores:[{id:'1',name:'Coffee shop'}],invoices:[],inventory:[{id:'milk',qty:4,cost:2}],bills:[],journalEntries:[],accountingPeriods:[]};
  window.__backwoodsMainContext={getData:()=>window.__fixtureData,getUser:()=>window.__fixtureUser,getAuth:()=>window.__fixtureAuth,projectId:'isolated-test',setData:updater=>{window.__fixtureData=updater(window.__fixtureData);},refresh:()=>{window.__refreshes=(window.__refreshes||0)+1;}};
 });
 await page.goto('/integration-harness');await page.getByRole('button',{name:'Menu',exact:true}).click();await page.getByRole('button',{name:'Vendor Connection',exact:true}).click();return patches;
}
test('connect, acknowledge once, project accounting, persist configuration, and clear on logout',async({page})=>{
 const patches=await setup(page);await page.getByRole('button',{name:'Enable accounting connection'}).click();await expect(page.getByRole('dialog')).toContainText('Connected. Updated');await expect(page.getByRole('dialog')).toContainText('1 vendor invoices');
 expect(patches).toHaveLength(1);expect(patches[0].fields.mainAccountingSnapshot.mapValue.fields.invoice).toBeTruthy();
 const data=await page.evaluate(()=>({native:window.__fixtureData,merged:window.__vendorLink.project(window.__fixtureData)}));
 expect(data.native.invoices).toHaveLength(0);expect(data.native.vendorAccountingLink.enabled).toBe(true);expect(data.merged.invoices[0].balance).toBe(15);expect(data.merged.inventory).toEqual([{id:'milk',qty:4,cost:2}]);
 await page.evaluate(()=>{window.__fixtureAuth.currentUser=null;window.__fixtureUser=null;});await expect(page.getByRole('dialog')).toHaveCount(0);
 expect(await page.evaluate(()=>window.__vendorLink.project(window.__fixtureData).invoices)).toEqual([]);
});
test('permission failure is visible and does not change native accounts or stock',async({page})=>{
 const patches=await setup(page,{denied:true});await page.getByRole('button',{name:'Enable accounting connection'}).click();await expect(page.getByRole('dialog')).toContainText('Missing permission');expect(patches).toHaveLength(0);expect(await page.evaluate(()=>window.__fixtureData.inventory[0].qty)).toBe(4);
});
