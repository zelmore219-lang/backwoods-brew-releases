# Backwoods Vendor Ordering - Pilot Launch Checklist

## Before connecting real data
- [ ] Copy `.env.example` to `.env` and enter the Firebase web configuration.
- [ ] Set `VITE_SESSION_TIMEOUT_MINUTES` (60 is the default).
- [ ] Publish `firestore.rules`.
- [ ] Sign in as owner and create one profile for each test role.
- [ ] Open System Diagnostics and resolve every red item.
- [ ] Download a full backup.

## Master data
- [ ] Import or enter real customers.
- [ ] Import or enter real products, prices, costs, barcodes, and opening quantities.
- [ ] Enter suppliers and purchasing terms.
- [ ] Verify company name, logo, tax rate, invoice prefix, and payment instructions.

## End-to-end pilot order
- [ ] Sales creates and submits one order.
- [ ] Inventory becomes reserved.
- [ ] Packer scans and packs every line.
- [ ] Manager assigns a route and driver.
- [ ] Driver downloads the route for offline use.
- [ ] Driver records delivered quantities, GPS, signature, payment, and any return photo.
- [ ] Final invoice total matches delivered quantities and credits.
- [ ] Inventory decreases correctly.
- [ ] Payment appears in Launch Center > Driver Settlements.
- [ ] Accounting marks the driver settlement complete.
- [ ] Invoice appears in the correct customer-aging bucket.

## Purchasing pilot
- [ ] Create and print a purchase order.
- [ ] Receive a partial shipment by barcode.
- [ ] Confirm backordered and damaged quantities.
- [ ] Verify inventory and landed cost update.

## Device tests
- [ ] Windows desktop app opens after installation.
- [ ] PWA installs on one Android or iPhone device.
- [ ] Camera barcode scanning works over HTTPS.
- [ ] GPS permission works over HTTPS.
- [ ] Offline route remains visible with internet disconnected.
- [ ] Data synchronizes after reconnecting.

## Go-live gate
- [ ] Run `npm run build` without errors.
- [ ] Test every role on a separate account.
- [ ] Restore a backup into a test copy successfully.
- [ ] Pilot for at least one complete route before broader rollout.
