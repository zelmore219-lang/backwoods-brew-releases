# Store, Route, and Order Workflow Upgrade

## New features
- Customers are now presented as Stores.
- Stores include store number, city/state/ZIP, notes, and a dedicated weekly route.
- Routes are reusable weekly routes dedicated to Monday-Sunday.
- Stores can be added to a route and reordered into stop order.
- Products require both category and subcategory.
- The order screen supports store search, category filtering, subcategory filtering, product search, tap-to-add, and quantity steppers.
- New orders automatically record the selected store's route and delivery day.

## Firestore compatibility
- The existing `routePlans` state now syncs to the `vendorRoutes` Firestore collection to match the published vendor rules.
- Existing main-app collections remain untouched.

## Run
1. Extract the ZIP.
2. Open the extracted folder in VS Code.
3. Run `npm install`.
4. Run `npm run dev`.
