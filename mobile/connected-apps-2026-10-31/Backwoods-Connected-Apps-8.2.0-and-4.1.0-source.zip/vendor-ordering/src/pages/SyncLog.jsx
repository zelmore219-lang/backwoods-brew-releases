import { Download, RefreshCw } from 'lucide-react';
import { money, now } from '../lib/helpers';
import { buildSyncRows, syncSummary } from '../lib/syncStatus';

const csvCell = value => `"${String(value ?? '').replaceAll('"', '""')}"`;

function downloadCsv(name, rows) {
  if (!rows.length) return;
  const keys = Object.keys(rows[0]);
  const csv = [keys.join(','), ...rows.map(row => keys.map(key => csvCell(row[key])).join(','))].join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = name;
  link.click();
  URL.revokeObjectURL(url);
}

export default function SyncLog({ data, update }) {
  const rows = buildSyncRows(data);
  const summary = syncSummary(data);
  const readyRows = rows.filter(row => row.syncStatus === 'Ready for main app');
  const errorRows = rows.filter(row => row.syncStatus === 'Sync error');
  const exportRows = rows.filter(row => ['Ready for main app', 'Sync error'].includes(row.syncStatus));

  const patchOrder = (id, patch) => update(d => ({
    ...d,
    orders: (d.orders || []).map(order => order.id === id ? { ...order, ...patch, updatedAt: now() } : order)
  }));

  const retryFailed = () => update(d => ({
    ...d,
    orders: (d.orders || []).map(order => {
      const row = rows.find(item => item.id === order.id);
      return row?.syncStatus === 'Sync error'
        ? { ...order, mainAppSyncStatus: 'ready', mainAppSyncMessage: 'Retry queued from ordering app.', mainAppRetryAt: now(), updatedAt: now() }
        : order;
    })
  }));

  const requeue = row => patchOrder(row.id, {
    mainAppSyncStatus: 'ready',
    mainAppSyncMessage: 'Requeued for main app import.',
    mainAppSyncedAt: '',
    mainAppImportedBy: ''
  });

  const ignore = row => patchOrder(row.id, {
    mainAppSyncStatus: 'ignored',
    mainAppSyncMessage: 'Ignored in ordering app sync center.'
  });

  return <>
    <div className="page-head">
      <div><h1>Main App Sync Log</h1><p>See which invoices are ready, synced, or blocked before the main Backwoods Brew app imports them.</p></div>
      <div className="actions no-print">
        <button className="secondary" onClick={() => location.reload()}><RefreshCw size={17}/>Refresh</button>
        <button className="secondary" disabled={!errorRows.length} onClick={retryFailed}><RefreshCw size={17}/>Retry failed</button>
        <button onClick={() => downloadCsv('vendor-main-app-sync-log.csv', rows)}><Download size={17}/>Export CSV</button>
        <button disabled={!exportRows.length} onClick={() => downloadCsv('vendor-ready-invoices.csv', exportRows)}><Download size={17}/>Export ready/errors</button>
      </div>
    </div>

    <div className="stats report-stats">
      <div className="card"><span>Ready for main app</span><strong>{summary.ready}</strong><small>{money(summary.readyValue)}</small></div>
      <div className="card"><span>Synced</span><strong>{summary.synced}</strong><small>{money(summary.syncedValue)}</small></div>
      <div className="card"><span>Errors</span><strong>{summary.errors}</strong></div>
      <div className="card"><span>Blocked</span><strong>{summary.blocked}</strong></div>
      <div className="card"><span>Not ready</span><strong>{summary.notReady}</strong></div>
    </div>

    {readyRows.length > 0 && <div className="panel sync-callout">
      <div><h2>{readyRows.length} invoice(s) waiting for main app import</h2><p>Open the main Backwoods Brew app, open Vendor Connection, and enable the accounting connection. Both apps must use accounts with vendor accounting access.</p></div>
      <strong>{money(summary.readyValue)}</strong>
    </div>}

    <div className="panel table-scroll">
      <table>
        <thead><tr><th>Invoice</th><th>Customer</th><th>Order status</th><th>Main app status</th><th>Synced at</th><th>Total</th><th>Balance</th><th>Message</th><th></th></tr></thead>
        <tbody>{rows.map(row => <tr key={row.id}>
          <td><b>{row.invoice}</b><small>{row.route} {row.deliveryDay}</small></td>
          <td>{row.customer}</td>
          <td><span className="status">{row.orderStatus}</span></td>
          <td><span className={`status ${row.syncStatus === 'Synced to main app' ? 'success-status' : ['Sync error', 'Blocked'].includes(row.syncStatus) ? 'danger-status' : row.syncStatus === 'Ready for main app' ? 'warning-status' : ''}`}>{row.syncStatus}</span></td>
          <td>{row.syncedAt ? new Date(row.syncedAt).toLocaleString() : '-'}</td>
          <td>{money(row.total)}</td>
          <td>{money(row.balance)}</td>
          <td>{row.issues || row.message || '-'}</td>
          <td><div className="row-actions">
            {row.syncStatus === 'Sync error' && <button className="small" onClick={() => requeue(row)}>Retry</button>}
            {row.syncStatus === 'Synced to main app' && <button className="small secondary" onClick={() => requeue(row)}>Requeue</button>}
            {!['Ignored', 'Synced to main app'].includes(row.syncStatus) && <button className="small secondary" onClick={() => ignore(row)}>Ignore</button>}
          </div></td>
        </tr>)}</tbody>
      </table>
      {!rows.length && <div className="empty">No invoices have been created yet.</div>}
    </div>
  </>;
}
