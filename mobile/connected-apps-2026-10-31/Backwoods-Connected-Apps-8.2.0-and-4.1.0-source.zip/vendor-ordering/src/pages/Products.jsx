import { isNativeApp, showMobilePrintPreview } from '../lib/mobile';
import { useMemo, useState } from 'react';
import { Download, Image as ImageIcon, ListPlus, Plus, Printer, Upload } from 'lucide-react';
import Modal from '../components/Modal';
import BarcodeScanner from '../components/BarcodeScanner';
import CatalogPhoto from '../components/CatalogPhoto';
import { makeId, money, now } from '../lib/helpers';
import { parseBool, parseNumber, rowsFromCsv } from '../lib/csv';
import {
  availableUnits,
  catalogDescription,
  catalogExportRows,
  catalogNumberFields,
  catalogPhoto,
  catalogSearchText,
  downloadBlob,
  downloadCatalogCsv,
  imageFileToCatalogPhoto,
  isCatalogVisible
} from '../lib/catalog';

const blank = {
  sku: '',
  barcode: '',
  name: '',
  category: 'Coffee',
  subcategory: 'Bagged Coffee',
  unit: 'each',
  caseQty: 1,
  price: 0,
  cost: 0,
  onHand: 0,
  reserved: 0,
  damagedStock: 0,
  expiredStock: 0,
  quarantineStock: 0,
  location: '',
  reorderLevel: 10,
  catalogDescription: '',
  catalogVisible: true,
  featured: false,
  photoDataUrl: '',
  photoName: '',
  photoUpdatedAt: '',
};

const numberFields = catalogNumberFields;
const booleanFields = ['catalogVisible', 'featured'];
const hiddenFormFields = ['photoDataUrl', 'photoName', 'photoUpdatedAt'];
const fieldLabels = {
  sku: 'SKU',
  barcode: 'UPC / barcode',
  name: 'Product name',
  category: 'Category',
  subcategory: 'Subcategory',
  unit: 'Unit',
  caseQty: 'Case quantity',
  price: 'Wholesale price',
  cost: 'Cost',
  onHand: 'Sellable on hand',
  reserved: 'Reserved',
  damagedStock: 'Damaged stock',
  expiredStock: 'Expired stock',
  quarantineStock: 'Quarantine stock',
  location: 'Warehouse location',
  reorderLevel: 'Reorder level',
  catalogDescription: 'Catalog description',
  catalogVisible: 'Show in live catalog',
  featured: 'Feature in catalog',
};

const bulkBlank = {
  productLine: '',
  namePattern: '{line} - {flavor}',
  skuPrefix: '',
  category: 'Beverage',
  subcategory: 'Glass Bottle',
  unit: 'bottle',
  caseQty: 24,
  price: 0,
  cost: 0,
  onHand: 0,
  location: '',
  reorderLevel: 10,
  flavors: 'Cola\nDiet Cola\nRoot Beer\nOrange\nGrape\nLemon Lime',
  barcodes: '',
};

const bulkNumberFields = ['caseQty', 'price', 'cost', 'onHand', 'reorderLevel'];
const parseList = value => String(value || '').split(/\r?\n|,/).map(item => item.trim()).filter(Boolean);
const skuPart = value => String(value || '').trim().toUpperCase().replace(/[^A-Z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'ITEM';
const todayStamp = () => new Date().toISOString().slice(0, 10);
const escapeHtml = value => String(value ?? '').replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char]));
const fieldValue = (row, names, fallback = '') => {
  for (const name of names) {
    if (row[name] != null && String(row[name]).trim() !== '') return row[name];
  }
  return fallback;
};
const variantName = (pattern, line, flavor) => String(pattern || '{line} - {flavor}')
  .replaceAll('{line}', line)
  .replaceAll('{flavor}', flavor)
  .replace(/\s+/g, ' ')
  .trim();

function uniqueSku(base, used) {
  let sku = base || 'ITEM';
  let count = 2;
  while (used.has(sku.toLowerCase())) {
    sku = `${base}-${count}`;
    count += 1;
  }
  used.add(sku.toLowerCase());
  return sku;
}

function buildBulkRows(form, products = [], withIds = false) {
  const line = String(form.productLine || '').trim();
  const flavors = parseList(form.flavors);
  const barcodes = parseList(form.barcodes);
  const prefix = skuPart(form.skuPrefix || line);
  const used = new Set((products || []).map(product => String(product.sku || '').toLowerCase()).filter(Boolean));

  return flavors.map((flavor, index) => {
    const baseSku = `${prefix}-${skuPart(flavor)}`;
    return {
      ...blank,
      id: withIds ? makeId('p') : `${baseSku}-${index}`,
      sku: uniqueSku(baseSku, used),
      barcode: barcodes[index] || '',
      name: variantName(form.namePattern, line, flavor),
      category: form.category || 'Beverage',
      subcategory: form.subcategory || 'Glass Bottle',
      unit: form.unit || 'bottle',
      caseQty: Number(form.caseQty || 0),
      price: Number(form.price || 0),
      cost: Number(form.cost || 0),
      onHand: Number(form.onHand || 0),
      reserved: 0,
      damagedStock: 0,
      expiredStock: 0,
      quarantineStock: 0,
      location: form.location || '',
      reorderLevel: Number(form.reorderLevel || 0),
    };
  }).filter(product => product.name && product.sku);
}

function normalizeImportedProduct(raw = {}, fallbackProducts = []) {
  const existing = (fallbackProducts || []).find(product =>
    (fieldValue(raw, ['id']) && product.id === fieldValue(raw, ['id'])) ||
    (fieldValue(raw, ['sku']) && String(product.sku || '').toLowerCase() === String(fieldValue(raw, ['sku'])).toLowerCase())
  );
  const normalized = {
    ...existing,
    id: fieldValue(raw, ['id'], existing?.id || ''),
    sku: String(fieldValue(raw, ['sku'], existing?.sku || '')).trim(),
    barcode: String(fieldValue(raw, ['barcode', 'upc'], existing?.barcode || '')).trim(),
    name: String(fieldValue(raw, ['name', 'product'], existing?.name || '')).trim(),
    category: String(fieldValue(raw, ['category'], existing?.category || 'Coffee')).trim(),
    subcategory: String(fieldValue(raw, ['subcategory', 'subCategory'], existing?.subcategory || 'Bagged Coffee')).trim(),
    unit: String(fieldValue(raw, ['unit'], existing?.unit || 'each')).trim(),
    location: String(fieldValue(raw, ['location'], existing?.location || '')).trim(),
    catalogDescription: String(fieldValue(raw, ['catalogDescription', 'catalogdescription', 'description'], existing?.catalogDescription || existing?.description || '')).trim(),
    catalogVisible: fieldValue(raw, ['catalogVisible', 'catalogvisible'], '') === '' ? existing?.catalogVisible !== false : parseBool(fieldValue(raw, ['catalogVisible', 'catalogvisible'])),
    featured: fieldValue(raw, ['featured'], '') === '' ? Boolean(existing?.featured) : parseBool(fieldValue(raw, ['featured'])),
    photoDataUrl: fieldValue(raw, ['photoDataUrl', 'photodataurl', 'imageDataUrl', 'imagedataurl'], existing?.photoDataUrl || ''),
    photoName: fieldValue(raw, ['photoName', 'photoname'], existing?.photoName || ''),
    photoUpdatedAt: fieldValue(raw, ['photoUpdatedAt', 'photoupdatedat'], existing?.photoUpdatedAt || '')
  };
  numberFields.forEach(key => {
    normalized[key] = parseNumber(fieldValue(raw, [key, key.toLowerCase()]), Number(existing?.[key] ?? blank[key] ?? 0));
  });
  return normalized;
}

function productPrintCard(product) {
  const photo = catalogPhoto(product);
  const description = catalogDescription(product);
  const available = availableUnits(product);
  return `<article class="catalog-print-card">
    ${photo ? `<img src="${escapeHtml(photo)}" alt="${escapeHtml(product.name)}">` : `<div class="catalog-print-placeholder">${escapeHtml(product.name || product.sku || 'Product')}</div>`}
    <div>
      <h2>${escapeHtml(product.name)}</h2>
      <p class="sku">${escapeHtml(product.sku)}${product.barcode ? ` / UPC ${escapeHtml(product.barcode)}` : ''}</p>
      <p>${escapeHtml(product.category || 'Other')} / ${escapeHtml(product.subcategory || 'Other')}</p>
      ${description ? `<p class="desc">${escapeHtml(description)}</p>` : ''}
      <div class="catalog-print-bottom"><strong>${money(product.price)}</strong><span>${available} available</span></div>
    </div>
  </article>`;
}

export default function Products({ data, update }) {
  const [open, setOpen] = useState(false);
  const [bulkOpen, setBulkOpen] = useState(false);
  const [bulkForm, setBulkForm] = useState(bulkBlank);
  const [form, setForm] = useState(blank);
  const [editing, setEditing] = useState(null);
  const [search, setSearch] = useState('');
  const [message, setMessage] = useState('');

  const edit = product => {
    setEditing(product.id);
    setForm({ ...blank, ...product });
    setOpen(true);
  };

  const filtered = useMemo(() => (data.products || [])
    .filter(product => catalogSearchText(product).includes(search.toLowerCase()))
    .sort((a, b) => a.name.localeCompare(b.name)), [data.products, search]);

  const liveCatalogProducts = useMemo(() => filtered
    .filter(isCatalogVisible)
    .sort((a, b) => Number(b.featured) - Number(a.featured) || String(a.category || '').localeCompare(String(b.category || '')) || a.name.localeCompare(b.name)),
  [filtered]);

  const movementRows = useMemo(() => (data.inventoryMovements || [])
    .slice()
    .sort((a, b) => String(b.createdAt || '').localeCompare(String(a.createdAt || '')))
    .slice(0, 80)
    .map(movement => {
      const product = (data.products || []).find(p => p.id === movement.productId);
      return {
        ...movement,
        productName: product?.name || movement.productId || '',
        sku: product?.sku || '',
      };
    }), [data.inventoryMovements, data.products]);

  const bulkPreview = useMemo(() => buildBulkRows(bulkForm, data.products, false), [bulkForm, data.products]);
  const formFields = Object.keys(blank).filter(key => !hiddenFormFields.includes(key));

  const save = () => {
    update(d => {
      const product = {
        ...form,
        id: editing || makeId('p'),
        catalogVisible: form.catalogVisible !== false,
        featured: Boolean(form.featured),
        ...Object.fromEntries(numberFields.map(key => [key, Number(form[key] || 0)])),
      };
      const old = (d.products || []).find(p => p.id === editing);
      const delta = old ? Number(product.onHand) - Number(old.onHand || 0) : Number(product.onHand || 0);
      const movement = delta !== 0 ? {
        id: makeId('mov'),
        productId: product.id,
        type: old ? 'adjustment' : 'opening_balance',
        quantity: delta,
        unitCost: Number(product.cost || 0), accountingCostCaptured: true,
        reference: product.sku,
        note: old ? 'Manual sellable inventory adjustment' : 'Opening sellable inventory balance',
        createdAt: now(),
      } : null;
      return {
        ...d,
        company: { ...d.company, catalogUpdatedAt: now() },
        products: editing ? (d.products || []).map(p => p.id === editing ? product : p) : [...(d.products || []), product],
        inventoryMovements: movement ? [...(d.inventoryMovements || []), movement] : (d.inventoryMovements || []),
      };
    });
    setOpen(false);
    setEditing(null);
    setForm(blank);
    setMessage(`Saved ${form.name || 'product'} to the live catalog.`);
  };

  const startBulk = () => {
    setBulkForm(bulkBlank);
    setBulkOpen(true);
  };

  const saveBulk = () => {
    update(d => {
      const products = buildBulkRows(bulkForm, d.products || [], true);
      const movements = products
        .filter(product => Number(product.onHand || 0) !== 0)
        .map(product => ({
          id: makeId('mov'),
          productId: product.id,
          type: 'bulk_opening_balance',
          quantity: Number(product.onHand || 0),
          unitCost: Number(product.cost || 0), accountingCostCaptured: true,
          reference: product.sku,
          note: `Bulk product setup: ${product.category} / ${product.subcategory}`,
          createdAt: now(),
        }));
      return {
        ...d,
        company: { ...d.company, catalogUpdatedAt: now() },
        products: [...(d.products || []), ...products],
        inventoryMovements: movements.length ? [...(d.inventoryMovements || []), ...movements] : (d.inventoryMovements || []),
      };
    });
    setBulkOpen(false);
    setBulkForm(bulkBlank);
    setMessage(`Created ${bulkPreview.length} live catalog product${bulkPreview.length === 1 ? '' : 's'}.`);
  };

  const uploadPhoto = async event => {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;
    try {
      const photo = await imageFileToCatalogPhoto(file);
      setForm(current => ({
        ...current,
        photoDataUrl: photo.dataUrl,
        photoName: photo.name,
        photoUpdatedAt: photo.updatedAt
      }));
      setMessage(`Photo ready: ${photo.name}`);
    } catch (error) {
      alert(error.message || 'Could not upload that photo.');
    }
  };

  const clearPhoto = () => setForm(current => ({ ...current, photoDataUrl: '', photoName: '', photoUpdatedAt: '' }));

  const downloadFullCatalog = async () => {
    const payload = {
      schemaVersion: 1,
      app: 'Backwoods Vendor Ordering',
      type: 'live-product-catalog',
      exportedAt: now(),
      company: {
        name: data.company?.name || '',
        phone: data.company?.phone || '',
        email: data.company?.email || '',
        website: data.company?.website || ''
      },
      products: liveCatalogProducts.map(product => ({
        ...product,
        available: availableUnits(product),
        catalogDescription: catalogDescription(product),
        catalogVisible: isCatalogVisible(product),
        hasPhoto: Boolean(catalogPhoto(product))
      }))
    };
    try {
      const result = await downloadBlob(`backwoods-live-product-catalog-${todayStamp()}.json`, JSON.stringify(payload, null, 2), 'application/json;charset=utf-8', 'Save full catalog JSON');
      if (!result?.canceled) setMessage(result?.filePath ? `Saved full catalog to ${result.filePath}.` : 'Downloaded full catalog JSON with photos.');
    } catch (error) {
      alert(error.message || 'Could not save the catalog.');
    }
  };

  const downloadPriceSheet = async () => {
    try {
      const result = await downloadCatalogCsv(`backwoods-product-price-sheet-${todayStamp()}.csv`, catalogExportRows(liveCatalogProducts));
      if (!result?.canceled) setMessage(result?.filePath ? `Saved price sheet to ${result.filePath}.` : 'Downloaded catalog price sheet CSV.');
    } catch (error) {
      alert(error.message || 'Could not save the price sheet.');
    }
  };

  const printCatalog = () => {
    const cards = liveCatalogProducts.map(productPrintCard).join('');
    const html = `<!doctype html><html><head><title>${escapeHtml(data.company?.name || 'Backwoods Brew')} Product Catalog</title><style>
      body{font-family:Arial,sans-serif;margin:28px;color:#17201b;background:#fff}
      header{display:flex;justify-content:space-between;gap:24px;border-bottom:2px solid #17201b;padding-bottom:14px;margin-bottom:18px}
      h1{margin:0;font-size:28px} header p{margin:4px 0;color:#566258}
      .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:14px}
      .catalog-print-card{border:1px solid #d8ded8;border-radius:8px;overflow:hidden;break-inside:avoid;background:#fff}
      .catalog-print-card img,.catalog-print-placeholder{width:100%;height:170px;object-fit:cover;background:#eef3ef;display:grid;place-items:center;font-weight:800;color:#58665d}
      .catalog-print-card div{padding:12px}.catalog-print-card h2{font-size:18px;margin:0 0 6px}.sku,.desc{color:#5f695f}.desc{line-height:1.35}.catalog-print-bottom{display:flex;justify-content:space-between;gap:10px;border-top:1px solid #edf0ed;margin-top:10px;padding-top:10px!important}.catalog-print-bottom strong{font-size:20px}.catalog-print-bottom span{color:#5f695f}
      @media print{body{margin:12mm}.catalog-print-card{page-break-inside:avoid}}
    </style></head><body><header><div><h1>${escapeHtml(data.company?.name || 'Backwoods Brew')} Product Catalog</h1><p>${liveCatalogProducts.length} live item${liveCatalogProducts.length === 1 ? '' : 's'} - exported ${escapeHtml(new Date().toLocaleString())}</p></div><div><p>${escapeHtml(data.company?.phone || '')}</p><p>${escapeHtml(data.company?.email || '')}</p></div></header><main class="grid">${cards || '<p>No live catalog products available.</p>'}</main></body></html>`;
    if (isNativeApp()) return showMobilePrintPreview(html);
    const win = window.open('', '_blank');
    if (!win) return alert('Allow popups to print or save the catalog PDF.');
    win.document.write(html);
    win.document.close();
    win.focus();
    setTimeout(() => win.print(), 250);
  };

  const importCatalog = async event => {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file) return;
    try {
      const text = await file.text();
      const trimmed = text.trim();
      const importedRows = trimmed.startsWith('{') || trimmed.startsWith('[')
        ? (() => {
          const parsed = JSON.parse(trimmed);
          return Array.isArray(parsed) ? parsed : (parsed.products || parsed.catalog || []);
        })()
        : rowsFromCsv(text);
      if (!Array.isArray(importedRows) || !importedRows.length) throw new Error('No catalog products were found in that file.');

      let added = 0;
      let updated = 0;
      let skipped = 0;
      await update(d => {
        const products = [...(d.products || [])];
        const movements = [];
        importedRows.forEach(row => {
          const normalized = normalizeImportedProduct(row, products);
          if (!normalized.sku || !normalized.name) {
            skipped += 1;
            return;
          }
          const existingIndex = products.findIndex(product =>
            (normalized.id && product.id === normalized.id) ||
            String(product.sku || '').toLowerCase() === normalized.sku.toLowerCase()
          );
          const existing = existingIndex >= 0 ? products[existingIndex] : null;
          const product = {
            ...blank,
            ...(existing || {}),
            ...normalized,
            id: existing?.id || normalized.id || makeId('p'),
            updatedAt: now()
          };
          const delta = Number(product.onHand || 0) - Number(existing?.onHand || 0);
          if (delta !== 0) movements.push({
            id: makeId('mov'),
            productId: product.id,
            type: existing ? 'catalog_import_adjustment' : 'catalog_import_opening_balance',
            quantity: delta,
            reference: product.sku,
            note: `Live catalog import from ${file.name}`,
            createdAt: now()
          });
          if (existingIndex >= 0) {
            products[existingIndex] = product;
            updated += 1;
          } else {
            products.push(product);
            added += 1;
          }
        });
        return {
          ...d,
          company: { ...d.company, catalogUpdatedAt: now(), catalogImportedAt: now() },
          products,
          inventoryMovements: movements.length ? [...(d.inventoryMovements || []), ...movements] : (d.inventoryMovements || [])
        };
      });
      setMessage(`Catalog import complete: ${added} added, ${updated} updated${skipped ? `, ${skipped} skipped` : ''}.`);
    } catch (error) {
      alert(error.message || 'Could not import that catalog.');
    }
  };

  const stockStats = (data.products || []).reduce((stats, product) => {
    const available = Number(product.onHand || 0) - Number(product.reserved || 0);
    stats.available += available;
    stats.reserved += Number(product.reserved || 0);
    stats.low += available <= Number(product.reorderLevel || 0) ? 1 : 0;
    stats.nonSellable += Number(product.damagedStock || 0) + Number(product.expiredStock || 0) + Number(product.quarantineStock || 0);
    stats.catalog += isCatalogVisible(product) ? 1 : 0;
    stats.withPhotos += catalogPhoto(product) ? 1 : 0;
    return stats;
  }, { available: 0, reserved: 0, low: 0, nonSellable: 0, catalog: 0, withPhotos: 0 });

  return <>
    <div className="page-head">
      <div><h1>Products & Inventory</h1><p>Track sellable stock, reserved order quantities, return buckets, and inventory movements.</p></div>
      <div className="page-head-actions">
        <button className="secondary" disabled={!liveCatalogProducts.length} onClick={downloadPriceSheet}><Download size={17}/>Price sheet</button>
        <button className="secondary" disabled={!liveCatalogProducts.length} onClick={downloadFullCatalog}><Download size={17}/>Catalog JSON</button>
        <button className="secondary" disabled={!liveCatalogProducts.length} onClick={printCatalog}><Printer size={17}/>Print catalog</button>
        <label className="file-button secondary"><Upload size={17}/>Import catalog<input type="file" accept=".json,.csv,application/json,text/csv" onChange={importCatalog}/></label>
        <button className="secondary" onClick={startBulk}><ListPlus size={17}/>Bulk add flavors</button>
        <button onClick={() => { setForm(blank); setEditing(null); setOpen(true); }}><Plus size={17}/>Add product</button>
      </div>
    </div>
    {message && <div className="notice">{message}</div>}

    <div className="stats report-stats">
      <div className="card"><span>Available units</span><strong>{stockStats.available}</strong></div>
      <div className="card"><span>Reserved units</span><strong>{stockStats.reserved}</strong></div>
      <div className="card"><span>Low-stock items</span><strong>{stockStats.low}</strong></div>
      <div className="card"><span>Live catalog items</span><strong>{stockStats.catalog}</strong></div>
      <div className="card"><span>Catalog photos</span><strong>{stockStats.withPhotos}</strong></div>
      <div className="card"><span>Non-sellable units</span><strong>{stockStats.nonSellable}</strong></div>
    </div>

    <div className="panel toolbar-panel">
      <input className="search-input" value={search} onChange={event => setSearch(event.target.value)} placeholder="Search products, categories, subcategories, SKU, UPC, or location"/>
    </div>

    <div className="panel">
      <div className="panel-title"><div><h2>Live Product Catalog</h2><p>Customer-facing items with clear photos, live prices, availability, and descriptions.</p></div></div>
      <div className="catalog-preview-grid">
        {liveCatalogProducts.slice(0, 12).map(product => <article className="catalog-card" key={product.id}>
          <CatalogPhoto product={product} className="large"/>
          <div className="catalog-card-body">
            <div className="catalog-card-head">
              <div><h3>{product.name}</h3><small>{product.sku}{product.barcode ? ` - UPC ${product.barcode}` : ''}</small></div>
              {product.featured && <span className="catalog-badge">Featured</span>}
            </div>
            <p>{catalogDescription(product) || `${product.category} / ${product.subcategory || 'Other'}`}</p>
            <div className="catalog-card-bottom"><strong>{money(product.price)}</strong><span>{availableUnits(product)} available</span></div>
          </div>
        </article>)}
      </div>
      {!liveCatalogProducts.length && <div className="empty compact">No visible catalog products yet.</div>}
      {liveCatalogProducts.length > 12 && <p className="muted">Showing first 12 of {liveCatalogProducts.length} matching live catalog products.</p>}
    </div>

    <div className="panel table-scroll">
      <table>
        <thead><tr><th>Photo</th><th>SKU / Barcode</th><th>Product</th><th>Category</th><th>Catalog</th><th>Price</th><th>Sellable</th><th>Reserved</th><th>Available</th><th>Returns</th><th></th></tr></thead>
        <tbody>{filtered.map(product => {
          const available = availableUnits(product);
          const returns = Number(product.damagedStock || 0) + Number(product.expiredStock || 0) + Number(product.quarantineStock || 0);
          return <tr key={product.id} className={available <= Number(product.reorderLevel || 0) ? 'low-stock' : ''}>
            <td><CatalogPhoto product={product} className="thumb"/></td>
            <td>{product.sku}<small>{product.barcode || product.sku}</small></td>
            <td><b>{product.name}</b><small>{catalogDescription(product) || 'No catalog description'}</small><small>{product.location || 'No location'} - case {product.caseQty}</small></td>
            <td>{product.category}<small>{product.subcategory || 'Uncategorized'}</small></td>
            <td><span className={`status ${isCatalogVisible(product) ? 'success-status' : 'warning-status'}`}>{isCatalogVisible(product) ? 'Live' : 'Hidden'}</span>{product.featured && <small>Featured</small>}</td>
            <td>{money(product.price)}</td>
            <td>{Number(product.onHand || 0)}</td>
            <td>{Number(product.reserved || 0)}</td>
            <td><b>{available}</b>{available <= Number(product.reorderLevel || 0) && <small>Low stock</small>}</td>
            <td>{returns}<small>D {Number(product.damagedStock || 0)} / E {Number(product.expiredStock || 0)} / Q {Number(product.quarantineStock || 0)}</small></td>
            <td><button className="small" onClick={() => edit(product)}>Edit</button></td>
          </tr>;
        })}</tbody>
      </table>
      {!filtered.length && <div className="empty compact">No products match that search.</div>}
    </div>

    <div className="panel table-scroll">
      <div className="panel-title"><div><h2>Recent inventory movement</h2><p>Purchasing receipts, route deliveries, returns, credits, and manual adjustments.</p></div></div>
      <table>
        <thead><tr><th>Date</th><th>Product</th><th>SKU</th><th>Type</th><th>Qty</th><th>Reference</th><th>Note</th></tr></thead>
        <tbody>{movementRows.map(row => <tr key={row.id}>
          <td>{row.createdAt ? new Date(row.createdAt).toLocaleString() : '-'}</td>
          <td>{row.productName}</td>
          <td>{row.sku}</td>
          <td><span className="status">{row.type || 'movement'}</span></td>
          <td>{Number(row.quantity || 0)}</td>
          <td>{row.reference || '-'}</td>
          <td className="movement-note">{row.note || '-'}</td>
        </tr>)}</tbody>
      </table>
      {!movementRows.length && <div className="empty compact">No inventory movements have been recorded yet.</div>}
    </div>

    {open && <Modal title={editing ? 'Edit product' : 'Add product'} wide onClose={() => setOpen(false)}>
      <div className="catalog-photo-editor">
        <CatalogPhoto product={form} className="editor"/>
        <div>
          <h3><ImageIcon size={18}/> Catalog photo</h3>
          <p>Upload a clear front-facing product photo. The app compresses and saves it with the product catalog.</p>
          <div className="import-actions">
            <label className="file-button"><Upload size={17}/>Upload photo<input type="file" accept="image/png,image/jpeg,image/webp,image/*" onChange={uploadPhoto}/></label>
            {catalogPhoto(form) && <button className="small danger" type="button" onClick={clearPhoto}>Remove photo</button>}
          </div>
          {form.photoName && <small>{form.photoName}{form.photoUpdatedAt ? ` - ${new Date(form.photoUpdatedAt).toLocaleString()}` : ''}</small>}
        </div>
      </div>
      <div className="form-grid">
        {formFields.map(key => key === 'barcode'
          ? <div className="span-2 product-barcode-capture" key={key}>
            <label>{fieldLabels[key] || key}
              <input value={form.barcode} onChange={event => setForm(current => ({ ...current, barcode: event.target.value.trim() }))} placeholder="Scan or type UPC"/>
            </label>
            <BarcodeScanner
              autoFocus={false}
              placeholder="Scan UPC from product"
              onScan={code => setForm(current => ({ ...current, barcode: code.trim() }))}
            />
          </div>
          : key === 'catalogDescription'
            ? <label className="span-2" key={key}>{fieldLabels[key] || key}
              <textarea value={form.catalogDescription || ''} onChange={event => setForm(current => ({ ...current, catalogDescription: event.target.value }))} placeholder="Short customer-facing description, size, roast notes, flavor notes, or pack details"/>
            </label>
            : booleanFields.includes(key)
              ? <label className="toggle" key={key}>
                <input type="checkbox" checked={form[key] !== false} onChange={event => setForm(current => ({ ...current, [key]: event.target.checked }))}/>
                <span>{fieldLabels[key] || key}</span>
              </label>
          : <label key={key}>{fieldLabels[key] || key}
            <input
              type={numberFields.includes(key) ? 'number' : 'text'}
              step={['price', 'cost'].includes(key) ? '0.01' : '1'}
              value={form[key]}
              onChange={event => setForm(current => ({ ...current, [key]: event.target.value }))}
            />
          </label>)}
      </div>
      <div className="actions"><button disabled={!form.sku || !form.name || !form.category || !form.subcategory} onClick={save}>Save product</button></div>
    </Modal>}

    {bulkOpen && <Modal title="Bulk add flavor products" wide onClose={() => setBulkOpen(false)}>
      <div className="bulk-product-summary">
        <strong>{bulkPreview.length}</strong>
        <span>product{bulkPreview.length === 1 ? '' : 's'} ready to create</span>
      </div>
      <div className="form-grid">
        <label>Product line<input value={bulkForm.productLine} onChange={event => setBulkForm(current => ({ ...current, productLine: event.target.value }))} placeholder="Soda"/></label>
        <label>Name pattern<input value={bulkForm.namePattern} onChange={event => setBulkForm(current => ({ ...current, namePattern: event.target.value }))} placeholder="{line} - {flavor}"/></label>
        <label>SKU prefix<input value={bulkForm.skuPrefix} onChange={event => setBulkForm(current => ({ ...current, skuPrefix: event.target.value }))} placeholder="SODA"/></label>
        <label>Category<input value={bulkForm.category} onChange={event => setBulkForm(current => ({ ...current, category: event.target.value }))}/></label>
        <label>Subcategory<input value={bulkForm.subcategory} onChange={event => setBulkForm(current => ({ ...current, subcategory: event.target.value }))}/></label>
        <label>Unit<input value={bulkForm.unit} onChange={event => setBulkForm(current => ({ ...current, unit: event.target.value }))}/></label>
        {bulkNumberFields.map(key => <label key={key}>{fieldLabels[key] || key}
          <input
            type="number"
            step={['price', 'cost'].includes(key) ? '0.01' : '1'}
            value={bulkForm[key]}
            onChange={event => setBulkForm(current => ({ ...current, [key]: event.target.value }))}
          />
        </label>)}
        <label>Warehouse location<input value={bulkForm.location} onChange={event => setBulkForm(current => ({ ...current, location: event.target.value }))} placeholder="Cooler A"/></label>
        <label className="span-2">Flavors<textarea className="bulk-flavor-textarea" value={bulkForm.flavors} onChange={event => setBulkForm(current => ({ ...current, flavors: event.target.value }))} placeholder="One flavor per line"/></label>
        <label className="span-2">UPCs / barcodes<textarea className="bulk-flavor-textarea" value={bulkForm.barcodes} onChange={event => setBulkForm(current => ({ ...current, barcodes: event.target.value }))} placeholder="Optional: one UPC per flavor, in the same order"/></label>
      </div>

      <div className="panel inset bulk-variant-preview">
        <div className="panel-title"><div><h3>Preview</h3><p>Review names, SKUs, category, subcategory, and prices before saving.</p></div></div>
        <div className="table-scroll">
          <table>
            <thead><tr><th>SKU</th><th>Name</th><th>UPC</th><th>Category</th><th>Subcategory</th><th>Price</th><th>Stock</th></tr></thead>
            <tbody>{bulkPreview.map(product => <tr key={product.id}>
              <td><b>{product.sku}</b></td>
              <td>{product.name}</td>
              <td>{product.barcode || '-'}</td>
              <td>{product.category}</td>
              <td>{product.subcategory}</td>
              <td>{money(product.price)}</td>
              <td>{Number(product.onHand || 0)}</td>
            </tr>)}</tbody>
          </table>
          {!bulkPreview.length && <div className="empty compact">Enter a product line and at least one flavor.</div>}
        </div>
      </div>

      <div className="actions">
        <button className="secondary" onClick={() => setBulkOpen(false)}>Cancel</button>
        <button disabled={!bulkForm.productLine.trim() || !bulkPreview.length} onClick={saveBulk}>Create {bulkPreview.length || ''} product{bulkPreview.length === 1 ? '' : 's'}</button>
      </div>
    </Modal>}
  </>;
}
