# Order and Returns Upgrade

This version combines sales and returns on the same worksheet.

## Workflow
1. Choose the store.
2. Search or filter products.
3. Enter the quantity being delivered in **Deliver**.
4. Enter products coming back from the store in **Return**.
5. Select a reason for every return.
6. Submit one combined transaction.

## Invoice
The invoice prints two separate sections:
- Merchandise delivered
- Returns from store

The net invoice is calculated as:

Delivered merchandise - returns - other credits + tax = net invoice total

## Inventory
Outgoing items are reserved and packed normally. When delivery is completed, delivered items reduce inventory and returned items are added back into inventory with a return movement record.
