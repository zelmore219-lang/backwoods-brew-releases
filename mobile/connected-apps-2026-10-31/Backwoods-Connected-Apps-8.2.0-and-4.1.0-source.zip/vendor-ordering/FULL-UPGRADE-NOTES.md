# Backwoods Vendor Ordering 2.0

Added store-specific approved product catalogs, favorites, custom pricing, credit limits and account holds, delivery instructions, salesperson assignment, fast repeat-order and favorites ordering, draft orders, case ordering, a day-based sales route dashboard, route visit statuses, navigation/calling shortcuts, and an operations notifications center. Existing purchasing, receiving, inventory, packing, barcode scanning, labels, delivery proof, invoicing, credits, receivables, reports, backups, audit logs, and diagnostics remain included.
