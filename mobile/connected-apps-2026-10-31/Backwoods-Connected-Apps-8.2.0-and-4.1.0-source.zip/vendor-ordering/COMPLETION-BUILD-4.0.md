# Backwoods Vendor Ordering 4.0 Completion Build

## Completed workflow

Store -> combined order/return -> warehouse packing -> driver delivery -> invoice -> payment -> inventory movement.

## Critical corrections included

- Draft orders no longer reserve inventory.
- Return-only lines no longer reserve inventory.
- Submitting an edited draft now changes it to submitted and reserves only outgoing merchandise.
- Cancelled submitted orders release reserved outgoing inventory.
- Returns support full, partial, or zero customer credit.
- Each return requires a reason and an inventory disposition.
- Sellable returns go back to available stock.
- Damaged returns go to `damagedStock`.
- Expired returns go to `expiredStock`.
- Inspection returns go to `quarantineStock`.
- Invoices show return reason, disposition, credit percentage, and actual credit.
- Delivery completion records separate inventory movements for deliveries and each return condition.

## Required launch test

1. Create a draft with delivered items and confirm product reserved quantity does not change.
2. Submit the draft and confirm only delivered quantities become reserved.
3. Pack the order and record a shortage.
4. Complete a delivery with one sellable return, one damaged return, and one expired return.
5. Confirm the invoice shows delivered merchandise and each return credit correctly.
6. Confirm available stock only increases for the sellable return.
7. Confirm damaged and expired quantities appear in their separate product inventory fields.
8. Record a partial payment and confirm the remaining invoice balance.
9. Test owner, salesperson, packer, driver, and accounting access separately.
10. Create and restore a backup before entering live business data.

## Production note

Run `npm install` and `npm run build` on a computer with reliable npm registry access. The source package is complete, but dependencies could not be installed in the packaging environment because npm installation timed out.
