# Backwoods Vendor Ordering App

## Run locally

1. Install Node.js 20 or newer.
2. Open a terminal in this folder.
3. Run `npm install`.
4. Run `npm run dev`.
5. Open the local URL shown by Vite.

## Included MVP features

- Customer and store records
- Product catalog and inventory
- Vendor order creation
- Packing queue
- Driver delivery workflow
- Payment collection
- Signature capture
- Credits and returns
- Printable invoices and browser PDF download
- Company logo upload
- Local demo storage

## Production next step

Replace `src/lib/store.js` localStorage persistence with Firebase Authentication and Firestore. Keep the same collection groups: users, customers, products, orders, credits, payments, inventoryMovements, and companySettings.

## Firebase login and roles

The app now supports Firebase Email/Password Authentication and Firestore user profiles.

### Test immediately without Firebase

Run `npm run dev`. If no `.env` file is present, the login screen displays demo buttons for Owner, Manager, Salesperson, Packer, Driver, and Accounting.

### Connect Firebase

1. In Firebase Console, open Project settings > Your apps and create/select a Web app.
2. Enable Authentication > Sign-in method > Email/Password.
3. Create a `.env` file in the project root by copying `.env.example`.
4. Replace every placeholder with the values from your Firebase web configuration.
5. Restart `npm run dev` after saving `.env`.
6. Deploy the included `firestore.rules` in Firestore Database > Rules.

### Create the first owner

1. In Firebase Authentication, add the owner's email and password.
2. Copy that user's UID.
3. In Firestore, create a collection named `users`.
4. Create a document whose document ID is the copied UID.
5. Add these fields:

```
name: Zachary Elmore
role: owner
active: true
```

Supported role values are:

- `owner`
- `manager`
- `sales`
- `packer`
- `driver`
- `accounting`
- `pending`

A Firebase account without a matching Firestore user document is assigned `pending` and cannot enter the operating screens.

### Current permission map

- Owner: all modules and settings
- Manager: operations except company settings
- Sales: customers, products, orders, invoices, and credits
- Packer: products and packing
- Driver: deliveries, invoices, and credits
- Accounting: customers, products, invoices, and credits

The business records still use local browser storage in this version. Firebase Authentication and role enforcement are now installed; moving customers, products, orders, and invoices into shared Firestore collections is the next database phase.

## Warehouse packing workflow

The Packing page now supports packer assignment, per-line packed quantities, shortages and reasons, substitution notes, printable packing slips, saved in-progress packing, and completion handoff to the driver queue. When a short shipment is completed, the unfilled quantity is released from reserved inventory. Drivers deduct the packed quantity at delivery rather than the original ordered quantity.

## Driver delivery workflow

The Driver Deliveries page now supports route loading, per-line delivered and refused quantities, customer signatures, payment methods, partial payments, check numbers, credit pickups, delivery notes, inventory deduction, inventory movement history, and final printable invoices. Delivered invoices use actual delivered quantities rather than the original ordered quantities.

## Version 0.6 - Invoices and Accounts Receivable

Added:
- Accounts Receivable dashboard with outstanding and overdue balances
- Office payment entry with check/reference numbers and notes
- Customer statement printing/PDF
- Invoice search and paid/partial/unpaid filters
- Invoice line, price, and tax editing with a required audit reason
- Payment history on invoices
- Invoice voiding controls
- Pending credit requests with manager approval or rejection

## Version 0.7 reporting module

The Reports page is available to owner, manager, and accounting roles. It includes sales by month, product and customer performance, driver settlements, inventory health, credits and returns, CSV downloads, and print-friendly reports.


## Version 0.8 - Route planning

- Create delivery routes by date
- Assign drivers
- Add packed orders as stops
- Reorder stops
- Print route manifests
- Push route details to driver orders
- Create driver assignment notifications
- Store routes and notifications in Firestore

## Customer portal (v0.9)
Customer accounts can now view their own orders, delivery status, invoices, balances and credits, and submit repeat orders. Link a Firebase user profile to a store by setting `role: "customer"`, `active: true`, and `customerId: "<customer document id>"` in the `users` collection.

## Version 1.0 settings and audit update

This release adds expanded company and invoice settings, notification preferences, print controls, and an owner/manager audit log with CSV export. Publish the included `firestore.rules` after upgrading so the new `auditLogs` collection is protected.


## Field operations update (v1.3)

This version adds:

- USB/Bluetooth keyboard-wedge barcode scanning and supported-browser camera scanning
- Barcode-based packing quantity verification
- CODE128 product labels and shipping carton labels
- Driver offline route download plus Firestore offline write synchronization
- Daily owner cloud snapshots in the `cloudBackups` Firestore collection
- Configurable customer payment links
- Compressed damaged-return photo capture
- Required GPS proof of delivery

### Barcode setup
Enter each product's UPC/EAN/Code 128 value in the product `barcode` field. Most USB and Bluetooth scanners work automatically because they type the code and press Enter. Camera scanning requires a Chromium browser/device that supports `BarcodeDetector`.

### Payment links
Under Settings, enter the base URL supplied by your payment provider. The app appends `invoice`, `amount`, and `customer` query parameters. The provider must support receiving or mapping those values.

### Automatic backups
An owner session creates one Firestore snapshot per day while the app is opened. Use Backups to create, download, and restore snapshots. This is an application-level backup and is not a replacement for Google Cloud's managed Firestore export service for large production databases.

## Supplier purchasing and receiving (v1.4)

New modules:

- **Suppliers**: contacts, account numbers, terms, minimum orders, lead times, status, and spend history.
- **Purchasing**: draft/submit/cancel purchase orders, low-stock reorder suggestions, freight and tax, lot/expiration fields, and printable POs.
- **Receiving**: barcode scan or manual receiving, partial shipments, damaged/missing quantities, backorders, receiving notes, and receipt history.
- **Inventory integration**: good received quantities increase on-hand stock, create inventory movements, record the most recent supplier, and update product cost.

After replacing the previous project, preserve your `.env` file, publish the included `firestore.rules`, and run:

```powershell
npm install
npm run dev
```


## Launch Center (v1.5)

The Launch Center adds the final operational controls needed for a pilot rollout:

- Accounts-receivable aging buckets
- Driver collection settlement records
- Standing/recurring order templates
- Customer and product CSV import/export
- Automatic inactivity sign-out (default: 60 minutes)

Open **Launch Center** while signed in as owner, manager, or accounting. Set `VITE_SESSION_TIMEOUT_MINUTES` in `.env` to change the inactivity timeout.

### CSV import format

Use the exported template with these columns:

```text
type,name,sku,email,phone,address,price,cost,onHand,terms
```

The `type` value must be `customer` or `product`. Imports add records and do not overwrite existing records.


## Vendor Firestore isolation
This build uses vendor-prefixed collections only. Merge `firestore-vendor-rules-snippet.rules` into the existing Firestore rules; do not replace the main application rules. See `MERGE-FIRESTORE-RULES.md`.
