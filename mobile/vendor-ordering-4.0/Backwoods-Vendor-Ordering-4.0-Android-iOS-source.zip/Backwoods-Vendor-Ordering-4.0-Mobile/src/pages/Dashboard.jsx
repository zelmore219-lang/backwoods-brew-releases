import { money, calcOrder } from '../lib/helpers';
export default function Dashboard({data}){
 const open=data.orders.filter(o=>!['completed','cancelled'].includes(o.status));
 const packed=data.orders.filter(o=>o.status==='packed').length;
 const delivery=data.orders.filter(o=>o.status==='out_for_delivery').length;
 const receivable=data.orders.reduce((s,o)=>s+calcOrder(o).balance,0);
 return <><div className="page-head"><div><h1>Operations Dashboard</h1><p>Live view of sales, warehouse, deliveries, and collections.</p></div></div>
 <div className="stats"><div className="card"><span>Open orders</span><strong>{open.length}</strong></div><div className="card"><span>Ready to deliver</span><strong>{packed}</strong></div><div className="card"><span>Out for delivery</span><strong>{delivery}</strong></div><div className="card"><span>Receivables</span><strong>{money(receivable)}</strong></div></div>
 <div className="panel"><h3>Low stock</h3><table><thead><tr><th>Product</th><th>Available</th><th>Location</th></tr></thead><tbody>{data.products.filter(p=>p.onHand-p.reserved<30).map(p=><tr key={p.id}><td>{p.name}</td><td>{p.onHand-p.reserved}</td><td>{p.location}</td></tr>)}</tbody></table></div></>
}
