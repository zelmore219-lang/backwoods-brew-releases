import { useMemo, useState } from 'react';
import { calcOrder, money } from '../lib/helpers';

const day = value => value ? new Date(value).toLocaleDateString('en-US') : '—';
const monthKey = value => {
  const d = value ? new Date(value) : new Date();
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`;
};
const downloadCsv = (name, rows) => {
  if (!rows.length) return;
  const keys = Object.keys(rows[0]);
  const csv = [keys.join(','), ...rows.map(row => keys.map(k => `"${String(row[k] ?? '').replaceAll('"','""')}"`).join(','))].join('\n');
  const blob = new Blob([csv], { type:'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url; link.download = name; link.click(); URL.revokeObjectURL(url);
};

export default function Reports({ data }) {
  const [range, setRange] = useState('all');
  const [tab, setTab] = useState('sales');
  const now = new Date();
  const filteredOrders = useMemo(() => data.orders.filter(order => {
    if (range === 'all') return true;
    const value = new Date(order.deliveredAt || order.createdAt || 0);
    const days = Number(range);
    return value >= new Date(now.getTime() - days * 86400000);
  }), [data.orders, range]);

  const completed = filteredOrders.filter(o => ['completed','delivered','payment_pending'].includes(o.status));
  const salesTotal = completed.reduce((s,o)=>s+calcOrder(o).total,0);
  const collected = filteredOrders.reduce((s,o)=>s+(o.payments||[]).reduce((a,p)=>a+Number(p.amount||0),0),0);
  const outstanding = data.orders.reduce((s,o)=>s+calcOrder(o).balance,0);
  const creditTotal = data.credits.filter(c=>['approved','picked_up'].includes(c.status)).reduce((s,c)=>s+Number(c.amount||0),0);
  const profit = completed.reduce((sum,order)=>sum+order.items.reduce((s,item)=>{
    const product=data.products.find(p=>p.id===item.productId);
    const qty=Number(item.invoiceQty ?? item.deliveredQty ?? item.qty ?? 0);
    return s + qty * (Number(item.price||0)-Number(product?.cost||0));
  },0),0);

  const productRows = useMemo(() => data.products.map(product => {
    let qty=0,revenue=0;
    completed.forEach(order => order.items.filter(i=>i.productId===product.id).forEach(i=>{
      const q=Number(i.invoiceQty ?? i.deliveredQty ?? i.qty ?? 0); qty+=q; revenue+=q*Number(i.price||0);
    }));
    return { product:product.name, sku:product.sku, qty, revenue, profit:qty*(Number(product.price||0)-Number(product.cost||0)), available:Number(product.onHand||0)-Number(product.reserved||0) };
  }).sort((a,b)=>b.revenue-a.revenue), [completed,data.products]);

  const customerRows = useMemo(() => data.customers.map(customer => {
    const orders=completed.filter(o=>o.customerId===customer.id);
    return { customer:customer.name, orders:orders.length, sales:orders.reduce((s,o)=>s+calcOrder(o).total,0), balance:data.orders.filter(o=>o.customerId===customer.id).reduce((s,o)=>s+calcOrder(o).balance,0) };
  }).sort((a,b)=>b.sales-a.sales), [completed,data.customers,data.orders]);

  const driverRows = useMemo(() => {
    const map=new Map();
    filteredOrders.forEach(order=>{
      if(!order.driver) return;
      const row=map.get(order.driver)||{driver:order.driver,deliveries:0,collected:0,cash:0,checks:0,cards:0,ach:0};
      row.deliveries += order.deliveredAt ? 1 : 0;
      (order.payments||[]).forEach(p=>{const amount=Number(p.amount||0);row.collected+=amount;const m=(p.method||'').toLowerCase();if(m==='cash')row.cash+=amount;else if(m==='check')row.checks+=amount;else if(m.includes('card'))row.cards+=amount;else if(m==='ach')row.ach+=amount;});
      map.set(order.driver,row);
    });
    return [...map.values()].sort((a,b)=>b.collected-a.collected);
  }, [filteredOrders]);

  const inventoryRows = data.products.map(p=>({product:p.name,sku:p.sku,onHand:Number(p.onHand||0),reserved:Number(p.reserved||0),available:Number(p.onHand||0)-Number(p.reserved||0),reorder:Number(p.reorderLevel||30),location:p.location||''})).sort((a,b)=>a.available-b.available);
  const creditRows = data.credits.slice().reverse().map(c=>({date:day(c.createdAt),invoice:data.orders.find(o=>o.id===c.orderId)?.invoiceNumber||'',customer:data.customers.find(x=>x.id===data.orders.find(o=>o.id===c.orderId)?.customerId)?.name||'',product:data.products.find(p=>p.id===c.productId)?.name||'',reason:c.reason,status:c.status,amount:Number(c.amount||0)}));
  const monthly = Object.values(completed.reduce((map,o)=>{const key=monthKey(o.deliveredAt||o.createdAt);map[key] ||= {month:key,orders:0,sales:0,collected:0};map[key].orders++;map[key].sales+=calcOrder(o).total;map[key].collected+=(o.payments||[]).reduce((s,p)=>s+Number(p.amount||0),0);return map;},{})).sort((a,b)=>b.month.localeCompare(a.month));

  const print = () => window.print();
  const tabs=[['sales','Sales'],['products','Products'],['customers','Customers'],['drivers','Driver settlements'],['inventory','Inventory'],['credits','Credits & returns']];

  return <>
    <div className="page-head"><div><h1>Reports & Management</h1><p>Review sales, margins, collections, drivers, inventory, credits, and customer performance.</p></div><div className="actions no-print"><select value={range} onChange={e=>setRange(e.target.value)}><option value="all">All time</option><option value="7">Last 7 days</option><option value="30">Last 30 days</option><option value="90">Last 90 days</option><option value="365">Last 12 months</option></select><button className="secondary" onClick={print}>Print report</button></div></div>
    <div className="stats report-stats"><div className="card"><span>Sales</span><strong>{money(salesTotal)}</strong></div><div className="card"><span>Collected</span><strong>{money(collected)}</strong></div><div className="card"><span>Gross profit estimate</span><strong>{money(profit)}</strong></div><div className="card"><span>Outstanding A/R</span><strong>{money(outstanding)}</strong></div><div className="card"><span>Approved credits</span><strong>{money(creditTotal)}</strong></div></div>
    <div className="report-tabs no-print">{tabs.map(([id,label])=><button key={id} className={tab===id?'active secondary':'secondary'} onClick={()=>setTab(id)}>{label}</button>)}</div>

    {tab==='sales' && <div className="panel"><div className="panel-title"><div><h2>Sales by month</h2><p>Delivered invoice totals and recorded collections.</p></div><button className="small secondary no-print" onClick={()=>downloadCsv('sales-by-month.csv',monthly)}>Download CSV</button></div><table><thead><tr><th>Month</th><th>Orders</th><th>Sales</th><th>Collected</th><th>Collection rate</th></tr></thead><tbody>{monthly.map(r=><tr key={r.month}><td>{r.month}</td><td>{r.orders}</td><td>{money(r.sales)}</td><td>{money(r.collected)}</td><td>{r.sales?`${Math.round(r.collected/r.sales*100)}%`:'0%'}</td></tr>)}</tbody></table></div>}

    {tab==='products' && <div className="panel"><div className="panel-title"><div><h2>Product performance</h2><p>Units, revenue, estimated gross profit, and current availability.</p></div><button className="small secondary no-print" onClick={()=>downloadCsv('product-performance.csv',productRows)}>Download CSV</button></div><table><thead><tr><th>Product</th><th>SKU</th><th>Units sold</th><th>Revenue</th><th>Est. profit</th><th>Available</th></tr></thead><tbody>{productRows.map(r=><tr key={r.sku}><td>{r.product}</td><td>{r.sku}</td><td>{r.qty}</td><td>{money(r.revenue)}</td><td>{money(r.profit)}</td><td>{r.available}</td></tr>)}</tbody></table></div>}

    {tab==='customers' && <div className="panel"><div className="panel-title"><div><h2>Customer performance</h2><p>Sales and current unpaid balances by account.</p></div><button className="small secondary no-print" onClick={()=>downloadCsv('customer-performance.csv',customerRows)}>Download CSV</button></div><table><thead><tr><th>Customer</th><th>Orders</th><th>Sales</th><th>Open balance</th></tr></thead><tbody>{customerRows.map(r=><tr key={r.customer}><td>{r.customer}</td><td>{r.orders}</td><td>{money(r.sales)}</td><td className={r.balance>0?'amount-due':''}>{money(r.balance)}</td></tr>)}</tbody></table></div>}

    {tab==='drivers' && <div className="panel"><div className="panel-title"><div><h2>Driver settlement</h2><p>Deliveries and payment amounts recorded by each driver.</p></div><button className="small secondary no-print" onClick={()=>downloadCsv('driver-settlement.csv',driverRows)}>Download CSV</button></div><table><thead><tr><th>Driver</th><th>Deliveries</th><th>Total collected</th><th>Cash</th><th>Checks</th><th>Cards</th><th>ACH</th></tr></thead><tbody>{driverRows.map(r=><tr key={r.driver}><td>{r.driver}</td><td>{r.deliveries}</td><td>{money(r.collected)}</td><td>{money(r.cash)}</td><td>{money(r.checks)}</td><td>{money(r.cards)}</td><td>{money(r.ach)}</td></tr>)}</tbody></table>{!driverRows.length&&<div className="empty">No driver collections are recorded for this period.</div>}</div>}

    {tab==='inventory' && <div className="panel"><div className="panel-title"><div><h2>Inventory health</h2><p>On-hand, reserved, available, and reorder quantities.</p></div><button className="small secondary no-print" onClick={()=>downloadCsv('inventory-health.csv',inventoryRows)}>Download CSV</button></div><table><thead><tr><th>Product</th><th>SKU</th><th>On hand</th><th>Reserved</th><th>Available</th><th>Reorder at</th><th>Location</th></tr></thead><tbody>{inventoryRows.map(r=><tr key={r.sku} className={r.available<=r.reorder?'short-line':''}><td>{r.product}</td><td>{r.sku}</td><td>{r.onHand}</td><td>{r.reserved}</td><td><b>{r.available}</b></td><td>{r.reorder}</td><td>{r.location}</td></tr>)}</tbody></table></div>}

    {tab==='credits' && <div className="panel"><div className="panel-title"><div><h2>Credits and returns</h2><p>Credit value, reason, pickup status, and affected invoice.</p></div><button className="small secondary no-print" onClick={()=>downloadCsv('credits-and-returns.csv',creditRows)}>Download CSV</button></div><table><thead><tr><th>Date</th><th>Invoice</th><th>Customer</th><th>Product</th><th>Reason</th><th>Status</th><th>Amount</th></tr></thead><tbody>{creditRows.map((r,i)=><tr key={`${r.invoice}-${i}`}><td>{r.date}</td><td>{r.invoice}</td><td>{r.customer}</td><td>{r.product}</td><td>{r.reason}</td><td><span className="status">{r.status}</span></td><td>{money(r.amount)}</td></tr>)}</tbody></table></div>}
  </>;
}
