import { useMemo, useState } from 'react';
import Modal from '../components/Modal';
import { makeId } from '../lib/helpers';
import { useAuth } from '../auth/AuthContext';

const roles=['owner','manager','sales','packer','driver','accounting','pending'];
const blank={uid:'',name:'',email:'',role:'pending',active:true};

export default function Users({data,update,firebaseEnabled}){
  const {user:me}=useAuth();
  const [open,setOpen]=useState(false); const [editing,setEditing]=useState(null); const [f,setF]=useState(blank); const [message,setMessage]=useState('');
  const users=useMemo(()=>[...data.users].sort((a,b)=>(a.name||'').localeCompare(b.name||'')),[data.users]);
  const startAdd=()=>{setEditing(null);setF(blank);setMessage('');setOpen(true)};
  const startEdit=u=>{setEditing(u.id);setF({uid:u.uid||u.id,name:u.name||'',email:u.email||'',role:u.role||'pending',active:u.active!==false});setMessage('');setOpen(true)};
  const save=()=>{
    const id=(f.uid||editing||makeId('user')).trim();
    if(!id||!f.name.trim()){setMessage('Name and Firebase UID are required.');return;}
    update(d=>({...d,users:[...d.users.filter(u=>u.id!==editing&&u.id!==id),{id,uid:id,name:f.name.trim(),email:f.email.trim(),role:f.role,active:Boolean(f.active)}]}));
    setOpen(false);
  };
  const toggle=u=>update(d=>({...d,users:d.users.map(x=>x.id===u.id?{...x,active:x.id===me.uid?true:x.active===false}:x)}));
  return <>
    <div className="page-head"><div><h1>User Management</h1><p>Create employee profiles, assign job roles, and disable access.</p></div><button onClick={startAdd}>Add user profile</button></div>
    {!firebaseEnabled&&<div className="notice">Demo mode: profiles are stored only on this computer until Firebase is connected.</div>}
    <div className="panel"><table><thead><tr><th>Employee</th><th>Role</th><th>Status</th><th>Firebase UID</th><th></th></tr></thead><tbody>
      {users.length===0&&<tr><td colSpan="5">No employee profiles yet.</td></tr>}
      {users.map(u=><tr key={u.id}><td><b>{u.name}</b><small>{u.email||'No email entered'}</small></td><td><span className="status">{u.role}</span></td><td>{u.active===false?'Disabled':'Active'}</td><td><code>{u.uid||u.id}</code></td><td><div className="row-actions"><button className="small secondary" onClick={()=>startEdit(u)}>Edit</button><button className="small danger" disabled={u.id===me.uid} onClick={()=>toggle(u)}>{u.active===false?'Enable':'Disable'}</button></div></td></tr>)}
    </tbody></table></div>
    <div className="panel"><h3>How employee sign-in works</h3><p>Create the employee in Firebase Authentication using username@backwoodsbrew-e3584-d52a3.firebaseapp.com, then paste that account’s UID here. Employees sign in using only the username portion. This profile controls what the employee can access after signing in.</p></div>
    {open&&<Modal title={editing?'Edit user profile':'Add user profile'} onClose={()=>setOpen(false)}><div className="form-grid">
      <label>Firebase UID<input value={f.uid} disabled={Boolean(editing)} onChange={e=>setF({...f,uid:e.target.value})} placeholder="Paste UID from Firebase Authentication"/></label>
      <label>Name<input value={f.name} onChange={e=>setF({...f,name:e.target.value})}/></label>
      <label>Login email / username alias<input type="text" value={f.email} onChange={e=>setF({...f,email:e.target.value})} placeholder="username@backwoodsbrew-e3584-d52a3.firebaseapp.com"/></label>
      <label>Role<select value={f.role} onChange={e=>setF({...f,role:e.target.value})}>{roles.map(r=><option key={r}>{r}</option>)}</select></label>
      <label className="check-label"><input type="checkbox" checked={f.active} onChange={e=>setF({...f,active:e.target.checked})}/> Active account</label>
    </div>{message&&<div className="auth-error">{message}</div>}<div className="actions"><button className="secondary" onClick={()=>setOpen(false)}>Cancel</button><button onClick={save}>Save profile</button></div></Modal>}
  </>;
}
