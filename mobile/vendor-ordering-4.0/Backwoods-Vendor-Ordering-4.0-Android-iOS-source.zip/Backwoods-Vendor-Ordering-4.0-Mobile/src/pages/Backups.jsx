import { useMemo } from 'react';
import { makeId, now } from '../lib/helpers';
const BACKUP_KEYS=['company','users','customers','products','suppliers','purchaseOrders','purchaseReceipts','supplierInvoices','orders','credits','payments','inventoryMovements','routePlans','notifications','auditLogs'];
function snapshot(data){return Object.fromEntries(BACKUP_KEYS.map(k=>[k,data[k]]));}
export default function Backups({data,update}){
 const rows=useMemo(()=>[...(data.cloudBackups||[])].sort((a,b)=>String(b.createdAt).localeCompare(String(a.createdAt))),[data.cloudBackups]);
 const create=()=>update(d=>({...d,cloudBackups:[...(d.cloudBackups||[]),{id:makeId('backup'),createdAt:now(),kind:'manual',recordCounts:Object.fromEntries(BACKUP_KEYS.filter(k=>Array.isArray(d[k])).map(k=>[k,d[k].length])),payload:JSON.stringify(snapshot(d))}]}));
 const download=b=>{const blob=new Blob([b.payload],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`backwoods-cloud-backup-${b.createdAt.slice(0,10)}.json`;a.click();URL.revokeObjectURL(a.href)};
 const restore=b=>{if(!confirm('Restore this backup? Current business data will be replaced.'))return;const parsed=JSON.parse(b.payload);update(d=>({...d,...parsed,cloudBackups:d.cloudBackups}));};
 return <><div className="page-head"><div><h1>Cloud Backups</h1><p>A daily backup is created automatically when an owner opens the app. Create, download, or restore snapshots here.</p></div><button onClick={create}>Create backup now</button></div><div className="panel"><table><thead><tr><th>Date</th><th>Type</th><th>Orders</th><th>Products</th><th>Customers</th><th></th></tr></thead><tbody>{rows.map(b=><tr key={b.id}><td>{new Date(b.createdAt).toLocaleString()}</td><td>{b.kind}</td><td>{b.recordCounts?.orders||0}</td><td>{b.recordCounts?.products||0}</td><td>{b.recordCounts?.customers||0}</td><td><div className="actions"><button className="small secondary" onClick={()=>download(b)}>Download</button><button className="small" onClick={()=>restore(b)}>Restore</button></div></td></tr>)}</tbody></table>{!rows.length&&<div className="empty">No cloud backups yet.</div>}</div></>;
}
