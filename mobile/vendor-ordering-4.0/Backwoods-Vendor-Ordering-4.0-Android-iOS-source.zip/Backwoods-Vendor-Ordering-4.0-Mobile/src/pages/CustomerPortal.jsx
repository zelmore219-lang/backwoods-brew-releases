import { useMemo, useState } from 'react';
import { useAuth } from '../auth/AuthContext';
import Modal from '../components/Modal';
import InvoiceView from '../components/InvoiceView';
import { calcOrder, makeId, nextBusinessNumbers, now, money } from '../lib/helpers';

export default function CustomerPortal({data, update}) {
  const { user } = useAuth();
  const [selectedInvoice, setSelectedInvoice] = useState(null);
  const [repeatOrder, setRepeatOrder] = useState(null);
  const [message, setMessage] = useState('');
  const customer = data.customers.find(c => c.id === user.customerId || c.email?.toLowerCase() === user.email?.toLowerCase());
  const orders = useMemo(() => data.orders.filter(o => o.customerId === customer?.id).sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt)), [data.orders, customer]);
  const openOrders = orders.filter(o => !['delivered','completed','cancelled','void'].includes(o.status));
  const balance = orders.reduce((sum,o)=>sum+calcOrder(o).balance,0);
  const paymentLink = order => { if(!data.company.paymentLinkBase)return ''; const u=new URL(data.company.paymentLinkBase,window.location.href); const t=calcOrder(order); u.searchParams.set('invoice',order.invoiceNumber||''); u.searchParams.set('amount',Number(t.balance||0).toFixed(2)); u.searchParams.set('customer',customer?.name||''); return u.toString(); };
  const approvedCredits = data.credits.filter(c=>c.customerId===customer?.id && c.status==='approved').reduce((s,c)=>s+Number(c.amount||0),0);

  if (!customer) return <div className="panel"><h1>Customer portal</h1><p>Your account is signed in, but it is not linked to a customer record yet.</p><p>Ask an owner to add <code>customerId</code> to your user profile.</p></div>;

  const placeRepeat = () => {
    if (!repeatOrder) return;
    const unavailable = repeatOrder.items.find(i => {
      const p = data.products.find(x=>x.id===i.productId);
      return !p || Number(p.onHand||0)-Number(p.reserved||0) < Number(i.qty||0);
    });
    if (unavailable) return setMessage(`${unavailable.name} does not have enough available inventory.`);
    update(d => {
      const nums=nextBusinessNumbers(d);
      const order = {
        id:makeId('o'), orderNumber:nums.orderNumber, invoiceNumber:nums.invoiceNumber,
        customerId:customer.id, items:repeatOrder.items.map(i=>({productId:i.productId,sku:i.sku,name:i.name,qty:Number(i.qty),price:Number(i.price)})),
        status:'submitted', createdAt:now(), updatedAt:now(), credits:[], payments:[], tax:0,
        salesperson:'Customer portal', notes:`Repeat order from ${repeatOrder.orderNumber}`, source:'customer_portal'
      };
      return {...d, company:{...d.company,nextInvoiceNumber:nums.nextInvoiceNumber}, orders:[...d.orders,order], products:d.products.map(p=>{
        const line=order.items.find(i=>i.productId===p.id); return line?{...p,reserved:Number(p.reserved||0)+Number(line.qty)}:p;
      })};
    });
    setRepeatOrder(null); setMessage('Repeat order submitted successfully.');
  };

  return <>
    <div className="page-head"><div><h1>Welcome, {customer.name}</h1><p>View deliveries, invoices, balances, credits, and place repeat orders.</p></div></div>
    {message&&<div className="notice">{message}</div>}
    <div className="stats portal-stats">
      <div className="stat"><span>Open orders</span><strong>{openOrders.length}</strong></div>
      <div className="stat"><span>Account balance</span><strong>{money(balance)}</strong></div>
      <div className="stat"><span>Approved credits</span><strong>{money(approvedCredits)}</strong></div>
      <div className="stat"><span>Payment terms</span><strong>{customer.terms||'—'}</strong></div>
    </div>

    <div className="panel"><div className="panel-title"><div><h2>Orders and deliveries</h2><p>Follow each order from submission through delivery.</p></div></div>
      <table><thead><tr><th>Order</th><th>Date</th><th>Status</th><th>Delivery</th><th>Total</th><th>Balance</th><th></th></tr></thead><tbody>{orders.map(o=>{const t=calcOrder(o);return <tr key={o.id}><td><b>{o.orderNumber}</b><small>{o.invoiceNumber}</small></td><td>{new Date(o.createdAt).toLocaleDateString()}</td><td><span className="status">{o.status}</span></td><td>{o.deliveryDate?new Date(`${o.deliveryDate}T12:00:00`).toLocaleDateString():'Not scheduled'}<small>{o.routeName||''}</small></td><td>{money(t.total)}</td><td>{money(t.balance)}</td><td><div className="row-actions"><button className="small secondary" onClick={()=>setSelectedInvoice(o)}>Invoice</button>{t.balance>0&&paymentLink(o)&&<a className="button small" href={paymentLink(o)} target="_blank" rel="noreferrer">Pay</a>}<button className="small" disabled={['cancelled','void'].includes(o.status)} onClick={()=>setRepeatOrder(o)}>Repeat</button></div></td></tr>})}</tbody></table>
      {!orders.length&&<p className="empty">No orders have been placed for this account.</p>}
    </div>

    <div className="panel"><h2>Credits</h2><table><thead><tr><th>Date</th><th>Reason</th><th>Status</th><th>Pickup</th><th>Amount</th></tr></thead><tbody>{data.credits.filter(c=>c.customerId===customer.id).map(c=><tr key={c.id}><td>{new Date(c.createdAt||Date.now()).toLocaleDateString()}</td><td>{c.reason||'Store credit'}</td><td><span className="status">{c.status}</span></td><td>{c.pickupRequired?'Required':'No'}</td><td>{money(c.amount)}</td></tr>)}</tbody></table></div>

    {selectedInvoice&&<Modal title={selectedInvoice.invoiceNumber} wide onClose={()=>setSelectedInvoice(null)}><InvoiceView order={selectedInvoice} customer={customer} company={data.company}/><div className="actions no-print"><button onClick={()=>window.print()}>Print / Save PDF</button></div></Modal>}
    {repeatOrder&&<Modal title={`Repeat ${repeatOrder.orderNumber}`} wide onClose={()=>setRepeatOrder(null)}>{message&&<div className="alert">{message}</div>}<p>Review quantities before submitting a new order.</p><table><thead><tr><th>Product</th><th>Available</th><th>Quantity</th><th>Price</th><th>Total</th></tr></thead><tbody>{repeatOrder.items.map((i,idx)=>{const p=data.products.find(x=>x.id===i.productId);const available=Number(p?.onHand||0)-Number(p?.reserved||0);return <tr key={i.productId}><td>{i.name}<small>{i.sku}</small></td><td>{available}</td><td><input className="qty" type="number" min="0" max={available} value={i.qty} onChange={e=>setRepeatOrder({...repeatOrder,items:repeatOrder.items.map((x,n)=>n===idx?{...x,qty:Number(e.target.value)}:x)})}/></td><td>{money(i.price)}</td><td>{money(Number(i.qty)*Number(i.price))}</td></tr>})}</tbody></table><div className="order-total"><span>New order total</span><strong>{money(repeatOrder.items.reduce((s,i)=>s+Number(i.qty)*Number(i.price),0))}</strong></div><div className="actions"><button onClick={placeRepeat}>Submit repeat order</button></div></Modal>}
  </>;
}
