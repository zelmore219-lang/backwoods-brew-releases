import { useEffect, useState } from 'react';
import { Bell, Building2, FileText, Palette, Printer, Save, ShieldCheck } from 'lucide-react';

const defaults = {
  name:'', legalName:'', address:'', city:'', state:'', zip:'', phone:'', email:'', website:'', taxId:'', logo:'',
  invoicePrefix:'INV', orderPrefix:'ORD', nextInvoiceNumber:1001, defaultTerms:'Net 14', defaultTaxRate:0,
  invoiceFooter:'Thank you for your business.', paymentInstructions:'', showSku:true, showSignature:true, showPaymentHistory:true,
  printPackingPrices:false, printTwoCopies:false, emailInvoiceOnDelivery:false, notifyLowStock:true,
  notifyCreditApproval:true, notifyRouteAssignment:true, lowStockEmail:'', brandAccent:'#1f6f43', paymentLinkBase:''
};

export default function Settings({data,update,reset}){
  const [c,setC]=useState({...defaults,...data.company});
  const [saved,setSaved]=useState(false);
  useEffect(()=>setC({...defaults,...data.company}),[data.company]);
  const set=(key,value)=>setC(v=>({...v,[key]:value}));
  const logo=e=>{const file=e.target.files?.[0];if(!file)return;if(file.size>1024*1024){alert('Please use a logo smaller than 1 MB.');return;}const r=new FileReader();r.onload=()=>set('logo',r.result);r.readAsDataURL(file)};
  const save=async()=>{
    const old=data.company;
    const changed=Object.keys(c).filter(k=>JSON.stringify(old?.[k])!==JSON.stringify(c[k]));
    await update(d=>({...d,company:c,auditLogs:[...(d.auditLogs||[]),{id:crypto.randomUUID(),entityType:'settings',entityId:'company',action:'Company settings updated',details:changed.length?`Changed: ${changed.join(', ')}`:'No field changes',createdAt:new Date().toISOString(),actor:'Owner'}]}));
    setSaved(true);setTimeout(()=>setSaved(false),2500);
  };
  return <>
    <div className="page-head"><div><h1>Company Settings</h1><p>Control branding, invoice defaults, printing, payments, and notifications.</p></div><button onClick={save}><Save size={17}/> {saved?'Saved':'Save settings'}</button></div>
    <div className="settings-tabs">
      <section className="panel settings-section"><h2><Building2 size={20}/> Company profile</h2><div className="form-grid">
        <label>Display name<input value={c.name} onChange={e=>set('name',e.target.value)}/></label>
        <label>Legal business name<input value={c.legalName} onChange={e=>set('legalName',e.target.value)}/></label>
        <label className="span-2">Street address<input value={c.address} onChange={e=>set('address',e.target.value)}/></label>
        <label>City<input value={c.city} onChange={e=>set('city',e.target.value)}/></label><label>State<input value={c.state} onChange={e=>set('state',e.target.value)}/></label>
        <label>ZIP code<input value={c.zip} onChange={e=>set('zip',e.target.value)}/></label><label>Phone<input value={c.phone} onChange={e=>set('phone',e.target.value)}/></label>
        <label>Email<input type="email" value={c.email} onChange={e=>set('email',e.target.value)}/></label><label>Website<input value={c.website} onChange={e=>set('website',e.target.value)}/></label>
        <label>Tax ID / EIN<input value={c.taxId} onChange={e=>set('taxId',e.target.value)}/></label><label>Company logo<input type="file" accept="image/png,image/jpeg,image/webp" onChange={logo}/></label>
      </div>{c.logo&&<div className="logo-row"><img className="logo-preview" src={c.logo} alt="Company logo preview"/><button className="secondary small" onClick={()=>set('logo','')}>Remove logo</button></div>}</section>

      <section className="panel settings-section"><h2><FileText size={20}/> Invoice and order defaults</h2><div className="form-grid">
        <label>Invoice prefix<input value={c.invoicePrefix} onChange={e=>set('invoicePrefix',e.target.value.toUpperCase())}/></label><label>Next invoice number<input type="number" min="1" value={c.nextInvoiceNumber} onChange={e=>set('nextInvoiceNumber',Number(e.target.value))}/></label>
        <label>Order prefix<input value={c.orderPrefix} onChange={e=>set('orderPrefix',e.target.value.toUpperCase())}/></label><label>Default payment terms<select value={c.defaultTerms} onChange={e=>set('defaultTerms',e.target.value)}><option>COD</option><option>Due on receipt</option><option>Net 7</option><option>Net 14</option><option>Net 30</option><option>Net 60</option></select></label>
        <label>Default tax rate (%)<input type="number" min="0" max="100" step="0.01" value={c.defaultTaxRate} onChange={e=>set('defaultTaxRate',Number(e.target.value))}/></label><label>Brand accent<input type="color" value={c.brandAccent} onChange={e=>set('brandAccent',e.target.value)}/></label>
        <label className="span-2">Customer payment-link base URL<input value={c.paymentLinkBase||''} onChange={e=>set('paymentLinkBase',e.target.value)} placeholder="https://pay.example.com/invoice"/><small>Invoice number, amount, and customer are added as URL parameters.</small></label>
        <label className="span-2">Payment instructions<textarea value={c.paymentInstructions} onChange={e=>set('paymentInstructions',e.target.value)} placeholder="Make checks payable to..."/></label>
        <label className="span-2">Invoice footer<textarea value={c.invoiceFooter} onChange={e=>set('invoiceFooter',e.target.value)}/></label>
      </div></section>

      <section className="panel settings-section"><h2><Printer size={20}/> Print and document options</h2><div className="toggle-grid">
        <Toggle label="Show SKU on invoices" checked={c.showSku} onChange={v=>set('showSku',v)}/><Toggle label="Show customer signature" checked={c.showSignature} onChange={v=>set('showSignature',v)}/>
        <Toggle label="Show payment history" checked={c.showPaymentHistory} onChange={v=>set('showPaymentHistory',v)}/><Toggle label="Show prices on packing slips" checked={c.printPackingPrices} onChange={v=>set('printPackingPrices',v)}/>
        <Toggle label="Print two invoice copies" checked={c.printTwoCopies} onChange={v=>set('printTwoCopies',v)}/><Toggle label="Email invoice when delivered" checked={c.emailInvoiceOnDelivery} onChange={v=>set('emailInvoiceOnDelivery',v)}/>
      </div></section>

      <section className="panel settings-section"><h2><Bell size={20}/> Notifications</h2><div className="toggle-grid">
        <Toggle label="Low-stock alerts" checked={c.notifyLowStock} onChange={v=>set('notifyLowStock',v)}/><Toggle label="Credit approval alerts" checked={c.notifyCreditApproval} onChange={v=>set('notifyCreditApproval',v)}/><Toggle label="Driver route assignment alerts" checked={c.notifyRouteAssignment} onChange={v=>set('notifyRouteAssignment',v)}/>
      </div><label>Low-stock alert email<input type="email" value={c.lowStockEmail} onChange={e=>set('lowStockEmail',e.target.value)} placeholder={c.email||'inventory@example.com'}/></label></section>

      <section className="panel settings-section danger-zone"><h2><ShieldCheck size={20}/> Demo data</h2><p>Resetting restores the original demonstration customers, products, and settings on this browser. Do not use this after entering live business data.</p><button className="danger" onClick={()=>{if(confirm('Reset all demo data? This cannot be undone.'))reset();}}>Reset demo data</button></section>
    </div>
  </>;
}
function Toggle({label,checked,onChange}){return <label className="toggle"><input type="checkbox" checked={!!checked} onChange={e=>onChange(e.target.checked)}/><span><b>{label}</b><small>{checked?'Enabled':'Disabled'}</small></span></label>}
