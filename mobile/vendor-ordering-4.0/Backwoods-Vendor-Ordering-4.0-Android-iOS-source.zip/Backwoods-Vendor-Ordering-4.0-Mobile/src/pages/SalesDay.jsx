import { useMemo } from 'react';
import { Link } from 'react-router-dom';
import { money, calcOrder, now } from '../lib/helpers';

const days=['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
export default function SalesDay({data,update}){
 const today=days[new Date().getDay()];
 const routes=(data.routePlans||[]).filter(r=>r.dayOfWeek===today);
 const stores=useMemo(()=>routes.flatMap(r=>(r.storeIds||[]).map((id,index)=>({store:data.customers.find(c=>c.id===id),route:r,index})).filter(x=>x.store)),[routes,data.customers]);
 const todayKey=new Date().toISOString().slice(0,10);
 const getVisit=(storeId)=>(data.notifications||[]).find(n=>n.type==='route_visit'&&n.storeId===storeId&&n.date===todayKey);
 const setStatus=(storeId,status)=>update(d=>{const id=`visit_${todayKey}_${storeId}`;const entry={id,type:'route_visit',storeId,date:todayKey,status,updatedAt:now(),read:true};return {...d,notifications:[...(d.notifications||[]).filter(n=>n.id!==id),entry]}});
 const orders=data.orders.filter(o=>o.deliveryDay===today&&!['cancelled'].includes(o.status));
 const routeSales=orders.reduce((s,o)=>s+calcOrder(o).total,0);
 const complete=stores.filter(x=>['completed','skipped','closed'].includes(getVisit(x.store.id)?.status)).length;
 return <>
  <div className="page-head"><div><h1>Today&apos;s Route</h1><p>{today} selling and service dashboard.</p></div><Link className="link-button" to="/orders">Create order</Link></div>
  <div className="stats"><div className="card"><span>Routes today</span><strong>{routes.length}</strong></div><div className="card"><span>Stops</span><strong>{stores.length}</strong></div><div className="card"><span>Completed</span><strong>{complete}</strong></div><div className="card"><span>Route sales</span><strong>{money(routeSales)}</strong></div></div>
  {!routes.length&&<div className="panel empty">No routes are assigned to {today}. Create one under Routes.</div>}
  {routes.map(route=><div className="panel" key={route.id}><div className="panel-title"><div><h2>{route.name}</h2><p>{route.driver||'Driver not assigned'} · {(route.storeIds||[]).length} stops</p></div><span className="status">{today}</span></div>
   <div className="route-day-list">{(route.storeIds||[]).map((id,index)=>{const store=data.customers.find(c=>c.id===id);if(!store)return null;const visit=getVisit(id);const last=data.orders.filter(o=>o.customerId===id).sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt))[0];return <div className="route-day-stop" key={id}><div className="stop-number">{index+1}</div><div><b>{store.name}</b><small>{store.address}{store.city?`, ${store.city}`:''}</small><small>{last?`Last order ${new Date(last.createdAt).toLocaleDateString()} · ${money(calcOrder(last).total)}`:'No previous order'}</small></div><div className="visit-actions"><select value={visit?.status||'not_visited'} onChange={e=>setStatus(id,e.target.value)}><option value="not_visited">Not visited</option><option value="started">Order started</option><option value="completed">Completed</option><option value="skipped">Skipped</option><option value="closed">Store closed</option><option value="follow_up">Follow-up needed</option></select><Link className="small link-button" to={`/orders?store=${id}`}>Order</Link>{store.phone&&<a className="small secondary link-button" href={`tel:${store.phone}`}>Call</a>}{store.address&&<a className="small secondary link-button" target="_blank" rel="noreferrer" href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(store.address+' '+(store.city||''))}`}>Navigate</a>}</div></div>})}</div>
  </div>)}
 </>;
}
