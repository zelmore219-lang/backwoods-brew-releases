import { useState } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../auth/AuthContext';

const roles = [
  ['owner', 'Owner'], ['manager', 'Manager'], ['sales', 'Salesperson'],
  ['packer', 'Packer'], ['driver', 'Driver'], ['accounting', 'Accounting'], ['customer', 'Customer Portal']
];

export default function Login() {
  const { user, login, demoLogin, firebaseEnabled, error } = useAuth();
  const location = useLocation();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const from = location.state?.from?.pathname || (user?.role === 'customer' ? '/portal' : '/');

  if (user) return <Navigate to={user.role === 'customer' ? '/portal' : from} replace />;

  const submit = async e => {
    e.preventDefault();
    setBusy(true);
    try { await login(username, password); } catch { /* displayed by context */ }
    finally { setBusy(false); }
  };

  return <div className="auth-page">
    <div className="auth-card">
      <div className="auth-brandmark">BB</div>
      <h1>Backwoods Vendor Operations</h1>
      <p>{firebaseEnabled ? 'Sign in with your company account.' : 'Firebase is not configured yet. Choose a role to test the app.'}</p>
      {firebaseEnabled ? <form onSubmit={submit}>
        <label>Username<input type="text" value={username} onChange={e=>setUsername(e.target.value)} required autoComplete="username" placeholder="Enter your username"/></label>
        <label>Password<input type="password" value={password} onChange={e=>setPassword(e.target.value)} required autoComplete="current-password"/></label>
        {error && <div className="auth-error">{error}</div>}
        <button className="auth-submit" disabled={busy}>{busy ? 'Signing in…' : 'Sign in'}</button>
      </form> : <div className="demo-role-grid">
        {roles.map(([role,label]) => <button key={role} onClick={()=>demoLogin(role)}>{label}</button>)}
      </div>}
      <small>{firebaseEnabled ? 'Use your assigned username and password.' : 'Demo mode stores the selected role only on this device.'}</small>
    </div>
  </div>;
}
