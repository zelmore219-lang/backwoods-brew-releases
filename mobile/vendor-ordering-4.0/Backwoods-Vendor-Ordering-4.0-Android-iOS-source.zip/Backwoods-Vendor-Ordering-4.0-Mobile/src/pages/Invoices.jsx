import { useMemo, useState } from 'react';
import Modal from '../components/Modal';
import InvoiceView from '../components/InvoiceView';
import { calcOrder, money, now } from '../lib/helpers';

export default function Invoices({data, update}){
  const [sel,setSel]=useState(null);
  const [edit,setEdit]=useState(null);
  const [search,setSearch]=useState('');
  const [status,setStatus]=useState('all');
  const [reason,setReason]=useState('');
  const [error,setError]=useState('');
  const rows=useMemo(()=>data.orders.filter(o=>{
    const c=data.customers.find(x=>x.id===o.customerId);
    const q=search.toLowerCase();
    const match=!q || `${o.invoiceNumber} ${c?.name||''}`.toLowerCase().includes(q);
    const t=calcOrder(o);
    const group=t.balance<=.009?'paid':t.paid>0?'partial':'unpaid';
    return match && (status==='all'||status===group);
  }).reverse(),[data.orders,data.customers,search,status]);
  const openEdit=o=>{setEdit(JSON.parse(JSON.stringify(o)));setReason('');setError('')};
  const saveEdit=()=>{
    if(!reason.trim())return setError('Enter a reason for changing this invoice.');
    const audit={id:`audit_${Date.now()}`,type:'invoice_edit',orderId:edit.id,invoiceNumber:edit.invoiceNumber,reason:reason.trim(),createdAt:now()};
    update(d=>({...d,orders:d.orders.map(o=>o.id===edit.id?{...edit,updatedAt:now(),audit:[...(o.audit||[]),audit]}:o)}));setEdit(null);
  };
  const voidInvoice=o=>{
    const why=window.prompt('Reason for voiding this invoice?'); if(!why)return;
    update(d=>({...d,orders:d.orders.map(x=>x.id===o.id?{...x,status:'void',voidReason:why,voidedAt:now(),updatedAt:now()}:x)}));
  };
  return <><div className="page-head"><div><h1>Invoices</h1><p>Search, edit, void, print, and review payment history.</p></div></div>
  <div className="panel invoice-filters"><input placeholder="Search invoice or customer" value={search} onChange={e=>setSearch(e.target.value)}/><select value={status} onChange={e=>setStatus(e.target.value)}><option value="all">All balances</option><option value="unpaid">Unpaid</option><option value="partial">Partially paid</option><option value="paid">Paid</option></select></div>
  <div className="panel"><table><thead><tr><th>Invoice</th><th>Customer</th><th>Status</th><th>Total</th><th>Paid</th><th>Balance</th><th></th></tr></thead><tbody>{rows.map(o=>{const t=calcOrder(o);return <tr key={o.id}><td>{o.invoiceNumber}<small>{new Date(o.createdAt).toLocaleDateString()}</small></td><td>{data.customers.find(c=>c.id===o.customerId)?.name}</td><td><span className="status">{o.status}</span></td><td>{money(t.total)}</td><td>{money(t.paid)}</td><td><b>{money(t.balance)}</b></td><td><div className="row-actions"><button className="small secondary" onClick={()=>setSel(o)}>View</button><button className="small secondary" disabled={o.status==='void'} onClick={()=>openEdit(o)}>Edit</button><button className="small danger" disabled={o.status==='void'||t.paid>0} onClick={()=>voidInvoice(o)}>Void</button></div></td></tr>})}</tbody></table></div>
  {sel&&<Modal title={sel.invoiceNumber} wide onClose={()=>setSel(null)}><InvoiceView order={sel} customer={data.customers.find(c=>c.id===sel.customerId)} company={data.company}/>{(sel.payments||[]).length>0&&<div className="panel"><h3>Payment history</h3><table><thead><tr><th>Date</th><th>Method</th><th>Reference</th><th>Amount</th></tr></thead><tbody>{sel.payments.map(p=><tr key={p.id}><td>{new Date(p.createdAt).toLocaleString()}</td><td>{p.method}</td><td>{p.checkNumber||p.reference||'—'}</td><td>{money(p.amount)}</td></tr>)}</tbody></table></div>}<div className="actions no-print"><button onClick={()=>window.print()}>Print / Save PDF</button></div></Modal>}
  {edit&&<Modal title={`Edit ${edit.invoiceNumber}`} wide onClose={()=>setEdit(null)}>{error&&<div className="alert">{error}</div>}<div className="packing-table-wrap"><table><thead><tr><th>Product</th><th>Delivered</th><th>Returned</th><th>Price</th><th>Net line</th></tr></thead><tbody>{edit.items.map((i,idx)=><tr key={i.productId}><td>{i.name}<small>{i.sku}</small></td><td><input className="qty" type="number" min="0" value={i.invoiceQty??i.deliveredQty??i.qty} onChange={e=>setEdit({...edit,items:edit.items.map((x,n)=>n===idx?{...x,invoiceQty:Number(e.target.value)}:x)})}/></td><td><input className="qty return-qty" type="number" min="0" value={i.returnQty||0} onChange={e=>setEdit({...edit,items:edit.items.map((x,n)=>n===idx?{...x,returnQty:Number(e.target.value)}:x)})}/></td><td><input className="price" type="number" min="0" step="0.01" value={i.price} onChange={e=>setEdit({...edit,items:edit.items.map((x,n)=>n===idx?{...x,price:Number(e.target.value)}:x)})}/></td><td>{money((Number(i.invoiceQty??i.deliveredQty??i.qty)-Number(i.returnQty||0))*Number(i.price))}</td></tr>)}</tbody></table></div><div className="form-grid"><label>Tax<input type="number" step="0.01" value={edit.tax||0} onChange={e=>setEdit({...edit,tax:Number(e.target.value)})}/></label><label>Adjustment reason<input value={reason} onChange={e=>setReason(e.target.value)} placeholder="Required for audit trail"/></label></div><div className="order-total"><span>Updated total</span><strong>{money(calcOrder(edit).total)}</strong></div><div className="actions"><button onClick={saveEdit}>Save invoice changes</button></div></Modal>}
  </>;
}
