import { Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/Layout';
import ProtectedRoute from './auth/ProtectedRoute';
import { useStore } from './lib/store';
import Dashboard from './pages/Dashboard';
import Customers from './pages/Customers';
import Products from './pages/Products';
import Orders from './pages/Orders';
import Packing from './pages/Packing';
import Drivers from './pages/Drivers';
import Invoices from './pages/Invoices';
import Credits from './pages/Credits';
import Settings from './pages/Settings';
import Login from './pages/Login';
import Unauthorized from './pages/Unauthorized';
import Users from './pages/Users';
import AccountsReceivable from './pages/AccountsReceivable';
import Reports from './pages/Reports';
import RoutesPage from './pages/Routes';
import CustomerPortal from './pages/CustomerPortal';
import AuditLog from './pages/AuditLog';
import SystemDiagnostics from './pages/SystemDiagnostics';
import Labels from './pages/Labels';
import Backups from './pages/Backups';
import Suppliers from './pages/Suppliers';
import Purchasing from './pages/Purchasing';
import AutoCloudBackup from './components/AutoCloudBackup';
import LaunchCenter from './pages/LaunchCenter';
import SalesDay from './pages/SalesDay';
import Notifications from './pages/Notifications';

const protect = (element, roles) => <ProtectedRoute roles={roles}>{element}</ProtectedRoute>;

export default function App(){
  const store = useStore();
  return <><AutoCloudBackup {...store}/><Routes>
    <Route path="/login" element={<Login/>}/>
    <Route path="/unauthorized" element={<Unauthorized/>}/>
    <Route path="/portal" element={protect(<CustomerPortal {...store}/>, ['customer'])}/>
    <Route path="/*" element={protect(
      <Layout company={store.data.company}>
        <Routes>
          <Route path="/" element={protect(<Dashboard {...store}/>, ['owner','manager','sales','packer','driver','accounting'])}/>
          <Route path="/customers" element={protect(<Customers {...store}/>, ['owner','manager','sales','accounting'])}/>
          <Route path="/products" element={protect(<Products {...store}/>, ['owner','manager','sales','packer','accounting'])}/>
          <Route path="/orders" element={protect(<Orders {...store}/>, ['owner','manager','sales'])}/>
          <Route path="/sales-day" element={protect(<SalesDay {...store}/>, ['owner','manager','sales','driver'])}/>
          <Route path="/notifications" element={protect(<Notifications {...store}/>, ['owner','manager','sales','packer','driver','accounting'])}/>
          <Route path="/suppliers" element={protect(<Suppliers {...store}/>, ['owner','manager','accounting'])}/>
          <Route path="/purchasing" element={protect(<Purchasing {...store}/>, ['owner','manager','packer','accounting'])}/>
          <Route path="/packing" element={protect(<Packing {...store}/>, ['owner','manager','packer'])}/>
          <Route path="/routes" element={protect(<RoutesPage {...store}/>, ['owner','manager'])}/>
          <Route path="/drivers" element={protect(<Drivers {...store}/>, ['owner','manager','driver'])}/>
          <Route path="/invoices" element={protect(<Invoices {...store}/>, ['owner','manager','sales','driver','accounting'])}/>
          <Route path="/credits" element={protect(<Credits {...store}/>, ['owner','manager','sales','driver','accounting'])}/>
          <Route path="/receivables" element={protect(<AccountsReceivable {...store}/>, ['owner','manager','accounting'])}/>
          <Route path="/reports" element={protect(<Reports {...store}/>, ['owner','manager','accounting'])}/>
          <Route path="/launch" element={protect(<LaunchCenter {...store}/>, ['owner','manager','accounting'])}/>
          <Route path="/users" element={protect(<Users {...store}/>, ['owner'])}/>
          <Route path="/audit" element={protect(<AuditLog {...store}/>, ['owner','manager'])}/>
          <Route path="/labels" element={protect(<Labels {...store}/>, ['owner','manager','packer'])}/>
          <Route path="/backups" element={protect(<Backups {...store}/>, ['owner'])}/>
          <Route path="/system" element={protect(<SystemDiagnostics {...store}/>, ['owner'])}/>
          <Route path="/settings" element={protect(<Settings {...store}/>, ['owner'])}/>
        </Routes>
      </Layout>
    )}/>
  </Routes></>;
}
