import { useEffect, useRef, useState } from 'react';
import { BrowserMultiFormatReader } from '@zxing/browser';

export default function BarcodeScanner({ onScan, placeholder='Scan barcode or type code', autoFocus=true }) {
  const [value, setValue] = useState('');
  const [cameraOpen, setCameraOpen] = useState(false);
  const [error, setError] = useState('');
  const videoRef = useRef(null);
  const controlsRef = useRef(null);
  const generation = useRef(0);
  const onScanRef = useRef(onScan);
  onScanRef.current = onScan;
  const stopCamera = () => {
    generation.current += 1;
    controlsRef.current?.stop();
    controlsRef.current = null;
    videoRef.current?.srcObject?.getTracks().forEach(track => track.stop());
    setCameraOpen(false);
  };
  useEffect(() => {
    if (!cameraOpen) return;
    const token = ++generation.current;
    let activeControls;
    const reader = new BrowserMultiFormatReader();
    reader.decodeFromConstraints({ video: { facingMode: { ideal: 'environment' } }, audio: false }, videoRef.current, (result, _error, controls) => {
      if (token !== generation.current) { controls.stop(); return; }
      if (result) {
        controls.stop();
        generation.current += 1;
        setCameraOpen(false);
        onScanRef.current(result.getText());
      }
    }).then(controls => {
      activeControls = controls;
      if (token !== generation.current) controls.stop();
      else controlsRef.current = controls;
    }).catch(err => {
      if (token !== generation.current) return;
      setError(`Could not open camera: ${err.message}. Check camera permission or type the barcode.`);
      setCameraOpen(false);
    });
    return () => {
      generation.current += 1;
      activeControls?.stop();
      controlsRef.current?.stop();
      controlsRef.current = null;
    };
  }, [cameraOpen]);
  const submit = () => { const code = value.trim(); if (code) { onScan(code); setValue(''); } };
  return <div className="barcode-scanner">
    <div className="scanner-row"><input autoFocus={autoFocus} value={value} onChange={e => setValue(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); submit(); } }} placeholder={placeholder}/><button type="button" onClick={submit}>Scan</button><button type="button" className="secondary" onClick={() => { setError(''); cameraOpen ? stopCamera() : setCameraOpen(true); }}>{cameraOpen ? 'Close camera' : 'Use camera'}</button></div>
    {cameraOpen && <video ref={videoRef} className="scanner-video" muted playsInline/>}
    {error && <small role="alert" className="scanner-error">{error}</small>}
  </div>;
}
