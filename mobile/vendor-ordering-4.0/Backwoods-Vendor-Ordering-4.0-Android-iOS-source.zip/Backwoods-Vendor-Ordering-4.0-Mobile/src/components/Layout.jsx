import { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { Store, LayoutDashboard, Users, Boxes, ClipboardList, PackageCheck, Truck, FileText, BadgeDollarSign, Settings, LogOut, UserCog, Landmark, BarChart3, Route, History, Activity, ScanBarcode, CloudCog, Factory, ShoppingCart, Rocket, CalendarDays, Bell } from 'lucide-react';
import { useAuth } from '../auth/AuthContext';
import ConnectionStatus from './ConnectionStatus';

const nav = [
  { to:'/portal', label:'My Account', icon:Store, roles:['customer'] },
  { to:'/', label:'Dashboard', icon:LayoutDashboard },
  { to:'/customers', label:'Stores', icon:Users, roles:['owner','manager','sales','accounting'] },
  { to:'/products', label:'Products', icon:Boxes, roles:['owner','manager','sales','packer','accounting'] },
  { to:'/orders', label:'Orders', icon:ClipboardList, roles:['owner','manager','sales'] },
  { to:'/sales-day', label:"Today's Route", icon:CalendarDays, roles:['owner','manager','sales','driver'] },
  { to:'/notifications', label:'Notifications', icon:Bell, roles:['owner','manager','sales','packer','driver','accounting'] },
  { to:'/suppliers', label:'Suppliers', icon:Factory, roles:['owner','manager','accounting'] },
  { to:'/purchasing', label:'Purchasing', icon:ShoppingCart, roles:['owner','manager','packer','accounting'] },
  { to:'/packing', label:'Packing', icon:PackageCheck, roles:['owner','manager','packer'] },
  { to:'/routes', label:'Routes', icon:Route, roles:['owner','manager'] },
  { to:'/drivers', label:'Drivers', icon:Truck, roles:['owner','manager','driver'] },
  { to:'/invoices', label:'Invoices', icon:FileText, roles:['owner','manager','sales','driver','accounting'] },
  { to:'/credits', label:'Credits', icon:BadgeDollarSign, roles:['owner','manager','sales','driver','accounting'] },
  { to:'/receivables', label:'Receivables', icon:Landmark, roles:['owner','manager','accounting'] },
  { to:'/reports', label:'Reports', icon:BarChart3, roles:['owner','manager','accounting'] },
  { to:'/launch', label:'Launch Center', icon:Rocket, roles:['owner','manager','accounting'] },
  { to:'/users', label:'Users', icon:UserCog, roles:['owner'] },
  { to:'/labels', label:'Labels', icon:ScanBarcode, roles:['owner','manager','packer'] },
  { to:'/backups', label:'Backups', icon:CloudCog, roles:['owner'] },
  { to:'/audit', label:'Audit Log', icon:History, roles:['owner','manager'] },
  { to:'/system', label:'System', icon:Activity, roles:['owner'] },
  { to:'/settings', label:'Settings', icon:Settings, roles:['owner'] }
];

export default function Layout({ children, company }) {
  const [menuOpen, setMenuOpen] = useState(false);
  const { user, logout, firebaseEnabled } = useAuth();
  const allowedNav = nav.filter(item => user.role === 'customer' ? item.roles?.includes('customer') : (!item.roles || item.roles.includes(user.role)));

  return <div className="app-shell">
    <header className="mobile-header no-print"><strong>{company.name}</strong><button type="button" aria-expanded={menuOpen} aria-controls="main-navigation" onClick={() => setMenuOpen(!menuOpen)}>{menuOpen ? 'Close menu' : 'Menu'}</button></header>
    <aside id="main-navigation" className={`sidebar ${menuOpen ? 'mobile-open' : ''}`}>
      <div className="brand">{company.logo ? <img src={company.logo} alt="logo"/> : <div className="brandmark">BB</div>}<div><strong>{company.name}</strong><span>Vendor Operations</span></div></div>
      <div className="user-card"><strong>{user.name}</strong><span>{user.role}</span><small>{firebaseEnabled ? user.email : 'Demo mode'}</small></div><ConnectionStatus/>
      <nav>{allowedNav.map(({to,label,icon:Icon}) => <NavLink key={to} to={to} end={to === '/'} onClick={() => setMenuOpen(false)}><Icon size={18}/>{label}</NavLink>)}</nav>
      <button className="logout-button" onClick={logout}><LogOut size={18}/> Sign out</button>
    </aside>
    <main className="content">{children}</main>
  </div>;
}
