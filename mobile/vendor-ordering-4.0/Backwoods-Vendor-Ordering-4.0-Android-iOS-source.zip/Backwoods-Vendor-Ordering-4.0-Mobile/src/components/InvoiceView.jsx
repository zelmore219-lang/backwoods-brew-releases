import { money, calcOrder } from '../lib/helpers';

export default function InvoiceView({ order, customer, company }) {
  const totals = calcOrder(order);
  const delivered=(order.items||[]).filter(i=>Number(i.invoiceQty??i.deliveredQty??i.qty)>0);
  const returned=(order.items||[]).filter(i=>Number(i.returnQty)>0);
  return <div className="invoice" id={`invoice-${order.id}`}>
    <div className="invoice-head"><div>{company.logo&&<img className="invoice-logo" src={company.logo} alt="logo"/>}<h1>{company.name}</h1><p>{[company.address,[company.city,company.state,company.zip].filter(Boolean).join(' ')].filter(Boolean).map((line,i)=><span key={i}>{line}<br/></span>)}{company.phone}<br/>{company.email}</p></div><div className="invoice-meta"><h2>INVOICE</h2><p><b>{order.invoiceNumber||order.orderNumber}</b><br/>Date: {new Date(order.createdAt).toLocaleDateString()}<br/>Status: {order.status}</p></div></div>
    <div className="invoice-grid"><div><b>Bill To</b><p>{customer?.name}<br/>{customer?.contact}<br/>{customer?.address}<br/>{customer?.phone}</p></div><div><b>Terms</b><p>{customer?.terms}<br/>Salesperson: {order.salesperson||'Unassigned'}<br/>Driver: {order.driver||'Unassigned'}</p></div></div>
    <h3>Merchandise delivered</h3>
    <table><thead><tr>{company.showSku!==false&&<th>SKU</th>}<th>Description</th><th>Qty brought in</th><th>Price</th><th>Total</th></tr></thead><tbody>{delivered.map(i=>{const q=Number(i.invoiceQty??i.deliveredQty??i.qty);return <tr key={i.productId}>{company.showSku!==false&&<td>{i.sku}</td>}<td>{i.name}</td><td>{q}</td><td>{money(i.price)}</td><td>{money(q*Number(i.price))}</td></tr>})}{!delivered.length&&<tr><td colSpan="5">No merchandise delivered.</td></tr>}</tbody></table>
    <h3 className="invoice-return-heading">Returns from store</h3>
    <table className="invoice-returns"><thead><tr>{company.showSku!==false&&<th>SKU</th>}<th>Description</th><th>Qty returned</th><th>Credit each</th><th>Reason / disposition</th><th>Credit</th></tr></thead><tbody>{returned.map(i=><tr key={i.productId}>{company.showSku!==false&&<td>{i.sku}</td>}<td>{i.name}</td><td>{Number(i.returnQty)}</td><td>{money(i.returnPrice??i.price)}</td><td>{i.returnReason||'Return'}<small>{(i.returnDisposition||'sellable').replaceAll('_',' ')} · {Number(i.returnCreditPercent??100)}% credit</small></td><td>-{money(Number(i.returnQty)*Number(i.returnPrice??i.price)*(Number(i.returnCreditPercent??100)/100))}</td></tr>)}{!returned.length&&<tr><td colSpan="6">No returns.</td></tr>}</tbody></table>
    <div className="totals"><p><span>Delivered merchandise</span><b>{money(totals.subtotal)}</b></p><p><span>Returns</span><b>-{money(totals.returnTotal)}</b></p><p><span>Other credits</span><b>-{money(totals.creditTotal)}</b></p><p><span>Tax</span><b>{money(totals.tax)}</b></p><p className="grand"><span>Net invoice total</span><b>{money(totals.total)}</b></p><p><span>Paid</span><b>{money(totals.paid)}</b></p><p className="grand"><span>Balance</span><b>{money(totals.balance)}</b></p></div>
    {order.deliveryNotes&&<p><b>Delivery notes:</b> {order.deliveryNotes}</p>}{company.paymentInstructions&&<p><b>Payment instructions:</b> {company.paymentInstructions}</p>}
    {company.showSignature!==false&&order.signature&&<div className="signature"><b>Received by:</b><br/><img src={order.signature} alt="signature"/><p>{order.signedBy||''}</p></div>}
    <p className="invoice-note">{company.invoiceFooter||'Thank you for your business.'}</p>
  </div>;
}
