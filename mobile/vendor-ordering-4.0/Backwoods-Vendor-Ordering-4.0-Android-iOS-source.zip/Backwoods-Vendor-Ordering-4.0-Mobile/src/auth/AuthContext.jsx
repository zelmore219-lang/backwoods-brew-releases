import { createContext, useContext, useEffect, useMemo, useState } from 'react';
import {
  onAuthStateChanged,
  signInWithEmailAndPassword,
  signOut as firebaseSignOut
} from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { auth, db, firebaseEnabled } from '../lib/firebase';

const AuthContext = createContext(null);
const DEMO_KEY = 'backwoods_vendor_demo_user';

const demoUsers = {
  owner: { uid: 'demo-owner', email: 'owner@demo.local', name: 'Demo Owner', role: 'owner' },
  manager: { uid: 'demo-manager', email: 'manager@demo.local', name: 'Demo Manager', role: 'manager' },
  sales: { uid: 'demo-sales', email: 'sales@demo.local', name: 'Demo Salesperson', role: 'sales' },
  packer: { uid: 'demo-packer', email: 'packer@demo.local', name: 'Demo Packer', role: 'packer' },
  driver: { uid: 'demo-driver', email: 'driver@demo.local', name: 'Demo Driver', role: 'driver' },
  accounting: { uid: 'demo-accounting', email: 'accounting@demo.local', name: 'Demo Accounting', role: 'accounting' },
  customer: { uid: 'demo-customer', email: 'orders@pinehill.example', name: 'Pine Hill Market', role: 'customer', customerId: 'c1' }
};

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(firebaseEnabled);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!user) return undefined;
    const timeoutMinutes = Math.max(5, Number(import.meta.env.VITE_SESSION_TIMEOUT_MINUTES || 60));
    let timer;
    const reset = () => {
      clearTimeout(timer);
      timer = setTimeout(() => logout(), timeoutMinutes * 60 * 1000);
    };
    const events = ['mousemove','mousedown','keydown','touchstart','scroll'];
    events.forEach(event => window.addEventListener(event, reset, { passive:true }));
    reset();
    return () => { clearTimeout(timer); events.forEach(event => window.removeEventListener(event, reset)); };
  }, [user]);

  useEffect(() => {
    if (!firebaseEnabled) {
      const saved = localStorage.getItem(DEMO_KEY);
      setUser(saved ? JSON.parse(saved) : null);
      setLoading(false);
      return undefined;
    }

    return onAuthStateChanged(auth, async firebaseUser => {
      setError('');
      if (!firebaseUser) {
        setUser(null);
        setLoading(false);
        return;
      }

      try {
        const profileRef = doc(db, 'vendorUsers', firebaseUser.uid);
        let profileSnap = await getDoc(profileRef);

        // Secure first-owner bootstrap for the existing Backwoods Brew admin account.
        if (!profileSnap.exists() && firebaseUser.email?.toLowerCase() === 'admin@backwoodsbrew-e3584-d52a3.firebaseapp.com') {
          await setDoc(profileRef, {
            name: 'Backwoods Brew Admin',
            email: firebaseUser.email,
            role: 'owner',
            active: true,
            createdAt: new Date().toISOString(),
            bootstrapOwner: true
          });
          profileSnap = await getDoc(profileRef);
        }

        const profile = profileSnap.exists() ? profileSnap.data() : {};
        setUser({
          uid: firebaseUser.uid,
          email: firebaseUser.email,
          name: profile.name || firebaseUser.displayName || firebaseUser.email,
          role: profile.role || 'pending',
          active: profile.active !== false,
          customerId: profile.customerId || ''
        });
      } catch (err) {
        setError('Signed in, but the user profile could not be loaded.');
        setUser({ uid: firebaseUser.uid, email: firebaseUser.email, name: firebaseUser.email, role: 'pending', active: true });
      } finally {
        setLoading(false);
      }
    });
  }, []);

  const login = async (username, password) => {
    setError('');
    if (!firebaseEnabled) throw new Error('Use a demo role until Firebase is configured.');
    try {
      const value = String(username || '').trim().toLowerCase();
      const loginDomain = String(import.meta.env.VITE_LOGIN_EMAIL_DOMAIN || 'backwoodsbrew-e3584-d52a3.firebaseapp.com').trim().toLowerCase();
      const loginEmail = value.includes('@') ? value : `${value}@${loginDomain}`;
      await signInWithEmailAndPassword(auth, loginEmail, password);
    } catch (err) {
      const friendly = err.code === 'auth/invalid-credential'
        ? 'The username or password is incorrect.'
        : 'Unable to sign in. Check your Firebase settings and try again.';
      setError(friendly);
      throw new Error(friendly);
    }
  };

  const demoLogin = role => {
    const demoUser = demoUsers[role];
    localStorage.setItem(DEMO_KEY, JSON.stringify(demoUser));
    setUser(demoUser);
  };

  const logout = async () => {
    if (firebaseEnabled) await firebaseSignOut(auth);
    localStorage.removeItem(DEMO_KEY);
    setUser(null);
  };

  const value = useMemo(() => ({ user, loading, error, login, demoLogin, logout, firebaseEnabled }), [user, loading, error]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const value = useContext(AuthContext);
  if (!value) throw new Error('useAuth must be used inside AuthProvider');
  return value;
}
