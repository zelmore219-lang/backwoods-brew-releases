import test from 'node:test';
import assert from 'node:assert/strict';
import { DeviceSync, cacheKey, queueKey, scopeKey } from '../src/lib/deviceSync.js';
const clone=value=>JSON.parse(JSON.stringify(value));
class Storage {
  values=new Map();
  getItem(key){return this.values.get(key)??null;}
  setItem(key,value){if(this.full)throw new Error('Storage quota exceeded');this.values.set(key,value);}
}
class Cloud {
  data={products:[{id:'coffee',name:'Coffee',price:8,stock:10},{id:'soap',name:'Soap',price:4}],orders:[],company:{name:'Shared company'}};
  listeners=new Set(); writes=[];
  transport(){
    const client={online:true,authorized:true,deny:null,hold:null};
    const snapshot=name=>name==='company'?{fromCache:false,exists:true,value:clone(this.data.company)}:{fromCache:false,exists:true,rows:clone(this.data[name]||[])};
    const publish=name=>{for(const listener of this.listeners)if(listener.name===name)listener.next(snapshot(name));};
    return {client,
      online:()=>client.online,canWrite:()=>client.authorized,
      listen:(name,next,error)=>{const listener={name,next,error};this.listeners.add(listener);next(snapshot(name));return()=>this.listeners.delete(listener);},
      write:async operation=>{
        if(client.deny===operation.name)throw Object.assign(new Error('Permission denied'),{code:'permission-denied'});
        this.writes.push(clone(operation));
        if(client.hold){const hold=client.hold;client.hold=null;await hold;}
        const rows=operation.name==='company'?new Map([['company',this.data.company]]):new Map((this.data[operation.name]||[]).map(row=>[row.id,row]));
        if(operation.deleted)rows.delete(operation.id);
        else{
          const next={...(rows.get(operation.id)||{}),...clone(operation.fields)};
          if(operation.name!=='company')next.id=operation.id;
          operation.removed.forEach(field=>delete next[field]);rows.set(operation.id,next);
        }
        if(operation.name==='company')this.data.company=rows.get('company')||{};else this.data[operation.name]=[...rows.values()];
        publish(operation.name);
      },
      publish,
    };
  }
}
function device(cloud,options={}){
 const storage=options.storage||new Storage();const transport=cloud.transport();let data;let status;
 const scope=scopeKey('test-project',options.uid||'owner');
 const engine=new DeviceSync({storage,scope,transport,initialData:options.initial||{products:[],orders:[],company:{}},onData:next=>data=next,onState:next=>status=next});
 engine.start(['products','orders']);
 return {engine,storage,transport,get data(){return data;},get status(){return status;},scope};
}
const changeProduct=(id,fields)=>data=>({...data,products:data.products.map(row=>row.id===id?{...row,...fields}:row)});

test('a product edit replicates to a second device and a second order replicates back',async()=>{
 const cloud=new Cloud(),a=device(cloud),b=device(cloud);
 await a.engine.update(changeProduct('coffee',{price:9}));
 assert.equal(b.data.products.find(row=>row.id==='coffee').price,9);
 await b.engine.update(data=>({...data,orders:[...data.orders,{id:'order-b',total:18}]}));
 assert.equal(a.data.orders[0].id,'order-b');assert.equal(a.status.pendingCount,0);assert.equal(b.status.pendingCount,0);
});
test('an offline device uploads only its edit and does not revert another device’s field',async()=>{
 const cloud=new Cloud(),a=device(cloud),b=device(cloud);
 a.transport.client.online=false;
 await a.engine.update(changeProduct('coffee',{stock:7}));
 await b.engine.update(changeProduct('coffee',{price:12}));
 assert.equal(a.data.products.find(row=>row.id==='coffee').price,12);
 assert.equal(a.data.products.find(row=>row.id==='coffee').stock,7);
 a.transport.client.online=true;await a.engine.flush();
 const row=cloud.data.products.find(row=>row.id==='coffee');assert.equal(row.price,12);assert.equal(row.stock,7);
 assert.deepEqual(cloud.writes.at(-1).fields,{stock:7});
});
test('an unrelated pending edit never blocks incoming orders or deletions',async()=>{
 const cloud=new Cloud(),a=device(cloud),b=device(cloud);
 a.transport.client.online=false;await a.engine.update(changeProduct('coffee',{stock:6}));
 await b.engine.update(data=>({...data,products:data.products.filter(row=>row.id!=='soap'),orders:[{id:'new-order',total:4}]}));
 assert.equal(a.data.products.some(row=>row.id==='soap'),false);assert.equal(a.data.orders[0].id,'new-order');
 a.transport.client.online=true;await a.engine.flush();assert.equal(cloud.data.products.some(row=>row.id==='soap'),false);
});
test('offline deletions stay deleted and do not resend unrelated cached rows',async()=>{
 const cloud=new Cloud(),a=device(cloud),b=device(cloud);
 a.transport.client.online=false;await a.engine.update(data=>({...data,products:data.products.filter(row=>row.id!=='soap')}));
 await b.engine.update(changeProduct('coffee',{price:14}));a.transport.client.online=true;await a.engine.flush();
 assert.deepEqual(cloud.data.products,[{id:'coffee',name:'Coffee',price:14,stock:10}]);
});
test('the persisted outbox survives an app restart and drains after reconnect',async()=>{
 const cloud=new Cloud(),a=device(cloud);a.transport.client.online=false;
 await a.engine.update(data=>({...data,orders:[{id:'offline-order',total:16}]}));
 a.engine.stop();const restarted=device(cloud,{storage:a.storage,initial:JSON.parse(a.storage.getItem(cacheKey(a.scope)))});
 await restarted.engine.flush();assert.equal(cloud.data.orders[0].id,'offline-order');assert.equal(restarted.status.pendingCount,0);
});
test('editing while a write is in flight cannot clear the newer edit',async()=>{
 const cloud=new Cloud(),a=device(cloud);let release;
 a.transport.client.hold=new Promise(resolve=>release=resolve);
 const first=a.engine.update(changeProduct('coffee',{price:9}));
 const second=a.engine.update(changeProduct('coffee',{price:11}));
 release();await Promise.all([first,second]);
 assert.equal(cloud.data.products.find(row=>row.id==='coffee').price,11);assert.equal(a.status.pendingCount,0);
});
test('permission failures retain changes and identify the denied collection until retry succeeds',async()=>{
 const cloud=new Cloud(),a=device(cloud);a.transport.client.deny='products';
 await a.engine.update(changeProduct('coffee',{price:10}));
 assert.equal(a.status.mode,'error');assert.equal(a.status.pendingCount,1);assert.equal(a.status.errors[0].path,'vendorProducts');
 a.transport.client.deny=null;await a.engine.flush();assert.equal(a.status.mode,'synced');assert.equal(a.status.pendingCount,0);
});
test('a stale cache never publishes itself or resurrects deleted records on login',async()=>{
 const cloud=new Cloud();const a=device(cloud,{initial:{products:[{id:'old',price:100},{id:'coffee',price:2}],orders:[],company:{name:'stale'}}});
 await a.engine.flush();assert.equal(cloud.writes.length,0);assert.equal(a.data.products.some(row=>row.id==='old'),false);assert.equal(a.data.company.name,'Shared company');
});
test('one account’s queue is never uploaded while another account signs in',async()=>{
 const cloud=new Cloud(),a=device(cloud,{uid:'user-a'});a.transport.client.authorized=false;
 await a.engine.update(changeProduct('coffee',{price:15}));a.engine.stop();
 const b=device(cloud,{storage:a.storage,uid:'user-b'});await b.engine.flush();
 assert.equal(cloud.writes.length,0);assert.equal(b.status.pendingCount,0);assert.equal(JSON.parse(a.storage.getItem(queueKey(a.scope))).length,1);
});
test('removed fields and changed nested objects are sent explicitly',async()=>{
 const cloud=new Cloud(),a=device(cloud);
 await a.engine.update(data=>({...data,products:data.products.map(row=>row.id==='coffee'?{id:row.id,price:row.price,stock:row.stock,options:{size:'large'}}:row)}));
 assert.equal('name' in cloud.data.products[0],false);assert.deepEqual(cloud.data.products[0].options,{size:'large'});
 assert.deepEqual(cloud.writes[0].removed,['name']);
});
test('a write to one collection can succeed while a different collection is denied',async()=>{
 const cloud=new Cloud(),a=device(cloud);a.transport.client.deny='products';
 await a.engine.update(data=>({...changeProduct('coffee',{stock:8})(data),orders:[{id:'order-ok',total:10}]}));
 assert.equal(cloud.data.orders[0].id,'order-ok');assert.equal(a.status.pendingCount,1);assert.equal(a.data.products[0].stock,8);
});
test('storage failure prevents an edit from being reported as saved',async()=>{
 const cloud=new Cloud(),a=device(cloud);a.storage.full=true;
 assert.throws(()=>a.engine.update(changeProduct('coffee',{price:20})),/quota/);
 assert.equal(a.data.products[0].price,8);assert.equal(cloud.writes.length,0);
});
test('receiving an empty cache result does not erase the persisted device cache',()=>{
 const storage=new Storage();let visible;
 const transport={online:()=>false,canWrite:()=>true,listen:(name,next)=>{next({fromCache:true,exists:false,rows:[]});return()=>{};}};
 const engine=new DeviceSync({storage,scope:'cache-only',initialData:{products:[{id:'local'}],company:{}},transport,onData:data=>visible=data});
 engine.start(['products']);assert.equal(visible.products[0].id,'local');
});
test('unsubscribed devices stop receiving further changes',async()=>{
 const cloud=new Cloud(),a=device(cloud),b=device(cloud);a.engine.stop();
 await b.engine.update(changeProduct('coffee',{price:21}));assert.equal(a.data.products[0].price,8);
});

test('a new offline invoice on each installation has a different business number',async()=>{
 const {nextBusinessNumbers}=await import('../src/lib/helpers.js');
 const first=new Storage(),second=new Storage();
 const previous=globalThis.localStorage;
 try{
  globalThis.localStorage=first;
  const a=nextBusinessNumbers({company:{invoicePrefix:'INV',orderPrefix:'ORD',nextInvoiceNumber:1001},orders:[]});
  globalThis.localStorage=second;
  const b=nextBusinessNumbers({company:{invoicePrefix:'INV',orderPrefix:'ORD',nextInvoiceNumber:1001},orders:[]});
  assert.notEqual(a.invoiceNumber,b.invoiceNumber);assert.notEqual(a.orderNumber,b.orderNumber);
  globalThis.localStorage=first;
  const c=nextBusinessNumbers({company:{invoicePrefix:'INV',orderPrefix:'ORD',nextInvoiceNumber:1001},orders:[]});
  assert.notEqual(a.invoiceNumber,c.invoiceNumber);
 }finally{globalThis.localStorage=previous;}
});

test('pending edits remain visibly queued when an edited record was deleted remotely',async()=>{
 const cloud=new Cloud(),a=device(cloud),b=device(cloud);
 const write=a.transport.write;
 a.transport.write=async operation=>{
  if(!operation.created&&!(cloud.data[operation.name]||[]).some(row=>row.id===operation.id))throw Object.assign(new Error('This record was removed on another device.'),{code:'not-found'});
  return write(operation);
 };
 a.transport.client.online=false;await a.engine.update(changeProduct('coffee',{price:11}));
 await b.engine.update(data=>({...data,products:data.products.filter(row=>row.id!=='coffee')}));
 a.transport.client.online=true;await a.engine.flush();
 assert.equal(cloud.data.products.some(row=>row.id==='coffee'),false);assert.equal(a.status.mode,'error');assert.equal(a.status.pendingCount,1);
 assert.equal(a.data.products.find(row=>row.id==='coffee').name,'Coffee');
});

test('cache-only snapshots cannot be reported as a confirmed Firebase connection',()=>{
 const cloud=new Cloud(),a=device(cloud);
 assert.equal(a.status.mode,'synced');
 for(const listener of cloud.listeners)if(listener.name==='products')listener.next({fromCache:true,exists:true,rows:clone(cloud.data.products)});
 assert.equal(a.status.mode,'connecting');
});
