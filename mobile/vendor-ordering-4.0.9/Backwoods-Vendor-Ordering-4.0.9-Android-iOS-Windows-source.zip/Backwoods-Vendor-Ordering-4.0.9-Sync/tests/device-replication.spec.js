import {readFile} from 'node:fs/promises';
import {test,expect} from '@playwright/test';
const clone=value=>JSON.parse(JSON.stringify(value));

async function setup(browser){
 const cloud={products:[{id:'coffee',name:'Coffee',price:8,stock:10},{id:'soap',name:'Soap',price:4}],orders:[],company:{name:'Sync test company'}};
 const pages=[];const contexts=[];const writes=[];
 const snapshot=name=>name==='company'?{fromCache:false,exists:true,value:clone(cloud.company)}:{fromCache:false,exists:true,rows:clone(cloud[name]||[])};
 async function publish(name){
  await Promise.all(pages.map(page=>page.evaluate(({name,snapshot})=>{if(window.__online)window.__listeners?.[name]?.(snapshot);},{name,snapshot:snapshot(name)})));
 }
 async function addDevice(){
  const context=await browser.newContext();contexts.push(context);const page=await context.newPage();pages.push(page);
  await page.addInitScript(()=>{window.__online=true;window.__listeners={};});
  await page.exposeFunction('__subscribe',name=>snapshot(name));
  await page.exposeFunction('__write',async operation=>{
   writes.push(clone(operation));const rows=new Map((cloud[operation.name]||[]).map(row=>[row.id,row]));
   if(operation.name==='company')cloud.company={...cloud.company,...operation.fields};
   else if(operation.deleted){rows.delete(operation.id);cloud[operation.name]=[...rows.values()];}
   else{
    if(!operation.created&&!rows.has(operation.id))throw new Error('Record deleted');
    const row={...(rows.get(operation.id)||{}),...operation.fields,id:operation.id};operation.removed.forEach(key=>delete row[key]);rows.set(operation.id,row);cloud[operation.name]=[...rows.values()];
   }
   await publish(operation.name);
  });
  await page.route('**/src/auth/AuthContext.jsx',route=>route.fulfill({contentType:'text/javascript',body:`export const useAuth=()=>({user:{uid:'test-owner',role:'owner',active:true,email:'owner@sync.test'}});`}));
  await page.route('**/src/lib/firebase.js',route=>route.fulfill({contentType:'text/javascript',body:`export const firebaseEnabled=true;export const firebaseConfig={projectId:'local-sync-test'};`}));
  await page.route('**/src/lib/firebaseSync.js',route=>route.fulfill({contentType:'text/javascript',body:`
   export const readableLists=()=>['products','orders'];
   export const firebaseTransport=()=>({canWrite:()=>true,online:()=>window.__online,
    listen(name,next){window.__listeners[name]=next;window.__subscribe(name).then(value=>{if(window.__listeners[name]===next)next({...value,fromCache:!window.__online});});return()=>{if(window.__listeners[name]===next)delete window.__listeners[name];};},
    write:operation=>window.__write(operation)
   });`}));
  await page.goto('/tests/sync-harness.html');await expect(page.getByTestId('price')).toHaveText('8');return page;
 }
 const a=await addDevice(),b=await addDevice();
 return {a,b,cloud,writes,close:()=>Promise.all(contexts.map(context=>context.close()))};
}

test('two actual React stores replicate independent edits and preserve offline changes after reconnect',async({browser})=>{
 const {a,b,cloud,writes,close}=await setup(browser);
 try{
  await a.evaluate(()=>{window.__online=false;window.dispatchEvent(new Event('offline'));});
  await a.getByRole('button',{name:'Stock 7'}).click();await expect(a.getByTestId('pending')).toHaveText('1');
  await b.getByRole('button',{name:'Price 12'}).click();await expect(b.getByTestId('pending')).toHaveText('0');
  await b.getByRole('button',{name:'Delete soap'}).click();
  await a.getByRole('button',{name:'Add order'}).click();
  await b.getByRole('button',{name:'Add order'}).click();
  await a.evaluate(()=>{window.__online=true;window.dispatchEvent(new Event('online'));});
  await expect(a.getByTestId('mode')).toHaveText('synced');await expect(a.getByTestId('price')).toHaveText('12');
  await expect(b.getByTestId('stock')).toHaveText('7');await expect(a.getByTestId('products')).toHaveText('coffee');
  await expect.poll(()=>cloud.orders.length).toBe(2);await expect(a.getByTestId('orders')).toHaveText(cloud.orders.map(row=>row.id).sort().join(','));
  const stockWrite=writes.find(op=>op.fields.stock===7);expect(stockWrite.fields).toEqual({stock:7});
 }finally{await close();}
});

test('a React client restores its persisted outbox after an offline reload',async({browser})=>{
 const {a,b,cloud,close}=await setup(browser);
 try{
  await a.evaluate(()=>{window.__online=false;window.dispatchEvent(new Event('offline'));});
  await a.getByRole('button',{name:'Add order'}).click();await expect(a.getByTestId('pending')).toHaveText('1');
  await a.reload();await expect(a.getByTestId('pending')).toHaveText('0');
  await expect.poll(()=>cloud.orders.length).toBe(1);await expect(b.getByTestId('orders')).toHaveText(cloud.orders[0].id);
 }finally{await close();}
});

test('the upgrade recovery export preserves both previous device snapshots without publishing them',async({browser})=>{
 const {a,writes,cloud,close}=await setup(browser);
 try{
  await a.evaluate(()=>{
   localStorage.setItem('backwoods_vendor_app_v2',JSON.stringify({company:{name:'Old cache'},products:[{id:'old-product',name:'Original cached product'}]}));
   localStorage.setItem('backwoods_vendor_pending_sync_v1',JSON.stringify({savedAt:'old',data:{company:{name:'Pending snapshot'},orders:[{id:'old-unsent-order'}]},deleted:{products:['deleted-id']}}));
  });
  await a.reload();await expect(a.getByRole('button',{name:'Export previous device backup'})).toBeVisible();
  const downloadPromise=a.waitForEvent('download');await a.getByRole('button',{name:'Export previous device backup'}).click();
  const download=await downloadPromise;const backup=JSON.parse(await readFile(await download.path(),'utf8'));
  expect(backup.previousDeviceCache.products[0].id).toBe('old-product');
  expect(backup.previousPendingSnapshot.data.orders[0].id).toBe('old-unsent-order');
  expect(backup.previousPendingSnapshot.deleted.products).toEqual(['deleted-id']);
  expect(writes).toHaveLength(0);expect(cloud.orders).toHaveLength(0);
  a.once('dialog',dialog=>dialog.accept());await a.getByRole('button',{name:'Remove old copy after backup'}).click();
  expect(await a.evaluate(()=>localStorage.getItem('backwoods_vendor_app_v2'))).toBeNull();
  expect(await a.evaluate(()=>Object.keys(localStorage).some(key=>key.startsWith('backwoods_vendor_cache_v3_')))).toBe(true);
 }finally{await close();}
});
