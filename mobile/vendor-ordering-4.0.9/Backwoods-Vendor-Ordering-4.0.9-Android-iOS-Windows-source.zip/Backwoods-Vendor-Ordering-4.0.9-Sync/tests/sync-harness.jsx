import DeviceSync from '../src/pages/DeviceSync';
import React from 'react';
import {createRoot} from 'react-dom/client';
import {useStore} from '../src/lib/store';
function Harness(){
 const store=useStore();
 const product=store.data.products.find(row=>row.id==='coffee');
 return <><output data-testid="price">{product?.price}</output><output data-testid="stock">{product?.stock}</output><output data-testid="pending">{store.syncStatus.pendingCount}</output><output data-testid="mode">{store.syncStatus.mode}</output><output data-testid="orders">{store.data.orders.map(row=>row.id).sort().join(',')}</output><output data-testid="products">{store.data.products.map(row=>row.id).sort().join(',')}</output>
 <button onClick={()=>store.update(d=>({...d,products:d.products.map(row=>row.id==='coffee'?{...row,price:12}:row)}))}>Price 12</button>
 <button onClick={()=>store.update(d=>({...d,products:d.products.map(row=>row.id==='coffee'?{...row,stock:7}:row)}))}>Stock 7</button>
 <button onClick={()=>store.update(d=>({...d,orders:[...d.orders,{id:'order-'+crypto.randomUUID(),total:24}]}))}>Add order</button>
 <button onClick={()=>store.update(d=>({...d,products:d.products.filter(row=>row.id!=='soap')}))}>Delete soap</button>
 <DeviceSync {...store}/></>;
}
createRoot(document.getElementById('root')).render(<Harness/>);
