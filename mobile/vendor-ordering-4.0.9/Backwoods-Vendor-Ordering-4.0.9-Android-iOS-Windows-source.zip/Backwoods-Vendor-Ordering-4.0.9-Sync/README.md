# Backwoods Vendor Ordering 4.0.9

Device-to-device sync update for the recovered Vendor Ordering 4.0.8 app. See **SYNC-UPDATE-4.0.9.md** before upgrading Android and Windows; update every Vendor Ordering device.

- Android: install the 4.0.9 APK as an update without uninstalling.
- Windows: run the new 4.0.9 portable executable instead of the old shortcut.
- Open Device Sync, sign in to the same Firebase project with your assigned company account, and wait for Firebase connected / zero pending records.
- Export previous-device data before recovering missing records. Existing cloud records are kept when recovering.

The original main-app accounting integration is outside this update; the main app was left unchanged.

Build: `npm ci`, `npm run test:sync`, `npm run test:mobile`, `npm run mobile:sync`.

Android: `npm run android:apk`. Windows on Windows: `npm run desktop:win`; portable: `npm run desktop:portable`. iOS: `npm run mobile:ios` on a Mac with Xcode/CocoaPods and Apple signing. No signed iOS IPA is included.

MOBILE-BUILD.md has general setup instructions; SYNC-UPDATE-4.0.9.md describes the changed sync/data-recovery behavior. RECOVERY-NOTES.md records the 4.0.8 recovery provenance. No production accounts, credentials, or security rules were changed.
