import { Cloud, CloudOff } from 'lucide-react';
const labels={demo:'Local demo — not shared','signed-out':'Sign in online to sync',offline:'Offline — saved on device',connecting:'Connecting to Firebase',pending:'Changes waiting to upload',error:'Sync needs attention',synced:'Firebase connected'};
export default function ConnectionStatus({status={mode:'connecting'},onRetry}) {
  const good=status.mode==='synced';
  return <div className={`connection-status ${good?'online':'offline'}`} role="status">
    {good?<Cloud size={14}/>:<CloudOff size={14}/>}<span>{labels[status.mode]||'Checking sync'}{status.pendingCount?` (${status.pendingCount})`:''}</span>
    {['error','pending','signed-out'].includes(status.mode)&&onRetry&&<button className="small secondary" onClick={onRetry}>Retry</button>}
  </div>;
}
