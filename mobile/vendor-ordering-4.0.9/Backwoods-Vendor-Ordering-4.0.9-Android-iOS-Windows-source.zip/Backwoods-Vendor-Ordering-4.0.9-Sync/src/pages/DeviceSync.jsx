import { useState } from 'react';
import { useAuth } from '../auth/AuthContext';
import { downloadBlob } from '../lib/catalog';

export default function DeviceSync({syncStatus, retrySync, legacyRecovery, recoverMissing, firebaseEnabled}) {
  const {user}=useAuth();
  const [message,setMessage]=useState('');
  const [busy,setBusy]=useState(false);
  const [exported,setExported]=useState(false);
  const previous=user?.role==='owner'?legacyRecovery():null;
  const exportPrevious=async()=>{
    try{const result=await downloadBlob('backwoods-previous-device-backup.json',JSON.stringify({app:'Backwoods Vendor Ordering',exportedAt:new Date().toISOString(),data:previous,previousDeviceCache:JSON.parse(localStorage.getItem('backwoods_vendor_app_v2')||'null'),previousPendingSnapshot:JSON.parse(localStorage.getItem('backwoods_vendor_pending_sync_v1')||'null')},null,2),'application/json');if(!result?.canceled){setExported(true);setMessage('Save the exported backup outside this app. If storage is full, you can remove the previous device copy after verifying your backup.');}}
    catch(error){setMessage(error.message);}
  };
  const recover=async()=>{
    if(!confirm('Copy records from this device’s previous cache only when their IDs do not already exist in Firebase? Existing cloud records and company settings will stay unchanged.'))return;
    setBusy(true);setMessage('Checking previous records against Firebase...');
    try{const result=await recoverMissing();setMessage(`Recovered ${result.added} missing record(s). Kept ${result.skipped} existing or invalid record(s) unchanged. The original device backup is still available.`);}
    catch(error){setMessage(`Recovery stopped: ${error.message}. The original backup is still available; previously copied records are safe to retry.`);}
    finally{setBusy(false);}
  };
  const removePrevious=()=>{
    if(!confirm('Have you saved and checked the exported previous-device backup? This removes only the old local cache and old snapshot queue to free storage. Cloud data and this version’s pending changes are kept.'))return;
    localStorage.removeItem('backwoods_vendor_app_v2');localStorage.removeItem('backwoods_vendor_pending_sync_v1');
    setMessage('Previous device copy removed. Your exported backup is your recovery copy.');retrySync();
  };
  return <>
    <div className="page-head"><div><h1>Device Sync</h1><p>Share Vendor Ordering data between phones, tablets, and Windows.</p></div><button onClick={retrySync}>Reconnect / Retry sync</button></div>
    <div className="panel"><h2>{syncStatus.mode==='synced'?'Connected to Firebase':syncStatus.mode==='demo'?'Local demo — not shared':syncStatus.mode==='signed-out'?'Sign in online to sync':syncStatus.mode==='offline'?'Offline — changes saved on this device':syncStatus.mode==='error'?'Sync needs attention':syncStatus.pendingCount?'Uploading changes':'Connecting to Firebase'}</h2>
      <p><b>Pending records:</b> {syncStatus.pendingCount}</p>
      <p><b>Account:</b> {syncStatus.email||user?.email||'Not signed in'}</p>
      <p><b>Firebase project:</b> {syncStatus.project||'Not connected'}</p>
      <p><b>Last server update received:</b> {syncStatus.lastReceivedAt?new Date(syncStatus.lastReceivedAt).toLocaleString():'Not yet confirmed'}</p>
      <p><b>Last local change uploaded:</b> {syncStatus.lastSavedAt?new Date(syncStatus.lastSavedAt).toLocaleString():'None in this session'}</p>
      <p>Use company accounts in the same Firebase project on every device. Local demo accounts do not share data. Keep this app open until pending records reach zero and Firebase shows connected.</p>
      {(syncStatus.errors||[]).map((error,index)=><div className="notice" role="alert" key={index}><b>{error.path}</b>: {error.message}{/permission-denied/.test(error.code)&&<p>Your Firebase rules or assigned role denied this collection. An owner must review its access in Firebase; this app cannot change production security rules.</p>}</div>)}
    </div>
    {firebaseEnabled&&previous&&<div className="panel"><h2>Previous device data</h2><p>Your older cache and unsent snapshot are preserved. They are not automatically uploaded over current cloud records. Export a copy before recovering missing records. If an existing cloud record differs from an unsent old edit, review it against the exported backup before changing that record.</p><div className="actions"><button className="secondary" onClick={exportPrevious}>Export previous device backup</button><button disabled={busy||syncStatus.mode==='signed-out'||syncStatus.mode==='offline'} onClick={recover}>Recover missing records</button>{exported&&<button className="secondary" onClick={removePrevious}>Remove old copy after backup</button>}</div></div>}
    {message&&<div className="notice" role="status">{message}</div>}
  </>;
}
