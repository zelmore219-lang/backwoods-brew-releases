import { useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Plus, RotateCcw, Search, Star } from 'lucide-react';
import Modal from '../components/Modal';
import CatalogPhoto from '../components/CatalogPhoto';
import { makeId, nextBusinessNumbers, now, money, calcOrder } from '../lib/helpers';
import { syncClass, syncLabel } from '../lib/syncStatus';
import { availableUnits, catalogDescription, catalogSearchText, isCatalogVisible } from '../lib/catalog';

const lineFor = (product, price, old = {}, includeExistingReservation = false) => {
  const caseQty = Number(product.caseQty || 1);
  const qty = Number(old.qty ?? old.deliveredQty ?? 0);
  const orderUnit = old.orderUnit || 'each';
  const heldUnits = includeExistingReservation ? qty * (orderUnit === 'case' ? caseQty : 1) : 0;

  return {
    productId: product.id,
    sku: product.sku,
    barcode: old.barcode || product.barcode || '',
    upc: old.upc || old.barcode || product.barcode || '',
    name: product.name,
    category: product.category || 'Other',
    subcategory: product.subcategory || 'Other',
    qty,
    returnQty: Number(old.returnQty || 0),
    price: Number(price ?? product.price),
    available: availableUnits(product) + heldUnits,
    caseQty,
    orderUnit,
    returnReason: old.returnReason || '',
    returnDisposition: old.returnDisposition || 'sellable',
    returnCreditPercent: Number(old.returnCreditPercent ?? 100)
  };
};

const units = line => Number(line.qty || 0) * (line.orderUnit === 'case' ? Number(line.caseQty || 1) : 1);
const reservedUnits = line => units(line);
const lineNet = line => units(line) * Number(line.price) - Number(line.returnQty) * Number(line.price) * (Number(line.returnCreditPercent ?? 100) / 100);
const requestedOverAvailable = line => units(line) > Number(line.available || 0);

export default function Orders({ data, update }) {
  const [params] = useSearchParams();
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [customerId, setCustomerId] = useState(data.customers[0]?.id || '');
  const [lines, setLines] = useState([]);
  const [notes, setNotes] = useState('');
  const [error, setError] = useState('');
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');
  const [subcategory, setSubcategory] = useState('All');

  const selectedStore = data.customers.find(c => c.id === customerId);
  const approved = selectedStore?.approvedProductIds || [];
  const selectedRoute = (data.routePlans || []).find(r => r.id === selectedStore?.routeId);
  const catalogProducts = useMemo(() => data.products.filter(isCatalogVisible), [data.products]);

  const categories = useMemo(() => ['All', ...new Set(catalogProducts.map(p => p.category || 'Other'))], [catalogProducts]);
  const subcategories = useMemo(() => [
    'All',
    ...new Set(catalogProducts
      .filter(p => category === 'All' || (p.category || 'Other') === category)
      .map(p => p.subcategory || 'Other'))
  ], [catalogProducts, category]);

  const storePrice = product => selectedStore?.customPrices?.[product.id] !== '' && selectedStore?.customPrices?.[product.id] != null
    ? Number(selectedStore.customPrices[product.id])
    : Number(product.price);

  const shown = useMemo(() => catalogProducts
    .filter(product => (
      (!approved.length || approved.includes(product.id)) &&
      (category === 'All' || (product.category || 'Other') === category) &&
      (subcategory === 'All' || (product.subcategory || 'Other') === subcategory) &&
      catalogSearchText(product).includes(search.toLowerCase())
    ))
    .sort((a, b) =>
      Number((selectedStore?.favoriteProductIds || []).includes(b.id)) - Number((selectedStore?.favoriteProductIds || []).includes(a.id)) ||
      Number(b.featured) - Number(a.featured) ||
      a.name.localeCompare(b.name)
    ),
  [catalogProducts, category, subcategory, search, approved, selectedStore]);

  const activeLines = lines.filter(line => Number(line.qty) > 0 || Number(line.returnQty) > 0);
  const untaxedTotals = calcOrder({ items: activeLines, credits: [], payments: [], tax: 0 });
  const taxRate = selectedStore?.taxExempt ? 0 : Number(selectedStore?.taxRate !== '' && selectedStore?.taxRate != null ? selectedStore.taxRate : data.company.defaultTaxRate || 0);
  const taxAmount = +(untaxedTotals.total * taxRate / 100).toFixed(2);
  const preview = { items: activeLines, credits: [], payments: [], tax: taxAmount };
  const totals = calcOrder(preview);
  const deliveredUnits = activeLines.reduce((sum, line) => sum + units(line), 0);
  const returnedUnits = activeLines.reduce((sum, line) => sum + Number(line.returnQty || 0), 0);
  const hasCreditLimit = Number(selectedStore?.creditLimit || 0) > 0;
  const atCreditLimit = hasCreditLimit && Number(selectedStore?.balance || 0) >= Number(selectedStore?.creditLimit || 0);
  const accountBlocked = Boolean(selectedStore?.accountHold || atCreditLimit);

  const recentOrders = useMemo(() => [...data.orders].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)), [data.orders]);
  const orderStats = useMemo(() => {
    const submitted = data.orders.filter(order => order.status === 'submitted').length;
    const drafts = data.orders.filter(order => order.status === 'draft').length;
    const returns = data.orders.reduce((sum, order) => sum + (order.items || []).reduce((n, item) => n + Number(item.returnQty || 0), 0), 0);
    const sales = data.orders
      .filter(order => !['cancelled', 'void'].includes(order.status))
      .reduce((sum, order) => sum + calcOrder(order).total, 0);
    return { submitted, drafts, returns, sales };
  }, [data.orders]);

  const close = () => {
    setOpen(false);
    setEditing(null);
    setLines([]);
    setNotes('');
    setError('');
    setSearch('');
    setCategory('All');
    setSubcategory('All');
  };

  const buildLines = (order = null, storeId = customerId, includeExistingReservation = false) => data.products.map(product => {
    const old = order?.items?.find(item => item.productId === product.id) || {};
    const customPrices = data.customers.find(c => c.id === storeId)?.customPrices || {};
    return lineFor(product, customPrices[product.id] ?? product.price, old, includeExistingReservation);
  });

  const start = (id = data.customers[0]?.id || '') => {
    setCustomerId(id);
    setLines(buildLines(null, id));
    setOpen(true);
  };

  useEffect(() => {
    const id = params.get('store');
    if (id && data.customers.some(c => c.id === id)) start(id);
  }, []);

  const previous = useMemo(() => data.orders
    .filter(order => order.customerId === customerId && order.status !== 'cancelled')
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))[0],
  [data.orders, customerId]);

  const changeStore = id => {
    setCustomerId(id);
    setLines(buildLines(null, id));
  };

  const setLine = (id, patch) => setLines(current => current.map(line => line.productId === id ? { ...line, ...patch } : line));
  const loadPrevious = () => {
    if (!previous) return;
    setLines(buildLines(previous, customerId).map(line => ({
      ...line,
      returnQty: 0,
      returnReason: '',
      returnDisposition: 'sellable',
      returnCreditPercent: 100
    })));
  };
  const loadFavorites = () => {
    const visibleIds = new Set(catalogProducts.map(product => product.id));
    setLines(buildLines(null, customerId).map(line => (
      visibleIds.has(line.productId) && (selectedStore?.favoriteProductIds || []).includes(line.productId) ? { ...line, qty: 1 } : line
    )));
  };
  const beginEdit = order => {
    setEditing(order);
    setCustomerId(order.customerId);
    setLines(buildLines(order, order.customerId, order.status !== 'draft' && order.status !== 'cancelled'));
    setNotes(order.notes || '');
    setOpen(true);
  };

  const save = (status = 'submitted') => {
    setError('');
    const items = activeLines;
    if (!customerId) return setError('Choose a store.');
    if (!items.length) return setError('Enter at least one delivered or returned quantity.');

    const missingReason = items.find(item => Number(item.returnQty) > 0 && !item.returnReason.trim());
    if (missingReason) return setError(`Choose a return reason for ${missingReason.name}.`);

    const invalidCredit = items.find(item => Number(item.returnQty) > 0 && (Number(item.returnCreditPercent) < 0 || Number(item.returnCreditPercent) > 100));
    if (invalidCredit) return setError(`Return credit for ${invalidCredit.name} must be between 0% and 100%.`);

    update(d => {
      let products = d.products;
      const clean = items.map(({ available, ...item }) => {
        const availableAtOrder = Number(available || 0);
        const orderedUnits = units(item);
        return {
          ...item,
          deliveredQty: Number(item.qty || 0),
          returnQty: Number(item.returnQty || 0),
          returnCreditPercent: Number(item.returnCreditPercent ?? 100),
          orderedUnits,
          availableAtOrder,
          stockException: orderedUnits > availableAtOrder ? 'requested_over_available' : ''
        };
      });

      if (editing) {
        const oldReserving = editing.status !== 'draft' && editing.status !== 'cancelled';
        const newReserving = status !== 'draft';
        products = products.map(product => {
          const old = editing.items.find(item => item.productId === product.id);
          const fresh = items.find(item => item.productId === product.id);
          const release = oldReserving ? reservedUnits(old || {}) : 0;
          const add = newReserving ? reservedUnits(fresh || {}) : 0;
          return { ...product, reserved: Math.max(0, Number(product.reserved || 0) - release + add) };
        });

        return {
          ...d,
          products,
          orders: d.orders.map(order => order.id === editing.id ? {
            ...order,
            customerId,
            routeId: selectedStore?.routeId || '',
            routeName: selectedRoute?.name || '',
            deliveryDay: selectedRoute?.dayOfWeek || '',
            customerName: selectedStore?.name || '',
            terms: selectedStore?.terms || d.company.defaultTerms,
            tax: taxAmount,
            taxRate,
            taxExempt: Boolean(selectedStore?.taxExempt),
            deliveryWindow: selectedStore?.deliveryWindow || '',
            items: clean,
            notes,
            status,
            submittedAt: status === 'submitted' ? (order.submittedAt || now()) : order.submittedAt,
            updatedAt: now()
          } : order)
        };
      }

      const nums = nextBusinessNumbers(d);
      const order = {
        id: makeId('o'),
        orderNumber: nums.orderNumber,
        invoiceNumber: nums.invoiceNumber,
        customerId,
        routeId: selectedStore?.routeId || '',
        routeName: selectedRoute?.name || '',
        deliveryDay: selectedRoute?.dayOfWeek || '',
        customerName: selectedStore?.name || '',
        items: clean,
        status,
        terms: selectedStore?.terms || d.company.defaultTerms,
        createdAt: now(),
        submittedAt: status === 'submitted' ? now() : null,
        updatedAt: now(),
        credits: [],
        payments: [],
        tax: taxAmount,
        taxRate,
        taxExempt: Boolean(selectedStore?.taxExempt),
        deliveryWindow: selectedStore?.deliveryWindow || '',
        salesperson: selectedStore?.salesperson || 'Sales Rep',
        notes
      };

      if (status === 'submitted') {
        products = products.map(product => {
          const item = items.find(line => line.productId === product.id);
          return item ? { ...product, reserved: Number(product.reserved || 0) + reservedUnits(item) } : product;
        });
      }

      return {
        ...d,
        orders: [...d.orders, order],
        products
      };
    });
    close();
  };

  const cancelOrder = order => update(d => ({
    ...d,
    orders: d.orders.map(current => current.id === order.id ? { ...current, status: 'cancelled', updatedAt: now() } : current),
    products: order.status === 'draft'
      ? d.products
      : d.products.map(product => {
        const item = order.items.find(line => line.productId === product.id);
        return item ? { ...product, reserved: Math.max(0, Number(product.reserved || 0) - reservedUnits(item)) } : product;
      })
  }));

  return <>
    <div className="page-head">
      <div><h1>Orders & Returns</h1><p>Store orders, credits, and invoice totals.</p></div>
      <button onClick={() => start()}><Plus size={17}/>New order / return</button>
    </div>

    <div className="order-board">
      <div className="card"><span>Submitted</span><strong>{orderStats.submitted}</strong></div>
      <div className="card"><span>Drafts</span><strong>{orderStats.drafts}</strong></div>
      <div className="card"><span>Returned units</span><strong>{orderStats.returns}</strong></div>
      <div className="card"><span>Order value</span><strong>{money(orderStats.sales)}</strong></div>
    </div>

    <div className="panel table-scroll order-list">
      <table>
        <thead><tr><th>Order</th><th>Store</th><th>Route</th><th>Status</th><th>Main app</th><th>Delivered</th><th>Returned</th><th>Net invoice</th><th></th></tr></thead>
        <tbody>{recentOrders.map(order => {
          const t = calcOrder(order);
          return <tr key={order.id}>
            <td><b>{order.orderNumber}</b><small>{order.invoiceNumber} - {new Date(order.createdAt).toLocaleString()}</small></td>
            <td>{data.customers.find(c => c.id === order.customerId)?.name}</td>
            <td>{order.routeName || 'Unassigned'}<small>{order.deliveryDay || ''}</small></td>
            <td><span className="status">{order.status}</span></td>
            <td><span className={`status ${syncClass(order)}`}>{syncLabel(order)}</span><small>{order.mainAppSyncedAt ? new Date(order.mainAppSyncedAt).toLocaleString() : order.mainAppSyncMessage || ''}</small></td>
            <td>{order.items.reduce((sum, item) => sum + Number(item.qty || 0), 0)}</td>
            <td>{order.items.reduce((sum, item) => sum + Number(item.returnQty || 0), 0)}</td>
            <td>{money(t.total)}</td>
            <td><div className="row-actions">
              {['submitted', 'draft'].includes(order.status) && <button className="small" onClick={() => beginEdit(order)}>Edit</button>}
              {order.status === 'submitted' && <button className="small danger" onClick={() => cancelOrder(order)}>Cancel</button>}
            </div></td>
          </tr>;
        })}</tbody>
      </table>
      {!data.orders.length && <p className="empty">No orders yet.</p>}
    </div>

    {open && <Modal title={editing ? 'Edit order and returns' : 'New order and returns'} wide onClose={close}>
      {error && <div className="alert">{error}</div>}
      {selectedStore && accountBlocked && <div className="alert">This store is on account hold or at its credit limit.</div>}

      <div className="order-entry-layout">
        <section className="order-entry-main">
          <div className="order-shortcuts">
            <button className="secondary" disabled={!previous} onClick={loadPrevious}><RotateCcw size={16}/>Repeat last delivery</button>
            <button className="secondary" disabled={!selectedStore?.favoriteProductIds?.length} onClick={loadFavorites}><Star size={16}/>Load favorites</button>
          </div>

          <div className="order-store-bar">
            <label>Store<select value={customerId} onChange={event => changeStore(event.target.value)}>
              <option value="">Choose store</option>
              {[...data.customers].sort((a, b) => a.name.localeCompare(b.name)).map(customer => <option key={customer.id} value={customer.id}>{customer.name}{customer.storeNumber ? ` #${customer.storeNumber}` : ''}</option>)}
            </select></label>
            <div className="route-preview"><span>Route</span><strong>{selectedRoute ? `${selectedRoute.name} - ${selectedRoute.dayOfWeek}` : 'Not assigned'}</strong></div>
            <label>Notes<input value={notes} onChange={event => setNotes(event.target.value)} placeholder="PO, delivery, or return notes"/></label>
          </div>

          <div className="catalog-filters">
            <label className="search-field"><Search size={16}/><input value={search} onChange={event => setSearch(event.target.value)} placeholder="Search catalog, SKU, or UPC"/></label>
            <select value={category} onChange={event => { setCategory(event.target.value); setSubcategory('All'); }}>{categories.map(item => <option key={item}>{item}</option>)}</select>
            <select value={subcategory} onChange={event => setSubcategory(event.target.value)}>{subcategories.map(item => <option key={item}>{item}</option>)}</select>
          </div>

          <div className="packing-table-wrap">
            <table className="order-return-table">
              <thead><tr><th>Product</th><th>Price</th><th>Deliver</th><th>Return</th><th>Return details</th><th>Net</th></tr></thead>
              <tbody>{shown.map(product => {
                const line = lines.find(item => item.productId === product.id) || lineFor(product, storePrice(product));
                const needsReview = requestedOverAvailable(line);
                return <tr key={product.id} className={`${Number(line.qty) || Number(line.returnQty) ? 'selected-line' : ''} ${needsReview ? 'stock-exception-line' : ''}`}>
                  <td><div className="order-product-cell"><CatalogPhoto product={product} className="mini"/><div><b>{product.name}</b><small>{product.category} / {product.subcategory || 'Other'} - {product.sku}{line.barcode ? ` - UPC ${line.barcode}` : ''} - {line.available} available{needsReview ? ' - warehouse review' : ''}</small><small>{catalogDescription(product)}</small></div></div></td>
                  <td><input className="price" type="number" min="0" step="0.01" value={line.price} onChange={event => setLine(product.id, { price: Number(event.target.value) })}/></td>
                  <td><input className="qty" type="number" min="0" value={line.qty} onChange={event => setLine(product.id, { qty: Math.max(0, Number(event.target.value || 0)) })}/></td>
                  <td><input className="qty return-qty" type="number" min="0" value={line.returnQty} onChange={event => setLine(product.id, { returnQty: Math.max(0, Number(event.target.value || 0)) })}/></td>
                  <td><div className="return-details">
                    <select value={line.returnReason} disabled={!Number(line.returnQty)} onChange={event => setLine(product.id, { returnReason: event.target.value })}>
                      <option value="">Choose reason</option><option>Damaged</option><option>Expired</option><option>Unsold</option><option>Wrong item</option><option>Customer refused</option><option>Other</option>
                    </select>
                    <select value={line.returnDisposition} disabled={!Number(line.returnQty)} onChange={event => setLine(product.id, { returnDisposition: event.target.value })}>
                      <option value="sellable">Return to sellable stock</option><option value="damaged">Damaged stock</option><option value="expired">Expired / discard</option><option value="quarantine">Hold for inspection</option>
                    </select>
                    <label className="credit-percent">Credit %<input type="number" min="0" max="100" value={line.returnCreditPercent} disabled={!Number(line.returnQty)} onChange={event => setLine(product.id, { returnCreditPercent: Number(event.target.value) })}/></label>
                  </div></td>
                  <td><b>{money(lineNet(line))}</b></td>
                </tr>;
              })}</tbody>
            </table>
          </div>
        </section>

        <aside className="order-entry-sidebar">
          <div className="customer-snapshot"><span>Store</span><strong>{selectedStore?.name || 'No store selected'}</strong><small>{selectedStore?.terms || 'Terms not set'}{hasCreditLimit ? ` - ${money(selectedStore.creditLimit)} limit` : ''}</small></div>
          <div className="order-metrics"><div><span>Lines</span><strong>{activeLines.length}</strong></div><div><span>Deliver</span><strong>{deliveredUnits}</strong></div><div><span>Return</span><strong>{returnedUnits}</strong></div></div>
          <div className="active-lines">
            <h4>Active lines</h4>
            {activeLines.slice(0, 8).map(line => <div key={line.productId}><span>{line.name}</span><b>{Number(line.qty || 0)} out / {Number(line.returnQty || 0)} back</b>{requestedOverAvailable(line) && <small>Warehouse review: {line.available} available</small>}</div>)}
            {activeLines.length > 8 && <small>{activeLines.length - 8} more lines</small>}
            {!activeLines.length && <p className="empty compact">No quantities entered.</p>}
          </div>
          <div className="order-return-summary"><div><span>Delivered</span><strong>{money(totals.subtotal)}</strong></div><div><span>Returns</span><strong>-{money(totals.returnTotal)}</strong></div><div><span>Tax</span><strong>{money(taxAmount)}</strong></div><div className="net"><span>Net invoice</span><strong>{money(totals.total)}</strong></div></div>
          <div className="actions order-actions">
            {!editing && <button className="secondary" disabled={!activeLines.length || !customerId} onClick={() => save('draft')}>Save draft</button>}
            <button disabled={!activeLines.length || !customerId || accountBlocked} onClick={() => save('submitted')}>{editing ? (editing.status === 'draft' ? 'Submit order & returns' : 'Save changes') : 'Submit order & returns'}</button>
          </div>
        </aside>
      </div>
    </Modal>}
  </>;
}
