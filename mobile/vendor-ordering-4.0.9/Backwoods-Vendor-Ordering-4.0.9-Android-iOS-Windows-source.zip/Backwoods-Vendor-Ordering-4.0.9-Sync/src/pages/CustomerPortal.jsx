import { useMemo, useState } from 'react';
import { Download, Search, Star } from 'lucide-react';
import { useAuth } from '../auth/AuthContext';
import Modal from '../components/Modal';
import InvoiceView from '../components/InvoiceView';
import CatalogPhoto from '../components/CatalogPhoto';
import { calcOrder, makeId, nextBusinessNumbers, now, money } from '../lib/helpers';
import {
  availableUnits,
  catalogDescription,
  catalogExportRows,
  catalogSearchText,
  downloadCatalogCsv,
  isCatalogVisible
} from '../lib/catalog';

const productPrice = (customer, product) => customer?.customPrices?.[product.id] !== '' && customer?.customPrices?.[product.id] != null
  ? Number(customer.customPrices[product.id])
  : Number(product.price || 0);

const customerTaxRate = (company, customer) => customer?.taxExempt ? 0 : Number(customer?.taxRate !== '' && customer?.taxRate != null ? customer.taxRate : company.defaultTaxRate || 0);
const todayStamp = () => new Date().toISOString().slice(0, 10);

export default function CustomerPortal({ data, update }) {
  const { user } = useAuth();
  const [selectedInvoice, setSelectedInvoice] = useState(null);
  const [repeatOrder, setRepeatOrder] = useState(null);
  const [message, setMessage] = useState('');
  const [quickQty, setQuickQty] = useState({});
  const [catalogSearch, setCatalogSearch] = useState('');
  const [catalogCategory, setCatalogCategory] = useState('All');
  const customer = data.customers.find(c => c.id === user.customerId || c.email?.toLowerCase() === user.email?.toLowerCase());
  const route = (data.routePlans || []).find(r => r.id === customer?.routeId);
  const orders = useMemo(() => data.orders.filter(o => o.customerId === customer?.id).sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt)), [data.orders, customer]);
  const openOrders = orders.filter(o => !['delivered','completed','cancelled','void'].includes(o.status));
  const balance = orders.reduce((sum,o)=>sum+calcOrder(o).balance,0);
  const approvedCredits = data.credits.filter(c=>c.customerId===customer?.id && c.status==='approved').reduce((s,c)=>s+Number(c.amount||0),0);

  const catalogProducts = useMemo(() => {
    if (!customer) return [];
    const approved = customer.approvedProductIds || [];
    return data.products.filter(product => isCatalogVisible(product) && (!approved.length || approved.includes(product.id)));
  }, [customer, data.products]);

  const catalogCategories = useMemo(() => ['All', ...new Set(catalogProducts.map(product => product.category || 'Other'))], [catalogProducts]);

  const products = useMemo(() => {
    const favorites = customer?.favoriteProductIds || [];
    const q = catalogSearch.trim().toLowerCase();
    return catalogProducts
      .filter(product => (
        (catalogCategory === 'All' || (product.category || 'Other') === catalogCategory) &&
        (!q || catalogSearchText(product).includes(q))
      ))
      .sort((a, b) =>
        Number(favorites.includes(b.id)) - Number(favorites.includes(a.id)) ||
        Number(b.featured) - Number(a.featured) ||
        String(a.category || '').localeCompare(String(b.category || '')) ||
        a.name.localeCompare(b.name)
      );
  }, [catalogProducts, catalogCategory, catalogSearch, customer]);

  if (!customer) return <div className="panel"><h1>Customer portal</h1><p>Your account is signed in, but it is not linked to a customer record yet.</p><p>Ask an owner to add <code>customerId</code> to your user profile.</p></div>;

  const buildPortalOrder = (d, items, note, nums) => {
    const untaxed = calcOrder({ items, credits: [], payments: [], tax: 0 });
    const taxRate = customerTaxRate(d.company, customer);
    const tax = +(untaxed.total * taxRate / 100).toFixed(2);
    return {
      id: makeId('o'),
      orderNumber: nums.orderNumber,
      invoiceNumber: nums.invoiceNumber,
      customerId: customer.id,
      customerName: customer.name,
      routeId: customer.routeId || '',
      routeName: route?.name || '',
      deliveryDay: route?.dayOfWeek || '',
      deliveryWindow: customer.deliveryWindow || '',
      items,
      status: 'submitted',
      terms: customer.terms || d.company.defaultTerms,
      createdAt: now(),
      submittedAt: now(),
      updatedAt: now(),
      credits: [],
      payments: [],
      tax,
      taxRate,
      taxExempt: Boolean(customer.taxExempt),
      salesperson: 'Customer portal',
      notes: note,
      source: 'customer_portal'
    };
  };

  const submitItems = (items, note) => {
    const unavailable = items.find(i => {
      const p = data.products.find(x => x.id === i.productId);
      return !p || availableUnits(p) < Number(i.qty || 0);
    });
    if (unavailable) return setMessage(`${unavailable.name} does not have enough available inventory.`);
    update(d => {
      const nums = nextBusinessNumbers(d);
      const order = buildPortalOrder(d, items, note, nums);
      return {
        ...d,
        orders: [...d.orders, order],
        products: d.products.map(p => {
          const line = order.items.find(i => i.productId === p.id);
          return line ? { ...p, reserved: Number(p.reserved || 0) + Number(line.qty || 0) } : p;
        })
      };
    });
    setMessage('Order submitted successfully.');
    return true;
  };

  const submitQuickOrder = () => {
    const items = catalogProducts.map(product => {
      const qty = Math.min(availableUnits(product), Math.max(0, Number(quickQty[product.id] || 0)));
      return qty > 0 ? { productId: product.id, sku: product.sku, barcode: product.barcode || '', upc: product.barcode || '', name: product.name, category: product.category, subcategory: product.subcategory, qty, deliveredQty: qty, price: productPrice(customer, product), caseQty: Number(product.caseQty || 1), orderUnit: 'each' } : null;
    }).filter(Boolean);
    if (!items.length) return setMessage('Enter at least one quantity.');
    if (submitItems(items, 'Customer portal quick order')) setQuickQty({});
  };

  const placeRepeat = () => {
    if (!repeatOrder) return;
    const items = repeatOrder.items.map(i => {
      const product = data.products.find(p => p.id === i.productId);
      const barcode = i.barcode || i.upc || product?.barcode || '';
      return { productId: i.productId, sku: i.sku || product?.sku || '', barcode, upc: barcode, name: i.name || product?.name || '', category: i.category || product?.category, subcategory: i.subcategory || product?.subcategory, qty: Number(i.qty), deliveredQty: Number(i.qty), price: Number(i.price), caseQty: Number(i.caseQty || product?.caseQty || 1), orderUnit: i.orderUnit || 'each' };
    }).filter(i => i.qty > 0);
    if (!items.length) return setMessage('Enter at least one quantity.');
    if (submitItems(items, `Repeat order from ${repeatOrder.orderNumber}`)) setRepeatOrder(null);
  };

  const paymentLink = order => {
    if (!data.company.paymentLinkBase) return '';
    const url = new URL(data.company.paymentLinkBase, window.location.href);
    const totals = calcOrder(order);
    url.searchParams.set('invoice', order.invoiceNumber || '');
    url.searchParams.set('amount', Number(totals.balance || 0).toFixed(2));
    url.searchParams.set('customer', customer.name || '');
    return url.toString();
  };

  const downloadCustomerCatalog = async () => {
    const rows = products.length ? products : catalogProducts;
    try {
      const result = await downloadCatalogCsv(`backwoods-customer-catalog-${todayStamp()}.csv`, catalogExportRows(rows, product => productPrice(customer, product)));
      if (!result?.canceled) setMessage(result?.filePath ? `Saved catalog to ${result.filePath}.` : 'Downloaded catalog price sheet.');
    } catch (error) {
      alert(error.message || 'Could not save the catalog.');
    }
  };

  const quickPreviewItems = catalogProducts.map(product => {
    const qty = Math.min(availableUnits(product), Math.max(0, Number(quickQty[product.id] || 0)));
    return qty > 0 ? { productId: product.id, qty, price: productPrice(customer, product) } : null;
  }).filter(Boolean);
  const quickTaxRate = customerTaxRate(data.company, customer);
  const quickBase = calcOrder({ items: quickPreviewItems, credits: [], payments: [], tax: 0 });
  const quickTax = +(quickBase.total * quickTaxRate / 100).toFixed(2);

  return <>
    <div className="page-head"><div><h1>Welcome, {customer.name}</h1><p>View deliveries, invoices, balances, credits, and place repeat orders.</p></div></div>
    {message && <div className="notice">{message}</div>}
    <div className="stats portal-stats">
      <div className="stat"><span>Open orders</span><strong>{openOrders.length}</strong></div>
      <div className="stat"><span>Account balance</span><strong>{money(balance)}</strong></div>
      <div className="stat"><span>Approved credits</span><strong>{money(approvedCredits)}</strong></div>
      <div className="stat"><span>Terms</span><strong>{customer.terms || '-'}</strong></div>
      <div className="stat"><span>Route</span><strong>{route?.name || 'Unassigned'}</strong></div>
    </div>

    <div className="panel portal-catalog-panel">
      <div className="panel-title catalog-panel-title">
        <div><h2>Live Product Catalog</h2><p>Customer catalog with current prices, photos, and available inventory.</p></div>
        <button className="secondary" disabled={!catalogProducts.length} onClick={downloadCustomerCatalog}><Download size={17}/>Download catalog</button>
      </div>
      <div className="catalog-toolbar">
        <label className="search-field"><Search size={16}/><input value={catalogSearch} onChange={e => setCatalogSearch(e.target.value)} placeholder="Search products, SKU, UPC, or category"/></label>
        <select value={catalogCategory} onChange={event => setCatalogCategory(event.target.value)}>{catalogCategories.map(item => <option key={item}>{item}</option>)}</select>
      </div>
      <div className="portal-catalog-grid">{products.map(product => {
        const available = availableUnits(product);
        const favorite = (customer.favoriteProductIds || []).includes(product.id);
        return <article className="portal-catalog-card" key={product.id}>
          <CatalogPhoto product={product} className="large"/>
          <div className="portal-catalog-body">
            <div className="catalog-card-head">
              <div><h3>{product.name}</h3><small>{product.sku}{product.barcode ? ` - UPC ${product.barcode}` : ''}</small></div>
              {favorite && <span className="catalog-badge"><Star size={12}/>Favorite</span>}
            </div>
            <p>{catalogDescription(product)}</p>
            <div className="portal-catalog-meta"><span>{product.category} / {product.subcategory || 'Other'}</span><span>{available} available</span></div>
            <div className="portal-product-controls">
              <strong>{money(productPrice(customer, product))}</strong>
              <label>Qty<input className="qty" type="number" min="0" max={available} disabled={!available} value={quickQty[product.id] || ''} onChange={e => setQuickQty(q => ({ ...q, [product.id]: Math.min(available, Math.max(0, Number(e.target.value || 0))) }))}/></label>
            </div>
          </div>
        </article>;
      })}</div>
      {!products.length && <div className="empty compact">No catalog products match that search.</div>}
      <div className="order-total"><span>Tax</span><strong>{money(quickTax)}</strong><span>Estimated total</span><strong>{money(quickBase.total + quickTax)}</strong></div>
      <div className="actions"><button disabled={!quickPreviewItems.length} onClick={submitQuickOrder}>Submit quick order</button></div>
    </div>

    <div className="panel"><div className="panel-title"><div><h2>Orders and deliveries</h2><p>Follow each order from submission through delivery.</p></div></div>
      <table><thead><tr><th>Order</th><th>Date</th><th>Status</th><th>Delivery</th><th>Total</th><th>Balance</th><th></th></tr></thead><tbody>{orders.map(o => { const t = calcOrder(o); return <tr key={o.id}><td><b>{o.orderNumber}</b><small>{o.invoiceNumber}</small></td><td>{new Date(o.createdAt).toLocaleDateString()}</td><td><span className="status">{o.status}</span></td><td>{o.deliveryDate ? new Date(`${o.deliveryDate}T12:00:00`).toLocaleDateString() : o.deliveryDay || 'Not scheduled'}<small>{o.routeName || ''}</small></td><td>{money(t.total)}</td><td>{money(t.balance)}</td><td><div className="row-actions"><button className="small secondary" onClick={() => setSelectedInvoice(o)}>Invoice</button>{t.balance > 0 && paymentLink(o) && <a className="button small" href={paymentLink(o)} target="_blank" rel="noreferrer">Pay</a>}<button className="small" disabled={['cancelled','void'].includes(o.status)} onClick={() => setRepeatOrder(JSON.parse(JSON.stringify(o)))}>Repeat</button></div></td></tr>; })}</tbody></table>
      {!orders.length && <p className="empty">No orders have been placed for this account.</p>}
    </div>

    <div className="panel"><h2>Credits</h2><table><thead><tr><th>Date</th><th>Reason</th><th>Status</th><th>Pickup</th><th>Amount</th></tr></thead><tbody>{data.credits.filter(c => c.customerId === customer.id).map(c => <tr key={c.id}><td>{new Date(c.createdAt || Date.now()).toLocaleDateString()}</td><td>{c.reason || 'Store credit'}</td><td><span className="status">{c.status}</span></td><td>{c.pickupRequired ? 'Required' : 'No'}</td><td>{money(c.amount)}</td></tr>)}</tbody></table></div>

    {selectedInvoice && <Modal title={selectedInvoice.invoiceNumber} wide onClose={() => setSelectedInvoice(null)}><InvoiceView order={selectedInvoice} customer={customer} company={data.company}/><div className="actions no-print"><button onClick={() => window.print()}>Print / Save PDF</button></div></Modal>}
    {repeatOrder && <Modal title={`Repeat ${repeatOrder.orderNumber}`} wide onClose={() => setRepeatOrder(null)}>{message && <div className="alert">{message}</div>}<p>Review quantities before submitting a new order.</p><table><thead><tr><th>Product</th><th>Available</th><th>Quantity</th><th>Price</th><th>Total</th></tr></thead><tbody>{repeatOrder.items.map((i, idx) => { const p = data.products.find(x => x.id === i.productId); const available = p ? availableUnits(p) : 0; return <tr key={i.productId}><td><div className="order-product-cell"><CatalogPhoto product={p || i} className="mini"/><div>{i.name}<small>{i.sku}{p ? ` - ${catalogDescription(p)}` : ''}</small></div></div></td><td>{available}</td><td><input className="qty" type="number" min="0" max={available} value={i.qty} onChange={e => setRepeatOrder({ ...repeatOrder, items: repeatOrder.items.map((x, n) => n === idx ? { ...x, qty: Math.min(available, Math.max(0, Number(e.target.value || 0))) } : x) })}/></td><td>{money(i.price)}</td><td>{money(Number(i.qty) * Number(i.price))}</td></tr>; })}</tbody></table><div className="order-total"><span>New order total</span><strong>{money(repeatOrder.items.reduce((s,i) => s + Number(i.qty) * Number(i.price), 0))}</strong></div><div className="actions"><button onClick={placeRepeat}>Submit repeat order</button></div></Modal>}
  </>;
}
