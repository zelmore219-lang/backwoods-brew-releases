import { useMemo, useRef, useState } from 'react';
import { CalendarClock, Download, PlayCircle, RefreshCw, ShieldCheck, Trash2, Upload } from 'lucide-react';
import { calcOrder, makeId, money, nextBusinessNumbers, now } from '../lib/helpers';

const today = () => new Date().toISOString().slice(0, 10);
const daysBetween = (a, b) => Math.floor((new Date(a) - new Date(b)) / 86400000);
const addDays = (value, days) => {
  const date = new Date(`${value || today()}T12:00:00`);
  date.setDate(date.getDate() + Number(days || 0));
  return date.toISOString().slice(0, 10);
};
const nextRunFor = template => addDays(template.nextRun || today(), template.frequency === 'monthly' ? 30 : template.frequency === 'biweekly' ? 14 : 7);
const csvCell = value => `"${String(value ?? '').replaceAll('"', '""')}"`;
const download = (name, text, type = 'text/csv') => {
  const blob = new Blob([text], { type });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = name;
  link.click();
  URL.revokeObjectURL(url);
};
const parseCsv = text => {
  const rows = [];
  let row = [];
  let cell = '';
  let quoted = false;
  for (let i = 0; i < text.length; i += 1) {
    const ch = text[i], next = text[i + 1];
    if (ch === '"' && quoted && next === '"') { cell += '"'; i += 1; }
    else if (ch === '"') quoted = !quoted;
    else if (ch === ',' && !quoted) { row.push(cell.trim()); cell = ''; }
    else if ((ch === '\n' || ch === '\r') && !quoted) {
      if (ch === '\r' && next === '\n') i += 1;
      row.push(cell.trim()); cell = '';
      if (row.some(Boolean)) rows.push(row);
      row = [];
    } else cell += ch;
  }
  if (cell || row.length) { row.push(cell.trim()); if (row.some(Boolean)) rows.push(row); }
  if (rows.length < 2) return [];
  const headers = rows[0].map(value => value.trim());
  return rows.slice(1).map(values => Object.fromEntries(headers.map((header, index) => [header, values[index] ?? ''])));
};

function dueDateFor(order) {
  if (order.dueDate) return order.dueDate;
  const terms = String(order.terms || '').match(/(\d+)/);
  return addDays((order.deliveredAt || order.createdAt || today()).slice(0, 10), terms ? Number(terms[1]) : 0);
}

function buildOrderFromTemplate(template, d) {
  const customer = (d.customers || []).find(row => row.id === template.customerId);
  const route = (d.routePlans || []).find(row => row.id === customer?.routeId);
  const nums = nextBusinessNumbers(d);
  const items = (template.items || []).map(item => {
    const product = (d.products || []).find(row => row.id === item.productId);
    const customPrice = customer?.customPrices?.[item.productId];
    return {
      productId: item.productId,
      sku: product?.sku || item.sku || '',
      barcode: product?.barcode || item.barcode || item.upc || '',
      upc: product?.barcode || item.upc || item.barcode || '',
      name: product?.name || item.name || '',
      category: product?.category || item.category || '',
      subcategory: product?.subcategory || item.subcategory || '',
      qty: Number(item.qty || 0),
      deliveredQty: Number(item.qty || 0),
      price: Number(item.price ?? customPrice ?? product?.price ?? 0),
      caseQty: Number(product?.caseQty || item.caseQty || 1),
      orderUnit: item.orderUnit || 'each',
    };
  }).filter(item => item.qty > 0);
  const base = calcOrder({ items, credits: [], payments: [], tax: 0 });
  const taxRate = customer?.taxExempt ? 0 : Number(customer?.taxRate !== '' && customer?.taxRate != null ? customer.taxRate : d.company?.defaultTaxRate || 0);
  const tax = +(base.total * taxRate / 100).toFixed(2);
  return {
    id: makeId('ord'),
    ...nums,
    customerId: template.customerId,
    customerName: customer?.name || '',
    routeId: customer?.routeId || '',
    routeName: route?.name || '',
    deliveryDay: route?.dayOfWeek || '',
    deliveryWindow: customer?.deliveryWindow || '',
    items,
    status: 'draft',
    terms: customer?.terms || d.company?.defaultTerms || 'Net 14',
    tax,
    taxRate,
    taxExempt: Boolean(customer?.taxExempt),
    createdAt: now(),
    updatedAt: now(),
    notes: `Generated from standing order: ${template.name}`,
    source: 'standing_order',
    recurringOrderId: template.id,
  };
}

export default function LaunchCenter({ data, update }) {
  const [tab, setTab] = useState('aging');
  const [message, setMessage] = useState('');
  const fileRef = useRef();
  const templates = data.recurringOrders || [];
  const activeTemplates = templates.filter(template => template.active !== false);
  const dueTemplates = activeTemplates.filter(template => String(template.nextRun || '') <= today());
  const openOrders = (data.orders || []).filter(order => calcOrder(order).balance > 0 && !['void', 'cancelled'].includes(order.status));
  const aging = useMemo(() => openOrders.map(order => {
    const due = dueDateFor(order);
    const overdue = Math.max(0, daysBetween(today(), due));
    return {
      ...order,
      due,
      balance: calcOrder(order).balance,
      customer: (data.customers || []).find(customer => customer.id === order.customerId)?.name || order.customerName || 'Unknown',
      bucket: overdue <= 0 ? 'Current' : overdue <= 30 ? '1-30' : overdue <= 60 ? '31-60' : overdue <= 90 ? '61-90' : '90+',
    };
  }).sort((a, b) => new Date(a.due) - new Date(b.due)), [data.orders, data.customers]);
  const agingTotals = ['Current', '1-30', '31-60', '61-90', '90+'].map(bucket => ({ bucket, total: aging.filter(row => row.bucket === bucket).reduce((sum, row) => sum + row.balance, 0) }));

  const createTemplate = order => update(d => {
    const customer = (d.customers || []).find(row => row.id === order.customerId);
    const template = {
      id: makeId('rec'),
      name: `${customer?.name || 'Customer'} standing order`,
      customerId: order.customerId,
      items: (order.items || []).map(item => ({
        productId: item.productId,
        sku: item.sku || '',
        barcode: item.barcode || item.upc || '',
        upc: item.upc || item.barcode || '',
        name: item.name || '',
        qty: Number(item.qty || item.invoiceQty || 1),
        price: Number(item.price || 0),
        caseQty: Number(item.caseQty || 1),
        orderUnit: item.orderUnit || 'each',
      })),
      frequency: 'weekly',
      nextRun: addDays(today(), 7),
      active: true,
      createdAt: now(),
    };
    return {
      ...d,
      recurringOrders: [...(d.recurringOrders || []), template],
      auditLogs: [...(d.auditLogs || []), { id: makeId('audit'), action: 'Standing order created', entityId: order.id, createdAt: now() }],
    };
  });

  const generateOne = template => update(d => {
    const order = buildOrderFromTemplate(template, d);
    if (!order.items.length) return d;
    return {
      ...d,
      orders: [...(d.orders || []), order],
      products: (d.products || []).map(product => {
        const line = order.items.find(item => item.productId === product.id);
        return line ? { ...product, reserved: Number(product.reserved || 0) + Number(line.qty || 0) } : product;
      }),
      recurringOrders: (d.recurringOrders || []).map(row => row.id === template.id ? { ...row, lastRun: now(), nextRun: nextRunFor(row) } : row),
      auditLogs: [...(d.auditLogs || []), { id: makeId('audit'), action: 'Standing order generated', entityId: order.id, createdAt: now() }],
    };
  });

  const runDue = async () => {
    let createdCount = 0;
    await update(d => {
    const due = (d.recurringOrders || []).filter(template => template.active !== false && String(template.nextRun || '') <= today());
    let next = { ...d, orders: [...(d.orders || [])], products: [...(d.products || [])], recurringOrders: [...(d.recurringOrders || [])] };
    const created = [];
    due.forEach(template => {
      const order = buildOrderFromTemplate(template, next);
      if (!order.items.length) return;
      created.push(order);
      next = {
        ...next,
        orders: [...next.orders, order],
        products: next.products.map(product => {
          const line = order.items.find(item => item.productId === product.id);
          return line ? { ...product, reserved: Number(product.reserved || 0) + Number(line.qty || 0) } : product;
        }),
        recurringOrders: next.recurringOrders.map(row => row.id === template.id ? { ...row, lastRun: now(), nextRun: nextRunFor(row) } : row),
      };
    });
    createdCount = created.length;
    return {
      ...next,
      auditLogs: [...(next.auditLogs || []), { id: makeId('audit'), action: 'Due standing orders generated', details: `${created.length} order(s)`, createdAt: now() }],
    };
    });
    setMessage(`Generated ${createdCount} draft order(s) from standing orders.`);
  };

  const patchTemplate = (id, patch) => update(d => ({
    ...d,
    recurringOrders: (d.recurringOrders || []).map(template => template.id === id ? { ...template, ...patch, updatedAt: now() } : template),
  }));

  const deleteTemplate = id => {
    if (!confirm('Delete this standing order?')) return;
    update(d => ({ ...d, recurringOrders: (d.recurringOrders || []).filter(template => template.id !== id) }));
  };

  const exportData = () => {
    const headers = ['type', 'name', 'sku', 'email', 'phone', 'address', 'price', 'cost', 'onHand', 'terms'];
    const rows = [
      ...(data.customers || []).map(customer => ['customer', customer.name, '', customer.email, customer.phone, customer.address, '', '', '', customer.terms]),
      ...(data.products || []).map(product => ['product', product.name, product.sku, '', '', '', product.price, product.cost, product.onHand, '']),
    ];
    download('backwoods-master-data.csv', [headers, ...rows].map(row => row.map(csvCell).join(',')).join('\n'));
  };

  const importData = async file => {
    const rows = parseCsv(await file.text());
    let customers = 0, products = 0;
    await update(d => {
      const next = { ...d, customers: [...(d.customers || [])], products: [...(d.products || [])] };
      rows.forEach(row => {
        if (String(row.type).toLowerCase() === 'customer' && row.name) {
          next.customers.push({ id: makeId('c'), name: row.name, email: row.email || '', phone: row.phone || '', address: row.address || '', terms: row.terms || d.company.defaultTerms, balance: 0 });
          customers += 1;
        }
        if (String(row.type).toLowerCase() === 'product' && row.name) {
          next.products.push({ id: makeId('p'), name: row.name, sku: row.sku || '', price: Number(row.price || 0), cost: Number(row.cost || 0), onHand: Number(row.onHand || 0), reserved: 0, unit: 'each', caseQty: 1, reorderLevel: 10 });
          products += 1;
        }
      });
      return next;
    });
    setMessage(`Imported ${customers} customer(s) and ${products} product(s).`);
  };

  return <div>
    <div className="page-head">
      <div><h1>Launch Center</h1><p>Final controls for receivables, standing orders, and master-data migration.</p></div>
      <div className="badge success"><ShieldCheck size={16}/>Launch tools</div>
    </div>

    <div className="report-tabs no-print">{[['aging', 'Customer Aging'], ['recurring', 'Standing Orders'], ['data', 'Import / Export']].map(([id, label]) => <button key={id} className={tab === id ? 'active' : ''} onClick={() => setTab(id)}>{label}</button>)}</div>
    {message && <div className="success-note">{message}</div>}

    {tab === 'aging' && <>
      <div className="stats report-stats">{agingTotals.map(row => <div className="stat" key={row.bucket}><span>{row.bucket}</span><strong>{money(row.total)}</strong></div>)}</div>
      <section className="panel table-scroll">
        <h2>Accounts-receivable aging</h2>
        <table><thead><tr><th>Invoice</th><th>Customer</th><th>Due</th><th>Bucket</th><th>Balance</th></tr></thead><tbody>{aging.map(row => <tr key={row.id} className={row.bucket !== 'Current' ? 'overdue-row' : ''}><td>{row.invoiceNumber}</td><td>{row.customer}</td><td>{new Date(`${row.due}T12:00:00`).toLocaleDateString()}</td><td><span className="status">{row.bucket}</span></td><td>{money(row.balance)}</td></tr>)}</tbody></table>
        {!aging.length && <div className="empty compact">No open receivables yet.</div>}
      </section>
    </>}

    {tab === 'recurring' && <div className="diagnostics-grid">
      <section className="panel">
        <div className="panel-title"><div><h2><CalendarClock size={20}/>Standing orders</h2><p>{dueTemplates.length} due today, {activeTemplates.length} active.</p></div><button disabled={!dueTemplates.length} onClick={runDue}><PlayCircle size={17}/>Run due today</button></div>
        <div className="health-list">
          {templates.map(template => <div className={template.active === false ? 'health-row bad' : 'health-row ok'} key={template.id}>
            <div>{template.active === false ? 'II' : 'OK'}</div>
            <div>
              <strong>{template.name}</strong>
              <span>{(data.customers || []).find(customer => customer.id === template.customerId)?.name || 'Unknown store'} - {template.frequency} - next {template.nextRun || 'not set'} - {(template.items || []).length} line(s)</span>
              <div className="recurring-controls">
                <select value={template.frequency || 'weekly'} onChange={event => patchTemplate(template.id, { frequency: event.target.value })}><option value="weekly">Weekly</option><option value="biweekly">Every 2 weeks</option><option value="monthly">Monthly</option></select>
                <input type="date" value={template.nextRun || ''} onChange={event => patchTemplate(template.id, { nextRun: event.target.value })}/>
                <button className="secondary small" onClick={() => generateOne(template)}>Generate draft now</button>
                <button className="secondary small" onClick={() => patchTemplate(template.id, { active: template.active === false })}>{template.active === false ? 'Resume' : 'Pause'}</button>
                <button className="danger small" onClick={() => deleteTemplate(template.id)}><Trash2 size={14}/>Delete</button>
              </div>
            </div>
          </div>)}
          {!templates.length && <p className="muted">No standing orders yet.</p>}
        </div>
      </section>
      <section className="panel">
        <h2>Create from an existing order</h2>
        {(data.orders || []).slice(-10).reverse().map(order => <div className="credit-pickup" key={order.id}>
          <div><strong>{order.orderNumber}</strong><span>{(data.customers || []).find(customer => customer.id === order.customerId)?.name || order.customerName || ''}</span></div>
          <button className="small" onClick={() => createTemplate(order)}>Make standing</button>
        </div>)}
        {!(data.orders || []).length && <p className="muted">Create an order first, then turn it into a standing order here.</p>}
      </section>
    </div>}

    {tab === 'data' && <section className="panel">
      <h2>Master-data migration</h2>
      <p>Export a template, edit it in Excel, then import customers and products. Existing records are preserved.</p>
      <div className="actions">
        <button onClick={exportData}><Download size={17}/>Export CSV template</button>
        <button onClick={() => fileRef.current?.click()}><Upload size={17}/>Import CSV</button>
        <input ref={fileRef} hidden type="file" accept=".csv,text/csv" onChange={event => event.target.files?.[0] && importData(event.target.files[0])}/>
        <button className="secondary" onClick={() => location.reload()}><RefreshCw size={17}/>Refresh app</button>
      </div>
      <div className="panel inset"><strong>Required CSV columns</strong><p>type, name, sku, email, phone, address, price, cost, onHand, terms</p></div>
    </section>}
  </div>;
}
