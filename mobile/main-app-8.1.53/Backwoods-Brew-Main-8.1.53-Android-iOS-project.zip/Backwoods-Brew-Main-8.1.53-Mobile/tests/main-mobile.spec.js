import { test, expect } from '@playwright/test';
import { createHash } from 'node:crypto';
const password = 'Mobile-Only-Test-8!';
const salt = 'isolated-main-app-test';
const owner = { id: 991, username: 'mobiletest', displayName: 'Mobile Test Owner', role: 'owner', employeeId: 991, storeId: '1', active: true, mustResetPassword: false, passwordHash: createHash('sha256').update(`${salt}:${password}`).digest('hex'), passwordSalt: salt, passwordVersion: 'sha256-v1' };

async function isolate(page) {
  // Exercise the existing local-auth path without creating accounts or changing Firebase data.
  await page.route(/^https:\/\//, route => route.fulfill({ status: route.request().method() === 'OPTIONS' ? 204 : 400, headers: { 'access-control-allow-origin': 'http://127.0.0.1:5180', 'access-control-allow-credentials': 'true', 'access-control-allow-methods': '*', 'access-control-allow-headers': '*' }, contentType: 'application/json', body: route.request().method() === 'OPTIONS' ? '' : JSON.stringify({ error: { code: 400, message: 'CONFIGURATION_NOT_FOUND', errors: [{ message: 'CONFIGURATION_NOT_FOUND', domain: 'global', reason: 'invalid' }] } }) }));
  await page.addInitScript(user => {
    if (!localStorage.getItem('test-seeded')) {
      localStorage.setItem('backwoods-brew-stable-users', JSON.stringify([user]));
      localStorage.setItem('test-seeded', '1');
    }
  }, owner);
}
async function login(page) {
  await page.goto('/');
  await page.getByPlaceholder('Username', { exact: true }).fill(owner.username);
  await page.getByPlaceholder('Password', { exact: true }).fill(password);
  await page.getByRole('button', { name: 'Login', exact: true }).click();
  await expect(page.locator('.bb-app')).toBeVisible();
}
async function navigate(page, group, name) {
  await page.getByRole('button', { name: 'Menu', exact: true }).click();
  const aside = page.locator('.bb-app > aside');
  const target = aside.getByRole('button', { name, exact: true });
  if (!(await target.isVisible())) await aside.getByRole('button', { name: new RegExp(group) }).click();
  await target.click();
  await expect(aside).toBeHidden();
}
async function mockNative(page, platform = 'android') {
  await page.addInitScript(platform => {
    if (platform === 'android') window.androidBridge = {};
    else window.webkit = { messageHandlers: { bridge: {} } };
    window.__nativeCalls = [];
    const methods = { App: ['addListener', 'minimizeApp'], Filesystem: ['writeFile'], Share: ['share'], Browser: ['open'], Geolocation: ['requestPermissions', 'getCurrentPosition'], NativePrint: ['print'] };
    window.Capacitor = {
      PluginHeaders: Object.entries(methods).map(([name, entries]) => ({ name, methods: entries.map(name => ({ name, rtype: name === 'addListener' ? 'callback' : 'promise' })) })),
      nativeCallback: () => 'listener',
      nativePromise: async (plugin, method, options) => {
        window.__nativeCalls.push({ plugin, method, options });
        if (method === 'writeFile') return { uri: 'file:///cache/main-export.json' };
        if (method === 'requestPermissions') return { location: window.__denyLocation ? 'denied' : 'granted' };
        if (method === 'getCurrentPosition') return { coords: { latitude: 33.6, longitude: -85.8, accuracy: 12 } };
        return {};
      },
    };
  }, platform);
}

test.beforeEach(async ({ page }) => isolate(page));

test('main app local login and mobile business navigation', async ({ page }) => {
  const errors = [];
  page.on('pageerror', error => errors.push(error.message));
  await login(page);
  for (const [group, name] of [['Sales', 'POS Register'], ['Menu', 'Inventory'], ['Business', 'Backup / Export Center']]) {
    await navigate(page, group, name);
    await expect(page.locator('.bb-app > main')).toBeVisible();
  }
  expect(errors).toEqual([]);
});

for (const platform of ['android', 'ios']) {
  test(`${platform} native exports, receipt popup printing, external links and location`, async ({ page }) => {
    await mockNative(page, platform);
    await login(page);
    await navigate(page, 'Business', 'Backup / Export Center');
    await page.getByRole('button', { name: 'Download Full Backup', exact: true }).click();
    await expect.poll(() => page.evaluate(() => window.__nativeCalls.some(c => c.method === 'share'))).toBe(true);
    const backup = await page.evaluate(() => {
      const call = window.__nativeCalls.find(c => c.method === 'writeFile');
      return JSON.parse(new TextDecoder().decode(Uint8Array.from(atob(call.options.data), c => c.charCodeAt(0))));
    });
    expect(backup.type).toBe('backwoods-brew-full-backup');
    expect(backup.version).toContain('8.1.53');
    expect(Array.isArray(backup.data.orders)).toBe(true);
    await page.evaluate(() => {
      const win = window.open('', '_blank');
      win.document.open();
      win.document.write('<html><head><title>Test receipt</title><style>body{color:black}h1{font-size:22px}</style></head><body><h1>Backwoods receipt</h1><p>Total $12.50</p><script>throw new Error("must not execute")<\/script></body></html>');
      win.document.close();
    });
    await expect(page.getByRole('dialog', { name: 'Test receipt' })).toBeVisible();
    await expect(page.getByText('Total $12.50', { exact: true })).toBeVisible();
    await page.getByRole('button', { name: 'Print / Save PDF', exact: true }).click();
    await expect.poll(() => page.evaluate(() => window.__nativeCalls.some(c => c.method === 'print'))).toBe(true);
    await page.getByRole('button', { name: 'Close preview' }).click();
    await page.evaluate(() => window.open('https://www.irs.gov/', '_blank'));
    await expect.poll(() => page.evaluate(() => window.__nativeCalls.some(c => c.plugin === 'Browser' && c.method === 'open'))).toBe(true);
    const location = await page.evaluate(() => new Promise((resolve, reject) => navigator.geolocation.getCurrentPosition(resolve, reject)));
    expect(location.coords.latitude).toBe(33.6);
    const denied = await page.evaluate(() => {
      window.__denyLocation = true;
      return new Promise(resolve => navigator.geolocation.getCurrentPosition(() => resolve('wrong'), error => resolve(error.message)));
    });
    expect(denied).toContain('permission denied');
  });
}

test('cash sale saves a receipt and survives reload without a live cloud account', async ({ page }) => {
  page.on('dialog', dialog => dialog.type() === 'confirm' ? dialog.dismiss() : dialog.accept());
  await login(page);
  await navigate(page, 'Sales', 'POS Register');
  await page.locator('.bb-app > main').getByRole('button', { name: 'Add', exact: true }).first().click();
  await page.getByPlaceholder('Amount customer gave you').fill('100');
  await page.getByRole('button', { name: 'Complete Cash Sale', exact: true }).click();
  await expect.poll(() => page.evaluate(() => JSON.parse(localStorage.getItem('backwoods-brew-stable-data')).orders.length)).toBe(1);
  const saved = await page.evaluate(() => JSON.parse(localStorage.getItem('backwoods-brew-stable-data')).orders[0]);
  expect(saved.paymentType).toBe('Cash');
  expect(saved.total).toBeGreaterThan(0);
  expect(saved.items.length).toBeGreaterThan(0);
  expect(saved.receiptText).toContain('Backwoods');
  await page.reload();
  await expect(page.getByRole('button', { name: 'Login', exact: true })).toBeVisible();
  expect(await page.evaluate(() => JSON.parse(localStorage.getItem('backwoods-brew-stable-data')).orders.length)).toBe(1);
});

test('tablet navigation remains visible and login rejects a wrong password', async ({ page }) => {
  await page.setViewportSize({ width: 1024, height: 768 });
  await page.goto('/');
  await page.getByPlaceholder('Username', { exact: true }).fill(owner.username);
  await page.getByPlaceholder('Password', { exact: true }).fill('Wrong-test-password');
  await page.getByRole('button', { name: 'Login', exact: true }).click();
  await expect(page.getByRole('button', { name: 'Login', exact: true })).toBeEnabled();
  await expect(page.locator('.bb-app')).toHaveCount(0);
  await login(page);
  await expect(page.locator('.bb-app > aside')).toBeVisible();
  await expect(page.getByRole('button', { name: 'Menu', exact: true })).toBeHidden();
});
