import { Capacitor, registerPlugin } from '@capacitor/core';
import { App } from '@capacitor/app';
import { Browser } from '@capacitor/browser';
import { Filesystem, Directory } from '@capacitor/filesystem';
import { Geolocation } from '@capacitor/geolocation';
import { Share } from '@capacitor/share';
import './main.css';

const NativePrint = registerPlugin('NativePrint');
const native = Capacitor.isNativePlatform();
const showError = error => {
  if (!/cancel/i.test(error?.message || '')) window.alert(error?.message || 'Could not complete this action.');
};

async function shareBlob(blob, filename) {
  const data = await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result).split(',')[1]);
    reader.onerror = () => reject(new Error('Could not read the export.'));
    reader.readAsDataURL(blob);
  });
  const name = (filename || 'backwoods-export').replace(/[^a-zA-Z0-9._-]/g, '_');
  const result = await Filesystem.writeFile({ path: `exports/${Date.now()}-${name}`, directory: Directory.Cache, data, recursive: true });
  await Share.share({ title: name, files: [result.uri], dialogTitle: 'Save or share Backwoods Brew export' });
}
async function shareAnchor(anchor) {
  // Start reading before the existing app revokes its temporary object URL.
  const response = await fetch(anchor.href);
  if (!response.ok) throw new Error('Could not read the document.');
  await shareBlob(await response.blob(), anchor.download);
}

function scopePrintCss(css) {
  const style = document.createElement('style');
  style.textContent = css;
  document.head.append(style);
  function scope(rules) {
    for (const rule of rules) {
      if (rule.type === CSSRule.STYLE_RULE) {
        rule.selectorText = rule.selectorText.split(',').map(selector => {
          const s = selector.trim().replace(/^(?:html\s+)?body\b/, '#mobile-print-content');
          return s.startsWith('#mobile-print-content') ? s : `#mobile-print-content ${s}`;
        }).join(', ');
      } else if (rule.cssRules) scope(rule.cssRules);
    }
  }
  scope(style.sheet.cssRules);
  const result = [...style.sheet.cssRules].map(rule => rule.cssText).join('\n');
  style.remove();
  return result;
}

function openPrintPreview(html) {
  document.getElementById('mobile-print-preview')?.remove();
  const parsed = new DOMParser().parseFromString(html, 'text/html');
  const css = [...parsed.querySelectorAll('style')].map(node => node.textContent).join('\n');
  parsed.querySelectorAll('script, style, .controls, .no-print').forEach(node => node.remove());
  for (const node of parsed.querySelectorAll('*')) {
    for (const attr of [...node.attributes]) {
      if (/^on/i.test(attr.name) || /^(?:javascript|vbscript):/i.test(attr.value.trim())) node.removeAttribute(attr.name);
    }
  }
  const panel = document.createElement('section');
  panel.id = 'mobile-print-preview';
  panel.setAttribute('role', 'dialog');
  panel.setAttribute('aria-label', parsed.title || 'Document preview');
  const actions = document.createElement('div');
  actions.className = 'mobile-preview-actions';
  const close = document.createElement('button');
  close.textContent = 'Close preview';
  close.onclick = () => { panel.remove(); document.body.classList.remove('has-mobile-preview'); };
  const print = document.createElement('button');
  print.textContent = 'Print / Save PDF';
  print.onclick = () => NativePrint.print().catch(showError);
  actions.append(close, print);
  const content = document.createElement('div');
  content.id = 'mobile-print-content';
  content.innerHTML = parsed.body.innerHTML;
  const style = document.createElement('style');
  style.textContent = scopePrintCss(css);
  panel.append(style, actions, content);
  const pdf = content.querySelector('iframe[src^="data:application/pdf"]');
  if (pdf) {
    const save = document.createElement('button');
    save.textContent = 'Save or open PDF';
    save.onclick = () => {
      const anchor = document.createElement('a');
      anchor.href = pdf.src;
      anchor.download = `${parsed.title || 'Backwoods-document'}.pdf`;
      shareAnchor(anchor).catch(showError);
    };
    actions.append(save);
    // Use the system share/open flow for PDF attachments on both platforms.
    pdf.replaceWith(document.createTextNode('Use “Save or open PDF” to view this attachment.'));
  }
  document.body.classList.add('has-mobile-preview');
  document.body.append(panel);
  close.focus();
}

function createDocumentWindow() {
  let html = '';
  return {
    closed: false,
    document: {
      open() { html = ''; },
      write(...parts) { html += parts.join(''); },
      close() { openPrintPreview(html); },
    },
    focus() {},
    print() { NativePrint.print().catch(showError); },
    close() { document.querySelector('#mobile-print-preview .mobile-preview-actions button')?.click(); },
  };
}

function installMobileNavigation() {
  const app = document.querySelector('.bb-app');
  const aside = app?.querySelector(':scope > aside');
  if (!aside || app.querySelector('.main-mobile-header')) return;
  aside.id = 'main-app-navigation';
  const header = document.createElement('header');
  header.className = 'main-mobile-header';
  const title = document.createElement('strong');
  title.textContent = 'Backwoods Brew';
  const menu = document.createElement('button');
  menu.textContent = 'Menu';
  menu.setAttribute('aria-controls', aside.id);
  menu.setAttribute('aria-expanded', 'false');
  const close = () => { app.classList.remove('main-menu-open'); menu.textContent = 'Menu'; menu.setAttribute('aria-expanded', 'false'); };
  menu.onclick = () => {
    if (app.classList.contains('main-menu-open')) close();
    else { app.classList.add('main-menu-open'); menu.textContent = 'Close menu'; menu.setAttribute('aria-expanded', 'true'); }
  };
  aside.addEventListener('click', event => { if (event.target.closest('button')) close(); });
  header.append(title, menu);
  app.prepend(header);
}

function start() {
  installMobileNavigation();
  new MutationObserver(installMobileNavigation).observe(document.getElementById('root') || document.body, { childList: true, subtree: true });
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, { once: true });
else start();

if (native) {
  document.documentElement.classList.add('native-main-app');
  // Keep the original app's authentication flow; adapt only platform interactions.
  const click = HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click = function () {
    if (this.download && /^(?:blob:|data:)/.test(this.href)) { shareAnchor(this).catch(showError); return; }
    return click.call(this);
  };
  document.addEventListener('click', event => {
    const anchor = event.target.closest?.('a');
    if (!anchor) return;
    if (anchor.download && /^(?:blob:|data:)/.test(anchor.href)) {
      event.preventDefault(); shareAnchor(anchor).catch(showError);
    } else if (/^https?:/.test(anchor.href) && new URL(anchor.href).origin !== location.origin) {
      event.preventDefault(); Browser.open({ url: anchor.href }).catch(showError);
    }
  });
  const originalOpen = window.open.bind(window);
  window.open = (url, ...args) => {
    if (!url || url === 'about:blank') return createDocumentWindow();
    const resolved = new URL(url, location.href);
    if (/^https?:$/.test(resolved.protocol) && resolved.origin !== location.origin) {
      Browser.open({ url: resolved.href }).catch(showError);
      return null;
    }
    return originalOpen(url, ...args);
  };
  window.print = () => { NativePrint.print().catch(showError); };
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition = (success, error, options = {}) => {
      (async () => {
        const permission = await Geolocation.requestPermissions();
        if (permission.location !== 'granted' && permission.coarseLocation !== 'granted') throw new Error('Location permission denied. You can enter the store coordinates manually or enable location in Settings.');
        return Geolocation.getCurrentPosition({ ...options, timeout: options.timeout || 15000 });
      })().then(success, reason => error?.({ code: 1, message: reason.message }));
    };
  }
  App.addListener('backButton', () => {
    const close = document.querySelector('#mobile-print-preview .mobile-preview-actions button');
    const menu = document.querySelector('.main-menu-open .main-mobile-header button');
    if (close) close.click();
    else if (menu) menu.click();
    else App.minimizeApp();
  });
}
