Place your final Windows icon here as:

assets/icon.ico

The package.json installer config already points to this path.
If icon.ico is missing, electron-builder may warn or use a default icon.
