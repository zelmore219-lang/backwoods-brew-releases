import { defineConfig } from '@playwright/test';
import { existsSync } from 'node:fs';
export default defineConfig({
  testDir: './tests',
  use: { baseURL: 'http://127.0.0.1:5180', viewport: { width: 390, height: 844 }, launchOptions: { executablePath: process.env.CHROMIUM_PATH || (existsSync('/usr/bin/chromium') ? '/usr/bin/chromium' : undefined), args: ['--no-sandbox'] } },
  webServer: { command: 'npm run build && node scripts/serve.mjs', url: 'http://127.0.0.1:5180', reuseExistingServer: false },
});
